//
//  DashboardData.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 14/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import Foundation
import UIKit

class DashboardData {
    
    static func getAllDashboardItem() -> [DashboardModel] {
        var arrData = [DashboardModel]()
        arrData = [
            DashboardModel(img: UIImage(named: "note.text")!, title: "Notes"),
            DashboardModel(img: UIImage(named: "photo.on.rectangle")!, title: "Images"),
            DashboardModel(img: UIImage(named: "video")!, title: "Videos"),
            DashboardModel(img: UIImage(named: "music.quarternote.3")!, title: "Audios"),
            DashboardModel(img: UIImage(named: "alarm")!, title: "Reminders"),
            DashboardModel(img: UIImage(named: "folder")!, title: "Folders")
        ]
       return arrData
    }
}
