//
//  AppInfoData.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 16/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import Foundation

var section_name:String = ""
var section_id:String = ""

class AppInfoData {
    
    static func addAppInfo(sectionName:String,sectionID:String) -> [AppInfoDelegete] {
        var arrData = [AppInfoDelegete]()
        section_name = sectionName
        section_id   = sectionID
        arrData = [
            AppInfoDelegete(sectionName: section_name,sectionID:section_id)
        ]
       return arrData
    }
    
    static func getAppInfo() -> [AppInfoDelegete] {
        var arrData = [AppInfoDelegete]()
        arrData = [
            AppInfoDelegete(sectionName: section_name,sectionID:section_id)
        ]
       return arrData
    }
}
