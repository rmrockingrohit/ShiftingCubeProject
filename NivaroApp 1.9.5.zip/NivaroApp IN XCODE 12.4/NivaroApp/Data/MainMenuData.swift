//
//  MainMenuData.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 17/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import Foundation
import UIKit

class MainMenuData {
    
    static func getMain() -> [MainMenuModel] {
        var arrData = [MainMenuModel]()
        arrData = [
            MainMenuModel(img: UIImage(named: "house")!, title: "Home"),
            MainMenuModel(img: UIImage(named: "bookmark")!, title: "My Bookmark"),
            MainMenuModel(img: UIImage(named: "lock.shield")!, title: "Change Password"),
            MainMenuModel(img: UIImage(named: "support")!, title: "Support"),
            MainMenuModel(img: UIImage(named: "faq")!, title: "FAQ"),
            MainMenuModel(img: UIImage(named: "subscription")!, title: "Subscription"),
            MainMenuModel(img: UIImage(named: "logout")!, title: "Sign Out")
        ]
       return arrData
    }
}
