//
//  NotificationData.swift
//  NivaroApp
//
//  Created by Rohit Mishra on 25/03/1943 Saka.
//  Copyright © 1943 ShiftingCube PVT LTD. All rights reserved.
//

import Foundation
import CoreData
import UIKit

class NotificationData{
    
    // Share Instance
    static var notify = NotificationData()
    
    // App Deligate Connection
    let contexts = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    // Save To Local Data Base
    func save(object:[String:String]) {
        let store = NSEntityDescription.insertNewObject(forEntityName: "Notifications", into: contexts!) as! Notifications
        store.notificationID     = object["identifire"]
        store.notificationTitle  = object["title"]
        store.notificationText   = object["body"]
        store.notificationTime   = object["time"]
        do{
            try contexts?.save()
        }catch{
            print("data not saved")
        }
    }
    
    func getNotificationData()-> [Notifications]{
        var notifications = [Notifications]()
        let fetchRequest  = NSFetchRequest<NSManagedObject>(entityName: "Notifications")
        
        do{
            notifications = try contexts?.fetch(fetchRequest) as! [Notifications]
        }catch{
            print("can not get data")
        }
        
        return notifications
    }
    
    func deleteData(indexPath:Int)->[Notifications]{
        var notifications = [Notifications]()
        contexts?.delete(notifications[indexPath])
        notifications.remove(at:indexPath)
        do{
            try contexts?.save()
        }catch{
            print("data not saved")
        }
        
        return notifications
    }
    
    func deleteWithIdentifire(identifire:String){
        let notifications = getNotificationData()
        for object in notifications {
            if object.notificationID == identifire{
                contexts?.delete(object)
            }
        }
        
    }
    
}
