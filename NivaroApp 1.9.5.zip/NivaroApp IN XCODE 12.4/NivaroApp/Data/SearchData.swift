//
//  SearchData.swift
//  NivaroApp
//
//  Created by rohit mishra on 26/06/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import Foundation

class SearchData {
    
    var data : [String : AnyObject]?
    init(data:[String: AnyObject]?,items: Array<AnyObject>?){
        self.data = data
    }
}

class data {
    
    var name : String = ""
    
    var folderID: String = ""

    var userid: String = ""

    var parentID: String = ""

    var sectionid: String = ""

    var strtotime: String = ""

    var count: String = ""
    
    init(data:data){
        name      = data.name
        folderID  = data.folderID
        userid    = data.userid
        parentID  = data.parentID
        sectionid = data.sectionid
        strtotime = data.strtotime
        count     = data.count
    }
}
