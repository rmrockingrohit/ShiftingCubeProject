//
//  ChooseColorData.swift
//  NivaroApp
//
//  Created by Rohit Mishra on 29/03/1943 Saka.
//  Copyright © 1943 ShiftingCube PVT LTD. All rights reserved.
//

import Foundation

struct ChooseColorData:Codable{
    var data = [ResultItem]()
}
struct ResultItem:Codable{
    let colorID:String
    let name:String
    let code:String
}
