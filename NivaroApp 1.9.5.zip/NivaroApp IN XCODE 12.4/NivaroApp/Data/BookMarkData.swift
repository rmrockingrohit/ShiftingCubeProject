//
//  BookMarkData.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 18/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import Foundation
import UIKit

class BookMarkData {
    
    static func getBTNBookmark() -> [BookMarkCells] {
        var arrData = [BookMarkCells]()
        arrData = [
            BookMarkCells(img: UIImage(named: "note.text")!, title: "Note"),
            BookMarkCells(img: UIImage(named: "photo.on.rectangle")!, title: "Images"),
            BookMarkCells(img: UIImage(named: "video")!, title: "Video"),
            BookMarkCells(img: UIImage(named: "music.quarternote.3")!, title: "Audio")
        ]
       return arrData
    }
}
