//
//  AppInfoDelegete.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 16/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import Foundation

struct AppInfoDelegete:Decodable {
    
    let sectionName : String
    let sectionID   : String
}
