//
//  BookMarkCells.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 18/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import Foundation
import UIKit

struct BookMarkCells {
    let img : UIImage
    let title : String
}
