//
//  AllParentFolders.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 17/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import Foundation

struct AllParentFolders: Decodable {
  let count: Int
  let all: [NoteParentModel]
  
  enum CodingKeys: String, CodingKey {
    case count
    case all = "results"
  }
}
