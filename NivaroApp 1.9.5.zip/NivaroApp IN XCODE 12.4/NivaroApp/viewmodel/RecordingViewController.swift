//
//  RecordingViewController.swift
//  NivaroApp
//
//  Created by Rohit Mishra on 28/03/1943 Saka.
//  Copyright © 1943 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit
import AVFoundation
import Alamofire

class RecordingViewController: UIViewController, AVAudioRecorderDelegate, AVAudioPlayerDelegate {
    
    @IBOutlet weak var selectRecord: UIBarButtonItem!
    
    @IBOutlet weak var imageView: UIImageView!
    
    @IBOutlet weak var secondsIndicator: UILabel!
    
    @IBOutlet weak var secordBTN: UIButton!
    
    @IBOutlet weak var stopBTN: UIButton!
    
    @IBOutlet weak var playRecording: UIButton!
    
    var audioRecorder: AVAudioRecorder!
    var audioPlayer : AVAudioPlayer!
    var meterTimer:Timer!
    var isAudioRecordingGranted: Bool!
    var isRecording = false
    var isPlaying = false
    
    let userID     = UserDefaults.standard.string(forKey: "userID")
    
    var spiner  = UIActivityIndicatorView()
    
    var folderID = ""
    var countNote:String = ""
    
    override func viewDidLoad() {
        
        stopBTN.isEnabled        = false
        playRecording.isEnabled  = false
        selectRecord.isEnabled   = false
        super.viewDidLoad()
        
        switch AVAudioSession.sharedInstance().recordPermission {
        case AVAudioSessionRecordPermission.granted:
            isAudioRecordingGranted = true
            break
        case AVAudioSessionRecordPermission.denied:
            isAudioRecordingGranted = false
            break
        case AVAudioSessionRecordPermission.undetermined:
            AVAudioSession.sharedInstance().requestRecordPermission({ (allowed) in
                if allowed {
                    self.isAudioRecordingGranted = true
                } else {
                    self.isAudioRecordingGranted = false
                }
            })
            break
        default:
            break
        }
    }
    
    
    @IBAction func recordSound(_ sender: Any) {
        
        stopBTN.isEnabled      = true
        secordBTN.isEnabled    = false
        selectRecord.isEnabled = false
        
        print("recording Start")
        
        // Recording Start
        if(isRecording)
        {
            finishAudioRecording(success: true)
            isRecording = false
        }
        else
        {
            setup_recorder()
            
            audioRecorder.record()
            meterTimer = Timer.scheduledTimer(timeInterval: 0.1, target:self, selector:#selector(self.updateAudioMeter(timer:)), userInfo:nil, repeats:true)
            isRecording = true
        }
        
    }
    
    @IBAction func stopRecording(_ sender: Any) {
        
        stopBTN.isEnabled      = false
        secordBTN.isEnabled    = true
        selectRecord.isEnabled = true
        playRecording.isEnabled = true
        isRecording            = false
        print("recording Closed")
        self.finishAudioRecording(success: true)
    }
    
    
    func getDocumentsDirectory() -> URL
    {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentsDirectory = paths[0]
        return documentsDirectory
    }
    
    func getFileUrl() -> URL
    {
        let filename = "myRecording.m4a"
        let filePath = getDocumentsDirectory().appendingPathComponent(filename)
        return filePath
    }
    
    
    func setup_recorder()
    {
        if isAudioRecordingGranted
        {
            let session = AVAudioSession.sharedInstance()
            do
            {
                try session.setCategory(AVAudioSession.Category.playAndRecord, options: .defaultToSpeaker)
                try session.setActive(true)
                let settings = [
                    AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
                    AVSampleRateKey: 44100,
                    AVNumberOfChannelsKey: 2,
                    AVEncoderAudioQualityKey:AVAudioQuality.high.rawValue
                ]
                audioRecorder = try AVAudioRecorder(url: getFileUrl(), settings: settings)
                audioRecorder.delegate = self
                audioRecorder.isMeteringEnabled = true
                audioRecorder.prepareToRecord()
            }
            catch let error {
                print(error.localizedDescription)
            }
        }
        else
        {
            print("recording Permission not allowed")
        }
    }
    
    
    @objc func updateAudioMeter(timer: Timer)
    {
        if audioRecorder.isRecording
        {
            let hr = Int((audioRecorder.currentTime / 60) / 60)
            let min = Int(audioRecorder.currentTime / 60)
            let sec = Int(audioRecorder.currentTime.truncatingRemainder(dividingBy: 60))
            let totalTimeString = String(format: "%02d:%02d:%02d", hr, min, sec)
            secondsIndicator.text = totalTimeString
            audioRecorder.updateMeters()
        }
    }
    
    func finishAudioRecording(success: Bool)
    {
        if success
        {
            audioRecorder.stop()
            audioRecorder = nil
            meterTimer.invalidate()
            print("recorded successfully.")
        }
        else
        {
            print("Recording Failed")
        }
    }
    
    
    func audioRecorderDidFinishRecording(_ recorder: AVAudioRecorder, successfully flag: Bool) {
        stopBTN.isEnabled      = false
        secordBTN.isEnabled    = true
        selectRecord.isEnabled = true
        
        secondsIndicator.text  = "00:00:00"
        
    }
    
    
    
    @IBAction func playRecord(_ sender: Any) {
        
        if(isPlaying)
        {
            audioPlayer.stop()
            
            secordBTN.isEnabled = true
            stopBTN.isEnabled = true
            playRecording.setBackgroundImage(UIImage(named: "play.circle"), for: .normal)
            
            isPlaying = false
        }
        else
        {
            if FileManager.default.fileExists(atPath: getFileUrl().path)
            {
                secordBTN.isEnabled = false
                stopBTN.isEnabled = false
                playRecording.setBackgroundImage(UIImage(named: "stop.fill"), for: .normal)
                prepare_play()
                audioPlayer.play()
                isPlaying = true
            }
            else
            {
                print("Error on play")
            }
        }
        
    }
    
    
    func prepare_play()
    {
        do
        {
            audioPlayer = try AVAudioPlayer(contentsOf: getFileUrl())
            audioPlayer.delegate = self
            audioPlayer.prepareToPlay()
        }
        catch{
            print("Error")
        }
    }
    
    @IBAction func selectRecording(_ sender: Any) {
        getFileName(message: "Enter File Name")
    }
    
    
    func getFileName(message:String){
        let alertController = UIAlertController(title: "Add Media File", message: message, preferredStyle: .alert)
        // creating text fields
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter Audio Name"
        }
        
        let saveAction = UIAlertAction(title: "Save", style: .default, handler: { alert -> Void in
            let nameMedia   = alertController.textFields![0] as UITextField
            // Check for NameMedia Is Not Empty
            
            if nameMedia.text!.isEmpty{
                self.getFileName(message: "Media File Name Required.")
            }else{
                self.uploadRecording(fileName:nameMedia.text!)
            }
            
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil )
        
        alertController.addAction(saveAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    func uploadRecording(fileName:String){
        
        let urlFile = getFileUrl()
        
        let progressView = UIProgressView()
        let uploadLBL    = UILabel()
        let alertView    = UIAlertController(title: "/n/n/n/n/n/n/n/n/n", message: "Uploading..", preferredStyle: .alert)
        self.present(alertView, animated: true, completion:{
            let margin:CGFloat = 8.0
            let rect = CGRect(x: margin, y: 72.0, width: alertView.view.frame.width - margin * 2.0 , height: 2.0)
            progressView.frame = rect
            progressView.progress = 0
            progressView.tintColor = UIColor.systemBlue
            alertView.view.addSubview(progressView)
            
            uploadLBL.frame = CGRect(x: 10, y: 90, width: Int((alertView.view.frame.width - margin * 2.0)), height: 30)
            uploadLBL.textAlignment = .center
            uploadLBL.text  = "0%"
            uploadLBL.textColor = UIColor.systemBlue
            alertView.view.addSubview(uploadLBL)
        })
        
        let timestamp = NSDate().timeIntervalSince1970 // just for some random name.
        let endPoint = URL(string: "https://nivaroapp.nivaro.com.au/api/ios/UploadVideo")
        
        // check for limit in subscription
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/CheckSubscriptionLimit/")!)
        request.httpMethod  = "POST"
        let postString      = "userID=\(userID!)&sectionID=3"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            
                            if let status = json["result"] as? String, status == "true" {
                                
                                AF.upload(multipartFormData: { (multipartFormData) in
                                    multipartFormData.append(urlFile, withName: "Video", fileName: "\(timestamp).mp3", mimeType: "\(timestamp)/mp3")
                                }, to: endPoint!,method: .post)
                                .uploadProgress { progress in
                                    progressView.progress = Float(Int(progress.fractionCompleted * 100))
                                    uploadLBL.text = String(Int(progress.fractionCompleted * 100)) + "%"
                                }
                                .responseJSON { (response) in
                                    
                                    if response.value != nil {
                                        let jsonData     = response.value as! [String:Any]
                                        let dataResponce = jsonData["data"] as! String
                                        self.updateVideoData(userID:self.userID!,noteName:fileName,folderID:self.folderID,labelName:"",sectionID:"3",image:dataResponce)
                                    }
                                    
                                    alertView.dismiss(animated: true, completion: nil)
                                }
                                
                            }else{
                                DispatchQueue.main.async {
                                    let alert = UIAlertController(title: "Nivaro Error", message: json["message"] as? String, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    func updateVideoData(userID:String,noteName:String,folderID:String,labelName:String,sectionID:String,image:String){
        
        var countVal : String = ""
        
        if self.countNote != "Unlimited"{
            countVal = "\(Int(self.countNote)! - 1)"
        }else{
            countVal = self.countNote
        }
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/UploadVideoData/")!)
        request.httpMethod  = "POST"
        let postString      = "userID=\(userID)&noteName=\(noteName)&folderID=\(folderID)&labelName=\(labelName)&sectionID=\(sectionID)&image=\(image)&countUpd=\(countVal)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                    
                }
                
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            
                            if let status = json["result"] as? String, status == "true" {
                                // Get Folder Clik Data From API
                                DispatchQueue.main.async {
                                    let alert = UIAlertController(title: "Nivaro Success", message: "Upload Success", preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                    pageLoad = "yes"
                                }
                                
                            }else{
                                DispatchQueue.main.async {
                                    let alert = UIAlertController(title: "Nivaro Error", message: error?.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                   
                                }
                                
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                        
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
}
