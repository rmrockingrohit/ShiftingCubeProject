//
//  ChangePasswordViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 19/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class ChangePasswordViewController: UIViewController,UITextViewDelegate {
    
    @IBOutlet weak var outletPasswordView: UIView!
    @IBOutlet weak var mainPass: UITextField!
    @IBOutlet weak var changePass: UITextField!
    @IBOutlet weak var verifyPass: UITextField!
    
    let usersName  = UserDefaults.standard.string(forKey: "UserName")
    let loginKey   = UserDefaults.standard.string(forKey: "loginKey")
    let userID     = UserDefaults.standard.string(forKey: "userID")
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        outletPasswordView.layer.borderWidth = 1.0
        outletPasswordView.layer.borderColor = CGColor(red: 255/255, green: 14/255, blue: 0/255, alpha: 1)
        
        mainPass.textColor   = UIColor(named: "lightgray")
        changePass.textColor = UIColor(named: "lightgray")
        verifyPass.textColor = UIColor(named: "lightgray")
    }
    
    @IBAction func changePass(_ sender: Any) {
        
        let changePassword   = changePass.text
        let verifyPassword   = verifyPass.text
        let originalPassword = mainPass.text
        
        
        // checking for change password and verify password
        if changePassword != verifyPassword {
            let alert = UIAlertController(title: "Nivaro Password Not Matched", message: "New password not matched with verify password.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else if changePassword == "" || changePassword?.count == 0{
            let alert = UIAlertController(title: "Nivaro Password Not Matched", message: "Password Field can't be null.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else if verifyPassword == "" || verifyPassword?.count == 0{
            let alert = UIAlertController(title: "Nivaro Verify Password", message: "Verify Password Field can't be null.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else if originalPassword != loginKey{
            let alert = UIAlertController(title: "Nivaro Login Password ", message: "Input Login password  ot matched with your given login password.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/change_password/")!)
            request.httpMethod  = "POST"
            let postString      = "control=change_password&userID=\(userID!)&new_password=\(changePassword!)&old_password=\( originalPassword!)"
            request.httpBody    = postString.data(using: .utf8)
            
            let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
                if error != nil{
                    print(error?.localizedDescription as Any)
                }else{
                    if let urlContent = data{
                        do{
                            if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: String] {
                                if let status = json["result"], status == "true" {
                                    
                                    UserDefaults.standard.set(changePassword!, forKey: "loginKey")
                                    
                                    DispatchQueue.main.async {
                                        let alert = UIAlertController(title: "Nivaro Password Changed", message: "Hi ! \(self.usersName!). Your Account Password Has been changed.", preferredStyle: UIAlertController.Style.alert)
                                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                        self.present(alert, animated: true, completion: nil)
                                    }
                                    
                                }else{
                                    print(json["message"]!)
                                    DispatchQueue.main.async {
                                        let alert = UIAlertController(title: "Nivaro", message: "Password Can't change now . Try later.", preferredStyle: UIAlertController.Style.alert)
                                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                        self.present(alert, animated: true, completion: nil)
                                    }
                                    
                                }
                            }
                        } catch let error {
                            DispatchQueue.main.async {
                                let alert = UIAlertController(title: "Nivaro", message: error.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                            }
                           
                        }// Do And Catch Close
                    }// URL Content CLose]
                }//Task Control Close
            }
            task.resume()
        }
        
        
    }
    
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
