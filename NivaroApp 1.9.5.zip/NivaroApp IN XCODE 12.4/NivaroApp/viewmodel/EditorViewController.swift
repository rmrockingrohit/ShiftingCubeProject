//
//  EditorViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 25/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit
import RichEditorView
import Combine

class EditorViewController: UIViewController,RichEditorToolbarDelegate,UITextViewDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate,URLSessionDelegate, URLSessionTaskDelegate, URLSessionDataDelegate,UIColorPickerViewControllerDelegate{
    
    var noteID         : String = ""
    var parentID       : String = ""
    var folderID       : String = ""
    var userid         : String = ""
    var html           : String = ""
    var fileID         : String = ""
    var label_name     : String = ""
    var note_name      : String = ""
    var is_taged       : String = ""
    var userID         : String = ""
    var password       : String = ""
    
    var countNote      : String = ""
    
    
    var editor           = RichEditorView()
    let pickerController = UIImagePickerController()
    let colorPicker      = UIColorPickerViewController()
    var spiner           = UIActivityIndicatorView()
    
    @IBOutlet weak var editorView: UIView!
    @IBOutlet weak var scrollView: UIScrollView!
   
    
    var pickerImgs  : UIImage?        = nil
    var imageUrl    : URL?            = nil
    var cancellable : AnyCancellable?
    var colorName   : String          = ""
    
    var is_new          = ""
    
    let userIDSaved     = UserDefaults.standard.string(forKey: "userID")
    let usersName       = UserDefaults.standard.string(forKey: "UserName")
    
    var noteVC = NoteViewController()
    
    override func viewDidLoad() {
        if is_new.isEmpty{
            getNoteDetails(noteID: noteID)
        }
        
        editorView.backgroundColor = UIColor.lightGray
        
        super.viewDidLoad()
        
        editor = RichEditorView(frame: CGRect(x: 0, y: 0, width: editorView.bounds.width - 40, height: editorView.bounds.height - 50))
        
        editorView.addSubview(editor)
        editor.editingEnabled = true
        pickerController.delegate = self
    }
    
    
    
    @IBAction func bold(_ sender: Any) {
        
        editor.getSelectedText { (r) in
            self.editor.bold()
        }
    }
    
    @IBAction func italic(_ sender: Any) {
        
        editor.getSelectedText { (r) in
            self.editor.italic()
        }
    }
    
    @IBAction func underline(_ sender: Any) {
        
        editor.getSelectedText { (r) in
            self.editor.underline()
        }
    }
    
    @IBAction func leftAlign(_ sender: Any) {
        editor.getSelectedText { (r) in
            self.editor.alignLeft()
        }
    }
    
    @IBAction func centerAlign(_ sender: Any) {
        editor.getSelectedText { (r) in
            self.editor.alignCenter()
        }
    }
    
    @IBAction func rightAlign(_ sender: Any) {
        editor.getSelectedText { (r) in
            self.editor.alignRight()
        }
    }
    
    
    @IBAction func orderList(_ sender: Any) {
        editor.getSelectedText { (r) in
            self.editor.orderedList()
        }
    }
    
    
    @IBAction func checks(_ sender: Any) {
        editor.getSelectedText { (r) in
            self.editor.setCheckbox()
        }
        
    }
    
    @IBAction func undo(_ sender: Any) {
        editor.getSelectedText { (r) in
            self.editor.undo()
        }
    }
    
    @IBAction func image(_ sender: Any) {
        pickerController.allowsEditing          = false
        pickerController.sourceType             = .photoLibrary
        pickerController.modalPresentationStyle = .popover
        pickerController.mediaTypes             = ["public.image"]
        present(pickerController, animated: true, completion: nil)
    }
    
    @IBAction func textColor(_ sender: Any) {
        colorPicker.selectedColor = self.view.backgroundColor!
        colorPicker.delegate = self
  
        self.present(colorPicker, animated: true, completion: nil)
        
        
    }
    
    @IBAction func createLink(_ sender: Any) {
        let alertController = UIAlertController(title: "Set Link.", message: "", preferredStyle: UIAlertController.Style.alert)
        /* Add Text Boxes */
        alertController.addTextField { (textField : UITextField!) -> Void in
        textField.placeholder = "Enter Url Here."
            
            let saveAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { alert -> Void in
                
                let setUrl   = alertController.textFields![0] as UITextField
                self.editor.getSelectedText { (r) in
                    self.editor.insertLink(href: setUrl.text!, text: setUrl.text!, title: r!)
                }
            })
            
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler:nil)
            
            alertController.addAction(saveAction)
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true, completion: nil)
        }
    }
 
    
    /*   Image Picking Sections */
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        let imageFile = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
        
        self.uploadFiles(imageUrl: imageFile!)

        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
       
        dismiss(animated: true, completion: nil)
    }
    
    func colorPickerViewControllerDidFinish(_ viewController: UIColorPickerViewController) {
        
        let colorNames = viewController.selectedColor
        editor.getSelectedText { (r) in
            self.editor.setTextColor(colorNames)
        }
    }
    
    func colorPickerViewControllerDidSelectColor(_ viewController: UIColorPickerViewController) {
        self.view.backgroundColor = viewController.selectedColor
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        let touch: UITouch? = touches.first
        if touch?.view != editorView {
            self.view.endEditing(true)
        }
       
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    @IBAction func saveText(_ sender: Any) {
        
        editor.getHtml { (r) in
            
            if r.isEmpty{
                let alert = UIAlertController(title: "Note Cant Be Empty!", message: "New Note Cant Be Empty. Please Add Some Data in to Note And Then Save.", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
            }else{
                let jsonData = r.replacingOccurrences(of: "&nbsp;", with: " ")
                
                if self.is_new.isEmpty == false{
                    let alertController = UIAlertController(title: "Note File Name", message: "Please Enter Note Name.", preferredStyle: .alert)
                
                    alertController.addTextField { (textField : UITextField!) -> Void in
                        textField.placeholder = "Enter Note Name"
                    }
    
                    let saveAction = UIAlertAction(title: "Save", style: .default, handler: { alert -> Void in
                        
                        let firstTextField = alertController.textFields![0] as UITextField
                        self.createNewNote(parentID: self.parentID, noteName: firstTextField.text!, note: String(describing: jsonData))
                               
                    })
    
                    let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil )
    
                    alertController.addAction(saveAction)
                    alertController.addAction(cancelAction)
    
                    self.present(alertController, animated: true, completion: nil)
                }else{
                    self.saveNoteDataToServer()
                }
                
            }
        }
    }
    
   
    
    
    func saveNoteDataToServer(){
        editor.getHtml { (r) in
            
            let jsonData = r.replacingOccurrences(of: "&nbsp;", with: " ")
            
            var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/UpdateNote/")!)
                    request.httpMethod  = "POST"
            let postString      = "noteID=\(self.noteID)&text=\(jsonData)"
            request.httpBody    = postString.data(using: .utf8)
            
            let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
                if error != nil{
                    print(error?.localizedDescription as Any)
                }else{
                    if let urlContent = data{
                        do{
                            if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                                if let status = json["result"] as? String, status == "true" {
                                    DispatchQueue.main.async {
                                        self.html = r
                                        let viewHtml = NoteReadViewController()
                                        viewHtml.html = r
                                        let alert = UIAlertController(title: "Nivaro Success", message: "Note Updated Successfully", preferredStyle: UIAlertController.Style.alert)
                                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                        self.present(alert, animated: true, completion: nil)
                                    }
                                }else{
                                    DispatchQueue.main.async {
                                        let alert = UIAlertController(title: "Nivaro Error", message: (json["message"] as! String), preferredStyle: UIAlertController.Style.alert)
                                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                        self.present(alert, animated: true, completion: nil)
                                    }
                                }
                            }
                        } catch let error {
                            print(error.localizedDescription)
                        }// Do And Catch Close
                    }// URL Content CLose]
                }//Task Control Close
            }
            task.resume()
        }
    }
    
    func createNewNote(parentID:String,noteName:String,note:String){
        
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        var count : String = ""
        if self.countNote != "Unlimited"{
            count = "\(Int(self.countNote)! - 1)"
        }else{
            count = "Unlimited"
        }
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/add_note/")!)
        request.httpMethod  = "POST"
        let postString      = "note_name=\(noteName)&userID=\(userIDSaved!)&text=\(note)&folderID=\(parentID)&section_id=1&noteCount=\(count)&type=note"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                // Get Folder Clik Data From API
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    self.noteVC = self.storyboard?.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController

                                    self.noteVC.reloadView = "true"
                                    pageLoad = "yes"
                                    self.navigationController?.popViewController(animated: true)
                                    self.dismiss(animated: true, completion: nil)
                                }
                            }else{
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    let alert = UIAlertController(title: "Nivaro Error", message: json["message"] as? String, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    func getNoteDetails(noteID:String){
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/view_note/")!)
        request.httpMethod  = "POST"
        let postString      = "noteID=\(noteID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                
                                if let content = json["data"] as? [[String:Any]] {
                                    DispatchQueue.main.async {
                                        
                                        self.folderID   = content[0]["noteID"] as! String
                                        self.userid     = content[0]["userID"] as! String
                                        self.html       = content[0]["text"] as! String
                                        self.fileID     = content[0]["fileID"] as! String
                                        self.label_name = content[0]["label_name"] as! String
                                        self.note_name  = content[0]["note_name"] as! String
                                        self.is_taged   = content[0]["is_taged"] as! String
                                        self.userID     = content[0]["userID"] as! String
                                        self.password   = content[0]["password"] as? String ?? ""
                                        
                                        self.editor.html = self.html
                                    }
                                }else{
                                    print("JSON DECODE ERROR")
                                }
                            }else{
                                print("Responce Error")
                            }
                        }
                    } catch let error {
                        print(error.localizedDescription)
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    func uploadFiles(imageUrl:UIImage){
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        spiner.backgroundColor = UIColor.black
        spiner.alpha = 0.8
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        let myUrl = NSURL(string: "https://nivaroapp.nivaro.com.au/api/ios/UploadMedia");
        let request = NSMutableURLRequest(url:myUrl! as URL);
        request.httpMethod = "POST";
        let boundary = "Boundary-\(NSUUID().uuidString)"
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        
        let imageData = imageUrl.jpegData(compressionQuality:0.8)
        
        if(imageData==nil)  {
            spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
            return;
            
        }
        
        request.httpBody = createBodyWithParameters(filePathKey: "img", imageDataKey: imageData! as NSData, boundary: boundary) as Data
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    let alert = UIAlertController(title: "Nivaro Alert", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
                
                return
            }else{
                
                if let urlContent = data{
                    do {
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            
                            if let status = json["result"] as? String, status == "true" {
                                self.editor.insertImage(json["message"] as! String, alt: "NivaroApp")
                                
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                }
                            }
                        }
                    }catch{
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            let alert = UIAlertController(title: "Nivaro Alert", message: error.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }
                }
                
            }
        }
        task.resume()
    }
    
    
    func createBodyWithParameters( filePathKey: String?, imageDataKey: NSData, boundary: String) -> NSData {
        let body = NSMutableData();
        
        let filename = "user-profile.jpg"
        let mimetype = "image/jpg"
        
        body.appendString(string: "--\(boundary)\r\n")
        body.appendString(string: "Content-Disposition: form-data; name=\"\(filePathKey!)\"; filename=\"\(filename)\"\r\n")
        body.appendString(string: "Content-Type: \(mimetype)\r\n\r\n")
        body.append(imageDataKey as Data)
        body.appendString(string: "\r\n")
        body.appendString(string: "--\(boundary)--\r\n")
        return body
    }
    
}



extension ViewController {
    
    func initializeHideKeyboard(){
        //Declare a Tap Gesture Recognizer which will trigger our dismissMyKeyboard() function
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self,
            action: #selector(dismissMyKeyboard))
        
        //Add this tap gesture recognizer to the parent view
        view.addGestureRecognizer(tap)
    }
    
    @objc func dismissMyKeyboard(){
        //endEditing causes the view (or one of its embedded text fields) to resign the first responder status.
        //In short- Dismiss the active keyboard.
        view.endEditing(true)
    }
    
}
