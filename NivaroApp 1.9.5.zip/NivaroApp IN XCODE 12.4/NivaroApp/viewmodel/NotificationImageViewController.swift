//
//  NotificationImageViewController.swift
//  NivaroApp
//
//  Created by rohit mishra on 02/07/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit
import WebKit
import AVKit

class NotificationImageViewController: UIViewController {

    @IBOutlet weak var previewImage: UIImageView!
   
    @IBOutlet weak var textView: UITextView!
    
    @IBOutlet weak var videoAudioView: UIView!
    
    @IBOutlet weak var playBtn: UIButton!
    
    
    var passVal = ""
    var type    = ""
    
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        let navBar                  = self.navigationController?.navigationBar
        navBar?.barTintColor        = UIColor.systemRed
        navBar?.tintColor           = UIColor.white
        navBar?.isTranslucent       = false
        navBar?.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
        self.textView.backgroundColor = .white
        self.textView.allowsEditingTextAttributes = false
        self.textView.isEditable = false

        self.previewImage.isHidden   = true
        self.textView.isHidden       = true
        self.videoAudioView.isHidden = true
        
        if self.type == "image"{
            
            let url  = URL(string: passVal)
            let data = try? Data(contentsOf: url!)
            self.previewImage.isHidden = false
            self.previewImage.image = UIImage(data:data!)
            
        }else if self.type == "note"{
            
            // Convert html data to swift string
            let encodedData = passVal.data(using: String.Encoding.utf8)!
            var attributedString: NSAttributedString

            do {
                attributedString = try NSAttributedString(data: encodedData, options: [NSAttributedString.DocumentReadingOptionKey.documentType:NSAttributedString.DocumentType.html,NSAttributedString.DocumentReadingOptionKey.characterEncoding:NSNumber(value: String.Encoding.utf8.rawValue)], documentAttributes: nil)
                
                self.textView.isHidden       = false
                self.textView.attributedText = attributedString
                
            } catch let error as NSError {
                
                let alert = UIAlertController(title: "Notification Error", message: "This Note's HTML Content conversion Failed.", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
                
            } catch {
                let alert = UIAlertController(title: "Notification Error", message: "This Note's HTML Content conversion Failed.", preferredStyle: UIAlertController.Style.alert)
                alert.addAction(UIAlertAction(title: "ok", style: UIAlertAction.Style.default, handler: nil))
                self.present(alert, animated: true, completion: nil)
            }
            
            
            
        }else if self.type == "video"{
            
            self.videoAudioView.isHidden  = false
            
            let videoURL                = URL(string: passVal)
            let player                  = AVPlayer(url: videoURL!)
            let playerViewController    = AVPlayerViewController()
            playerViewController.player = player
            
            self.present(playerViewController, animated: true) {
                playerViewController.player!.play()
            }
            
        }else{
            
            let videoURL                = URL(string: passVal)
            let player                  = AVPlayer(url: videoURL!)
            let playerViewController    = AVPlayerViewController()
            playerViewController.player = player
            
            self.present(playerViewController, animated: true) {
                playerViewController.player!.play()
            }
        }
        
    }
    
    
    @IBAction func abortMission(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
    }
    
    
    
    @IBAction func repeatAudioVideo(_ sender: Any) {
        
        let videoURL = URL(string: passVal)
        let player = AVPlayer(url: videoURL!)
        let playerViewController = AVPlayerViewController()
        playerViewController.player = player
        self.present(playerViewController, animated: true) {
            playerViewController.player!.play()
        }
        
    }
    
    
    
}
