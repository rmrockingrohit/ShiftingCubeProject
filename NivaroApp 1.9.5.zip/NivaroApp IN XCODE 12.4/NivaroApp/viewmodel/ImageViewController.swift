//
//  ImageViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 16/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class ImageViewController: UIViewController {

    @IBOutlet weak var navigatiBarItem: UINavigationItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        navigatiBarItem.title = "Images"
        // Do any additional setup after loading the view.
    }

}
