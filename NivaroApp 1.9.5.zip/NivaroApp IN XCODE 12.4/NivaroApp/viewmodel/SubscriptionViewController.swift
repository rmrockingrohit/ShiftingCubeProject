//
//  SubscriptionViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 20/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class SubscriptionViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    var itemID    : [Any] = []
    var itemmode  : [Any] = []
    var itemplan  : [Any] = []
    var itemprice : [Any] = []
    var itemnote  : [Any] = []
    var itemvideo : [Any] = []
    var itemaudio : [Any] = []
    var itemimgs  : [Any] = []

    @IBOutlet weak var collectionView: UICollectionView!
    override func viewDidLoad() {
        super.viewDidLoad()
        collectionView.dataSource = self
        collectionView.delegate   = self
        
        
        if let layout = self.collectionView.collectionViewLayout as? UICollectionViewFlowLayout{
            let width = UIScreen.main.bounds.width
            layout.sectionInset = UIEdgeInsets(top: 15, left: 5, bottom: 15, right: 5)
            layout.itemSize = CGSize(width: width / 1.5, height: width / 1.5)
            layout.minimumInteritemSpacing = 25
            layout.minimumLineSpacing = 25
        }
        
        getSubscriptionList()
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return itemID.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "subsCell", for: indexPath) as! SubscriptionCollectionViewCell
        cell.title.text = itemplan[indexPath.row] as? String
        return cell
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
    }
    
    func getSubscriptionList() {
        var subcribeID  : [Any] = []
        var mode        : [Any] = []
        var plan        : [Any] = []
        var price       : [Any] = []
        var count_note  : [Any] = []
        var count_video : [Any] = []
        var count_audio : [Any] = []
        var count_imgs  : [Any] = []
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/Subscription_list/")!)
        request.httpMethod  = "POST"
        let postString      = "control=subscription"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                if let content  = json["data"]  as? [[String: String]] {
                                    for d in content{
                                        
                                        let subsID     = d["subcribeID"]!
                                        let modes      = d["mode"]!
                                        let plans      = d["plan"]!
                                        let prices     = d["price"]!
                                        let countNote  = d["count_note"]!
                                        let countVideo = d["count_video"]!
                                        let countAudio = d["count_audio"]!
                                        let countImg   = d["count_imgs"]!
                                        
                                        subcribeID.append(subsID)
                                        mode.append(modes)
                                        plan.append(plans)
                                        price.append(prices)
                                        count_note.append(countNote)
                                        count_video.append(countVideo)
                                        count_audio.append(countAudio)
                                        count_imgs.append(countImg)
                                    }
                                    
                                    DispatchQueue.main.async {
                                        self.itemID    = subcribeID
                                        self.itemmode  = mode
                                        self.itemplan  = plan
                                        self.itemprice = price
                                        self.itemnote  = count_note
                                        self.itemvideo = count_video
                                        self.itemaudio = count_audio
                                        self.itemimgs  = count_imgs
                                        
                                        self.collectionView.reloadData()
                                        print(self.itemplan)
                                    }
                                }
                            }else{
                                DispatchQueue.main.async {
                                    let alert = UIAlertController(title: "Nivaro", message: json["message"] as? String, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            let alert = UIAlertController(title: "Nivaro", message: error.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                       
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
}


extension SubscriptionViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 180, height: 80)
    }
}
