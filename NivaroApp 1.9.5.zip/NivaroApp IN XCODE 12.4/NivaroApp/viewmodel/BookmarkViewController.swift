//
//  BookmarkViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 18/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class BookmarkViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource{
    
    
    var arrData       = [BookMarkCells]()
    var arrDataMenu   = [MainMenuModel]()
    var dashboardData = [AppInfoDelegete]()
    
    var screenSize: CGRect!
    var screenWidth: CGFloat!
    var screenHeight: CGFloat!
    
    var spiner  = UIActivityIndicatorView()
    
    @IBOutlet weak var editProfile: UIButton!
    @IBOutlet weak var mainMenuView: UIView!
    @IBOutlet weak var profileNAme: UILabel!
    @IBOutlet weak var menuTableView: UITableView!
    @IBOutlet weak var menuPresentView: UIView!
    @IBOutlet weak var userInfoView: UIView!
    
    @IBOutlet weak var bookmarkBtnView: UICollectionView!
    @IBOutlet weak var bookmarkShowView: UICollectionView!
    
    
    // Defing Global Array For Element Fetch
    var folderID    : [Any] = []
    var userid      : [Any] = []
    var sectionid   : [Any] = []
    var strtotime   : [Any] = []
    var count       : [Any] = []
    var name        : [Any] = []
    var imageVal    : [Any] = []
    var notetxt     : [Any] = []
    var notepass    : [Any] = []
    var istagged    : [Any] = []
    var labelnames  : [Any] = []
    var iconcolor   : [Any] = []
    
    // getting user defaults
    let userID     = UserDefaults.standard.string(forKey: "userID")
    let usersName  = UserDefaults.standard.string(forKey: "UserName")
    
    var is_select = "1"
    
    
    override func viewDidLoad() {
        editProfile.isHidden = true
        mainMenuView.isHidden = true
        mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
        arrDataMenu = MainMenuData.getMain()
        
        profileNAme.text = usersName
        // Spiners Start
//        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
//        spiner.center = view.center
//        spiner.style  = UIActivityIndicatorView.Style.large
//        spiner.color  = .orange
//        spiner.hidesWhenStopped = true
//        view.addSubview(spiner)
//        spiner.startAnimating()
//        self.view.isUserInteractionEnabled = false
        
        super.viewDidLoad()
        arrData = BookMarkData.getBTNBookmark()
        
        getTaggedItems(userID: userID!, sectionID: "1")
        
        // Navigation Bar Top Properties
        let navBar = self.navigationController?.navigationBar
        navBar?.barTintColor = UIColor(hex: "#D35400")
        navBar?.tintColor = UIColor.white
        navBar?.isTranslucent = false
        navBar?.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
        
        // Collection View Button Properties
        
        screenSize = UIScreen.main.bounds
        screenWidth = screenSize.width
        screenHeight = screenSize.height
        
        self.bookmarkBtnView.contentInset = UIEdgeInsets(top: 5, left: 5, bottom: 10, right: 10)
        self.bookmarkBtnView.dataSource = self
        self.bookmarkBtnView.delegate = self
        
        self.bookmarkShowView.contentInset = UIEdgeInsets(top: 5, left: 5, bottom: 10, right: 10)
        self.bookmarkShowView.dataSource = self
        self.bookmarkShowView.delegate = self
        
        if let layout = self.bookmarkShowView.collectionViewLayout as? UICollectionViewFlowLayout{
            let width = UIScreen.main.bounds.width
            layout.sectionInset = UIEdgeInsets(top: 15, left: 5, bottom: 15, right: 5)
            layout.itemSize = CGSize(width: width / 3, height: width / 3)
            layout.minimumInteritemSpacing = 5
            layout.minimumLineSpacing = 5
        }
        
//        self.spiner.stopAnimating()
//        self.view.isUserInteractionEnabled = true
        
        
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == bookmarkBtnView{
            return arrData.count
        }else{
            return folderID.count
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        if collectionView == bookmarkBtnView{
            let cell = bookmarkBtnView.dequeueReusableCell(withReuseIdentifier: "bookMarkBtn", for: indexPath) as! BookMarkButtonCollectionViewCell
            
            cell.layer.cornerRadius = 20
            cell.layer.borderWidth     = 1.0
            cell.layer.borderColor = CGColor(red: 255/255, green: 14/255, blue: 0/255, alpha: 0.5)
            
            cell.cellLabel.textColor   = UIColor.lightGray
            
            cell.cellImg.image   = arrData[indexPath.row].img
            cell.cellLabel.text  = arrData[indexPath.row].title
            
            if cell.cellLabel.text == "Note"{
                
                if is_select == "1"{
                    cell.backgroundColor       = UIColor.systemYellow
                    cell.tintColor             = UIColor.black
                    cell.cellLabel.textColor   = UIColor.black
                }else{
                    cell.backgroundColor       = UIColor(red: 0/255, green: 0/255, blue: 0/255, alpha: 0.2)
                    cell.cellLabel.textColor   = UIColor.lightGray
                    cell.tintColor             = UIColor.systemYellow
                }
                
            }else if cell.cellLabel.text == "Audio"{
                if is_select == "3"{
                    cell.backgroundColor       = UIColor.systemGreen
                    cell.tintColor             = UIColor.black
                    cell.cellLabel.textColor   = UIColor.black
                }else{
                    cell.backgroundColor       = UIColor(red: 0/255, green: 0/255, blue: 0/255, alpha: 0.2)
                    cell.cellLabel.textColor   = UIColor.lightGray
                    cell.tintColor             = UIColor.systemGreen
                }
                
            }else if cell.cellLabel.text == "Video"{
                
                if is_select == "2"{
                    cell.backgroundColor       = UIColor.red
                    cell.tintColor             = UIColor.black
                    cell.cellLabel.textColor   = UIColor.black
                }else{
                    cell.backgroundColor       = UIColor(red: 0/255, green: 0/255, blue: 0/255, alpha: 0.2)
                    cell.cellLabel.textColor   = UIColor.lightGray
                    cell.tintColor             = UIColor.red
                }
                
            }else if cell.cellLabel.text == "Images"{
                
                if is_select == "4"{
                    cell.backgroundColor       = UIColor.white
                    cell.tintColor             = UIColor.black
                    cell.cellLabel.textColor   = UIColor.black
                }else{
                    cell.backgroundColor       = UIColor(red: 0/255, green: 0/255, blue: 0/255, alpha: 0.2)
                    cell.cellLabel.textColor   = UIColor.lightGray
                    cell.tintColor             = UIColor.white
                }
            }
            
            return cell
        }else{
            
            let cell2 = bookmarkShowView.dequeueReusableCell(withReuseIdentifier: "bookmarkItem", for: indexPath) as! BookmarkItemCollectionViewCell
            
            // Default Hidden Cell Properties
            cell2.previewImage.isHidden = true
            cell2.labelName.isHidden    = true
            
            if (notepass[indexPath.row] as! String) != ""{
                cell2.itemImg.image = UIImage(named: "lock.doc.fill")
            }else{
                if is_select == "4"{
                    cell2.itemImg.isHidden      = true
                    cell2.previewImage.isHidden = false
                    cell2.labelName.isHidden    = false
                    
                    cell2.previewImage.image    = imageVal[indexPath.row] as? UIImage
                    cell2.labelName.text        = (labelnames[indexPath.row] as! String)
                }else{
                    cell2.previewImage.isHidden = true
                    cell2.itemImg.isHidden      = false
                    cell2.labelName.isHidden    = true
                    cell2.itemImg.image         = imageVal[indexPath.row] as? UIImage
                }
                
            }
            cell2.itemName.text = name[indexPath.row] as? String
            
            cell2.layer.cornerRadius = 10
            cell2.layer.borderWidth = 2.0
            cell2.layer.borderColor = UIColor.systemRed.cgColor
            
            cell2.layer.backgroundColor = UIColor.white.cgColor
            return cell2
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == bookmarkBtnView{
            let selected = (indexPath.row)
            
            if selected == 0{
                is_select = "1"
                getTaggedItems(userID: userID!, sectionID: "1")
            }else if selected == 1{
                is_select = "4"
                getTaggedItems(userID: userID!, sectionID: "4")
            }else if selected == 2{
                is_select = "2"
                getTaggedItems(userID: userID!, sectionID: "2")
            }else{
                is_select = "3"
                getTaggedItems(userID: userID!, sectionID: "3")
            }
            
            bookmarkBtnView.reloadData()
            
        }else{
            
            if is_select == "1"{
                
                let storyboard       = UIStoryboard(name: "Note", bundle: nil)
                
                let secondVC         = storyboard.instantiateViewController(withIdentifier: "noteRead_vc") as! NoteReadViewController
                secondVC.noteID      = folderID[indexPath.row] as! String
                //secondVC.parentID    = parentID[indexPath.row] as! String
                
                show(secondVC, sender: self)
                
            }else if is_select == "4"{
                
                let storyboard = UIStoryboard(name: "Note", bundle: nil)
                let secondVC   = storyboard.instantiateViewController(withIdentifier: "showImage_vc") as! ImagePreviewViewController
                secondVC.sectionID        = "4"
                secondVC.clikedID         = folderID[indexPath.row] as! String
                secondVC.is_bookmarkPage  = "y"
                show(secondVC, sender: self)
                
            }else if is_select == "2"{
                let storyboard = UIStoryboard(name: "Note", bundle: nil)
                let secondVC = storyboard.instantiateViewController(withIdentifier: "showVideo_vc") as! ShowVideoViewController
                
                secondVC.noteID      = folderID[indexPath.row] as! String
                //secondVC.parentID    = parentID[indexPath.row] as! String
                secondVC.nameImg     = name[indexPath.row] as! String
                secondVC.videoUrl    = notetxt[indexPath.row] as! String
                secondVC.sections    = "2"
                
                show(secondVC, sender: self)
                
                
            }else if is_select == "3"{
                let storyboard = UIStoryboard(name: "Note", bundle: nil)
                let secondVC = storyboard.instantiateViewController(withIdentifier: "showVideo_vc") as! ShowVideoViewController
                
                secondVC.noteID      = folderID[indexPath.row] as! String
                //secondVC.parentID    = parentID[indexPath.row] as! String
                secondVC.nameImg     = name[indexPath.row] as! String
                secondVC.videoUrl    = notetxt[indexPath.row] as! String
                secondVC.sections    = "3"
                
                show(secondVC, sender: self)
                
            }
        }
    }
 
    func getTaggedItems(userID:String, sectionID: String){
        
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        var folder_ID    : [Any] = []
        var user_ID      : [Any] = []
        var name_Val     : [Any] = []
        
        var section_ID   : [Any] = []
        var count_Val    : [Any] = []
       
        var image_Val    : [Any] = []
        var note_txt     : [Any] = []
        var note_pass    : [Any] = []
        var is_tagged    : [Any] = []
        var label_names  : [Any] = []
        var icon_color   : [Any] = []
        
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/BookmarkItems")!)
        request.httpMethod  = "POST"
        let postString      = "userID=\(userID)&section_id=\(sectionID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                if let content  = json["data"]  as? [[String: Any]] {
                                    
                                    
                                    // Array Collection For Notes
                                    for nt in content{
                                        
                                        let folderIDs  =   nt["noteID"]!
                                        let userIDs    =   nt["userID"]!
                                        let names      =   nt["note_name"]!
                                        let section_ids =  ""
                                        let counts     =   ""
                                        
                                        if sectionID == "4"{
//                                            let imgs = UIImage(named: "photo.fill")
//                                            image_Val.append(imgs!)
                                            
                                            let url  = URL(string: nt["text"] as! String)
                                            let data = try? Data(contentsOf: url!)
                                            let imgs = UIImage(data: data!)
                                            image_Val.append(imgs!)
                                            
                                        }else if sectionID == "1"{
                                            
                                            let imgs       =   UIImage(named: "doc.text.fill")
                                            image_Val.append(imgs!)
                                        }else if sectionID == "2"{
                                            let imgs       =   UIImage(named: "video")
                                            image_Val.append(imgs!)
                                        }else if sectionID == "3"{
                                            let imgs       =   UIImage(named: "music.quarternote.3")
                                            image_Val.append(imgs!)
                                        }
                                        // Add Null For Notes Properties
                                        let noteTextss =   nt["text"]!
                                        let notePass   =   nt["password"]!
                                        let isTag      =   nt["is_taged"]!
                                        let lblName    =   nt["label_name"]!
                                        let icnColor   =   nt["icon_color"]!
                                        
                                        folder_ID.append(folderIDs)
                                        user_ID.append(userIDs)
                                        name_Val.append(names)
                                        section_ID.append(section_ids)
                                        count_Val.append(counts)
                                        note_txt.append(noteTextss)
                                        note_pass.append(notePass)
                                        is_tagged.append(isTag)
                                        label_names.append(lblName)
                                        icon_color.append(icnColor)
                                    }
                                    
                                    DispatchQueue.main.async {
                                        self.folderID  = folder_ID
                                        self.userid    = user_ID
                                        self.sectionid = section_ID
                                        self.count     = count_Val
                                        self.name      = name_Val
                                        self.imageVal  = image_Val
                                        self.notetxt   = note_txt
                                        self.notepass  = note_pass
                                        self.istagged  = is_tagged
                                        self.labelnames = label_names
                                        self.iconcolor  = icon_color
                                        
                                        self.bookmarkShowView.reloadData()
                                        self.spiner.stopAnimating()
                                        self.view.isUserInteractionEnabled = true
                                    }
                                }
                                
                            }else{
                                print("Responce Error")
                            }
                        }
                    } catch let error {
                        print(error.localizedDescription)
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrDataMenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MainMenuCell") as! MainMenuTableViewCell
        cell.menuIcon.image = arrDataMenu[indexPath.row].img
        cell.menuNameLabel.text = arrDataMenu[indexPath.row].title
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let type = indexPath.row
        
        switch type {
        
        case (0):
            
            dashboardData = AppInfoData.addAppInfo(sectionName: "Notes",sectionID:"1")
            
            
            let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
        case (1):
            
            let storyboard = UIStoryboard(name: "MyBookmarks", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "bookmark_vc") as! BookmarkViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
        case (2):
            
            let storyboard = UIStoryboard(name: "MyBookmarks", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "bookmark_vc") as! BookmarkViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
        case (3):
             
            dashboardData = AppInfoData.addAppInfo(sectionName: "Audios",sectionID:"3")
            
            let storyboard = UIStoryboard(name: "Note", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
        case (4):
            
            dashboardData = AppInfoData.addAppInfo(sectionName: "Reminders",sectionID:"1")
            
            let storyboard = UIStoryboard(name: "Note", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
        case (5):
            
            dashboardData = AppInfoData.addAppInfo(sectionName: "Folders",sectionID:"1")
            
            let storyboard = UIStoryboard(name: "Note", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
        case (6):
            
            dashboardData = AppInfoData.addAppInfo(sectionName: "Folders",sectionID:"1")
            
            let storyboard = UIStoryboard(name: "Note", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
        default:
            dashboardData = AppInfoData.addAppInfo(sectionName: "",sectionID:"")
        }
        
    }
    
    @IBAction func goToDashboard(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
    
    @IBAction func mainMenuOpened(_ sender: Any) {
    
        UIView.animate(withDuration: 0.4) {
            self.mainMenuView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
            self.mainMenuView.isHidden = false
        }
    }

    /* ----------------------------------  Over Ride For Tuch Detection ----------------------*/
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        
        let touch: UITouch? = touches.first
        //location is relative to the current view
        // do something with the touched point
        if (touch?.view != menuPresentView) || (touch?.view != userInfoView) {
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
        }
        
        
    }
    
}
