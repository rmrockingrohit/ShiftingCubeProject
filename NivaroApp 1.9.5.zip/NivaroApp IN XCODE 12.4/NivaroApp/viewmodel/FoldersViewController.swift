//
//  FoldersViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 21/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class FoldersViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource{
    
    // getting Dashboard Click Info
    var dashboardData = [AppInfoDelegete]()
    var arrDataMenu = [MainMenuModel]()
    
    var spiner  = UIActivityIndicatorView()
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var collectionView2: UICollectionView!
    
    @IBOutlet weak var collectionView3: UICollectionView!
    
    @IBOutlet weak var collectionView4: UICollectionView!
    
    @IBOutlet weak var mainMenuView: UIView!
    @IBOutlet weak var menuTableView: UITableView!
    @IBOutlet weak var menuPresentView: UIView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var userInfoView: UIView!
    @IBOutlet weak var editProfile: UIButton!
    @IBOutlet weak var mainMenuBtn: UIBarButtonItem!
    
    
    var folderID1    : [Any] = []
    var userID1      : [Any] = []
    var nameVal1     : [Any] = []
    var parentID1    : [Any] = []
    var sectionID1   : [Any] = []
    var countVal1    : [Any] = []
    
    var folderID2    : [Any] = []
    var userID2      : [Any] = []
    var nameVal2     : [Any] = []
    var parentID2    : [Any] = []
    var sectionID2   : [Any] = []
    var countVal2    : [Any] = []
    
    var folderID3    : [Any] = []
    var userID3      : [Any] = []
    var nameVal3     : [Any] = []
    var parentID3    : [Any] = []
    var sectionID3   : [Any] = []
    var countVal3    : [Any] = []
    
    var folderID4    : [Any] = []
    var userID4      : [Any] = []
    var nameVal4     : [Any] = []
    var parentID4    : [Any] = []
    var sectionID4   : [Any] = []
    var countVal4    : [Any] = []
    
    
    var menu_open:Bool = false
    
    let userID     = UserDefaults.standard.string(forKey: "userID")
    //userDefaultes
    let usersName  = UserDefaults.standard.string(forKey: "UserName")
    
    override func viewDidLoad() {
        editProfile.isHidden = true
        super.viewDidLoad()
        
        // navigation bar properties
        let navBar = self.navigationController?.navigationBar
        
        navBar?.barTintColor = UIColor(hex: "#D35400")
        
        navBar?.tintColor = UIColor.white
        
        navBar?.isTranslucent = false
        
        navBar?.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
    
        
        collectionView.dataSource = self
        collectionView.delegate   = self
        
        collectionView2.dataSource = self
        collectionView2.delegate   = self

        collectionView3.dataSource = self
        collectionView3.delegate   = self

        collectionView4.dataSource = self
        collectionView4.delegate   = self


        getSectionFoldersForSection1(userID: userID!, sectionID: "1", control: "show_sec_folder")
        
        getSectionFoldersForSection2(userID: userID!, sectionID: "2", control: "show_sec_folder")

        getSectionFoldersForSection3(userID: userID!, sectionID: "3", control: "show_sec_folder")

        getSectionFoldersForSection4(userID: userID!, sectionID: "4", control: "show_sec_folder")
        
        mainMenuView.isHidden = true
        mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
        
        userNameLabel.text = usersName
        arrDataMenu = MainMenuData.getMain()
        
        menu_open = false
        
    }
    
    
    override func viewDidAppear(_ animated: Bool) {
        if folderID1.count < 0{
            self.collectionView.isHidden = true
        }
    }
    
    public func getSectionFoldersForSection1(userID:String,sectionID:String,control:String){
        
        var folder_ID    : [Any] = []
        var user_ID      : [Any] = []
        var name_Val     : [Any] = []
        var parent_ID    : [Any] = []
        var section_ID   : [Any] = []
        var count_Val    : [Any] = []
        var types        : [Any] = []
        
        
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/section_folder")!)
        request.httpMethod  = "POST"
        let postString      = "control=\(control)&userID=\(userID)&section_id=\(sectionID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
                
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                if let content = json["data"] as? [[String:String]] {
                                    if content.count != 0{
                                        for category in content{
                                            let folderIDs    =   category["folderID"]!
                                            let userIDs      =   category["userID"]!
                                            let parentIDs    =   category["parentID"]!
                                            let sewctionIDs  =   category["section_id"]!
                                            let names        =   category["name"]!
                                            let countss      =   category["count"]!
                                            let typess       =   "folder"
                                            
                                            
                                            name_Val.append(names)
                                            folder_ID.append(folderIDs)
                                            user_ID.append(userIDs)
                                            parent_ID.append(parentIDs)
                                            section_ID.append(sewctionIDs)
                                            count_Val.append(countss)
                                            types.append(typess)
                                            
                                        }
                                    }
                                    
                                    DispatchQueue.main.async {
                                        
                                        self.folderID1  = folder_ID
                                        self.nameVal1   = name_Val
                                        self.parentID1  = parent_ID
                                        self.sectionID1 = section_ID
                                        self.countVal1  = count_Val
                                       
                                        // Hide If No Data Found
                                        if self.folderID1.isEmpty == true{
                                            self.collectionView.isHidden = true
                                        }else{
                                            self.collectionView.reloadData()
                                        }
                                    }
                                }
                            }else{
                                DispatchQueue.main.async {
                                    self.collectionView.reloadData()
                                }
                                print("Responce Error")
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                                                        
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                        
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    public func getSectionFoldersForSection2(userID:String,sectionID:String,control:String){
        
        var folder_ID    : [Any] = []
        var user_ID      : [Any] = []
        var name_Val     : [Any] = []
        var parent_ID    : [Any] = []
        var section_ID   : [Any] = []
        var count_Val    : [Any] = []
        var types        : [Any] = []
        
        
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/section_folder")!)
        request.httpMethod  = "POST"
        let postString      = "control=\(control)&userID=\(userID)&section_id=\(sectionID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
                
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                if let content = json["data"] as? [[String:String]] {
                                    if content.count != 0{
                                        for category in content{
                                            let folderIDs    =   category["folderID"]!
                                            let userIDs      =   category["userID"]!
                                            let parentIDs    =   category["parentID"]!
                                            let sewctionIDs  =   category["section_id"]!
                                            let names        =   category["name"]!
                                            let countss      =   category["count"]!
                                            let typess       =   "folder"
                                            
                                            
                                            name_Val.append(names)
                                            folder_ID.append(folderIDs)
                                            user_ID.append(userIDs)
                                            parent_ID.append(parentIDs)
                                            section_ID.append(sewctionIDs)
                                            count_Val.append(countss)
                                            types.append(typess)
                                            
                                        }
                                    }
                                    
                                    DispatchQueue.main.async {
                                        
                                        self.folderID2  = folder_ID
                                        self.nameVal2   = name_Val
                                        self.parentID2  = parent_ID
                                        self.sectionID2 = section_ID
                                        self.countVal2  = count_Val
                                       
                                        // Hide If No Data Found
                                        if self.folderID2.isEmpty == true{
                                            self.collectionView2.isHidden = true
                                        }else{
                                            self.collectionView2.reloadData()
                                        }
                                    }
                                }
                            }else{
                                DispatchQueue.main.async {
                                   // self.collectionView2.reloadData()
                                }
                                print("Responce Error")
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                        
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    public func getSectionFoldersForSection3(userID:String,sectionID:String,control:String){
        
        var folder_ID    : [Any] = []
        var user_ID      : [Any] = []
        var name_Val     : [Any] = []
        var parent_ID    : [Any] = []
        var section_ID   : [Any] = []
        var count_Val    : [Any] = []
        var types        : [Any] = []
        
        
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/section_folder")!)
        request.httpMethod  = "POST"
        let postString      = "control=\(control)&userID=\(userID)&section_id=\(sectionID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
                
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                if let content = json["data"] as? [[String:String]] {
                                    if content.count != 0{
                                        for category in content{
                                            let folderIDs    =   category["folderID"]!
                                            let userIDs      =   category["userID"]!
                                            let parentIDs    =   category["parentID"]!
                                            let sewctionIDs  =   category["section_id"]!
                                            let names        =   category["name"]!
                                            let countss      =   category["count"]!
                                            let typess       =   "folder"
                                            
                                            
                                            name_Val.append(names)
                                            folder_ID.append(folderIDs)
                                            user_ID.append(userIDs)
                                            parent_ID.append(parentIDs)
                                            section_ID.append(sewctionIDs)
                                            count_Val.append(countss)
                                            types.append(typess)
                                            
                                        }
                                    }
                                    
                                    DispatchQueue.main.async {
                                        
                                        self.folderID3  = folder_ID
                                        self.nameVal3   = name_Val
                                        self.parentID3  = parent_ID
                                        self.sectionID3 = section_ID
                                        self.countVal3  = count_Val
                                       
                                        // Hide If No Data Found
                                        if self.folderID3.isEmpty == true{
                                            self.collectionView3.isHidden = true
                                        }else{
                                            self.collectionView3.reloadData()
                                        }
                                    }
                                }
                            }else{
                                DispatchQueue.main.async {
                                    //self.collectionView3.reloadData()
                                }
                                print("Responce Error")
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                        
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    public func getSectionFoldersForSection4(userID:String,sectionID:String,control:String){
        
        var folder_ID    : [Any] = []
        var user_ID      : [Any] = []
        var name_Val     : [Any] = []
        var parent_ID    : [Any] = []
        var section_ID   : [Any] = []
        var count_Val    : [Any] = []
        var types        : [Any] = []
        
        
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/section_folder")!)
        request.httpMethod  = "POST"
        let postString      = "control=\(control)&userID=\(userID)&section_id=\(sectionID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
                
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                if let content = json["data"] as? [[String:String]] {
                                    if content.count != 0{
                                        for category in content{
                                            let folderIDs    =   category["folderID"]!
                                            let userIDs      =   category["userID"]!
                                            let parentIDs    =   category["parentID"]!
                                            let sewctionIDs  =   category["section_id"]!
                                            let names        =   category["name"]!
                                            let countss      =   category["count"]!
                                            let typess       =   "folder"
                                            
                                            
                                            name_Val.append(names)
                                            folder_ID.append(folderIDs)
                                            user_ID.append(userIDs)
                                            parent_ID.append(parentIDs)
                                            section_ID.append(sewctionIDs)
                                            count_Val.append(countss)
                                            types.append(typess)
                                            
                                        }
                                    }
                                    
                                    DispatchQueue.main.async {
                                        
                                        self.folderID4  = folder_ID
                                        self.nameVal4   = name_Val
                                        self.parentID4  = parent_ID
                                        self.sectionID4 = section_ID
                                        self.countVal4  = count_Val
                                       
                                        // Hide If No Data Found
                                        if self.folderID4.isEmpty == true{
                                            self.collectionView4.isHidden = true
                                        }else{
                                            self.collectionView4.reloadData()
                                        }
                                        
                                    }
                                }
                            }else{
                                DispatchQueue.main.async {
                                   // self.collectionView4.reloadData()
                                }
                                print("Responce Error")
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                        
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if collectionView == self.collectionView{
            // Hide If No Data Found
            return folderID1.count
        }else if collectionView == self.collectionView2{
            return folderID2.count
        }else if collectionView == self.collectionView3{
            return folderID3.count
        }else if collectionView == self.collectionView4{
            return folderID4.count
        }else{
            return 0
        }
   
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        
        if collectionView == self.collectionView{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collection1", for: indexPath) as! Folder1CollectionViewCell

            cell.layer.cornerRadius = 5
            cell.layer.borderWidth = 1.0
            cell.layer.borderColor = UIColor.systemRed.cgColor
            cell.layer.backgroundColor = UIColor.white.cgColor
            cell.frame.size = CGSize(width: 100, height: 100)

            //cell.cellImage.image = UIImage(named: "folder.fill")
            cell.label.text  = nameVal1[indexPath.row] as? String
            return cell
        }else if collectionView == self.collectionView2{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collection2", for: indexPath) as! Folder2CollectionViewCell

            cell.layer.cornerRadius = 5
            cell.layer.borderWidth = 1.0
            cell.layer.borderColor = UIColor.systemRed.cgColor
            cell.layer.backgroundColor = UIColor.white.cgColor
            cell.frame.size = CGSize(width: 100, height: 100)

           // cell.cellImage.image = UIImage(named: "folder.fill")
            cell.label.text  = nameVal2[indexPath.row] as? String
            return cell
        }else if collectionView == self.collectionView3{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collection3", for: indexPath) as! Folder3CollectionViewCell

            cell.layer.cornerRadius = 5
            cell.layer.borderWidth = 1.0
            cell.layer.borderColor = UIColor.systemRed.cgColor
            cell.layer.backgroundColor = UIColor.white.cgColor
            cell.frame.size = CGSize(width: 100, height: 100)

           // cell.cellImage.image = UIImage(named: "folder.fill")
            cell.label.text  = nameVal3[indexPath.row] as? String
            return cell
        }else if collectionView == self.collectionView4{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collection4", for: indexPath) as! Folder4CollectionViewCell

            cell.layer.cornerRadius = 5
            cell.layer.borderWidth = 1.0
            cell.layer.borderColor = UIColor.systemRed.cgColor
            cell.layer.backgroundColor = UIColor.white.cgColor
            cell.frame.size = CGSize(width: 100, height: 100)

            //cell.cellImage.image = UIImage(named: "folder.fill")
            cell.label.text  = nameVal4[indexPath.row] as? String
            return cell
        }else{
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collection1", for: indexPath) as! Folder1CollectionViewCell

            cell.layer.cornerRadius = 5
            cell.layer.borderWidth = 1.0
            cell.layer.borderColor = UIColor.systemRed.cgColor
            cell.layer.backgroundColor = UIColor.white.cgColor
            cell.frame.size = CGSize(width: 100, height: 100)

            //cell.cellImage.image = UIImage(named: "folder.fill")
            cell.label.text  = nameVal1[indexPath.row] as? String
            return cell
        }
        
    }
    
    override func size(forChildContentContainer container: UIContentContainer, withParentContainerSize parentSize: CGSize) -> CGSize {
        return CGSize(width: 100.0, height: 100.0)
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout,
    insetForSectionAtIndex section: Int) -> UIEdgeInsets {

        let cellWidthPadding  = collectionView.frame.size.width / 30
        let cellHeightPadding = collectionView.frame.size.height / 4
        return UIEdgeInsets(top: cellHeightPadding,left: cellWidthPadding, bottom: cellHeightPadding,right: cellWidthPadding)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if collectionView == self.collectionView{
//            let folderID = folderID1[indexPath.row] as! String
//            let name     = nameVal1[indexPath.row] as! String
//            let type     = "folder"
            dashboardData = AppInfoData.addAppInfo(sectionName: "Notes",sectionID:"1")
            
            let storyboard      = UIStoryboard(name: "Note", bundle: nil)
            let secondVC        = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
            //showNote_vc ShowNoteViewController
            secondVC.folderID.append(folderID1[indexPath.row] as! String)
            secondVC.name.append(nameVal1[indexPath.row] as! String)
            secondVC.typeVal.append("folder")
            secondVC.parentID.append(parentID1[indexPath.row] as! String)
            show(secondVC, sender: self)
            
        }else if collectionView == self.collectionView2{
            
            dashboardData = AppInfoData.addAppInfo(sectionName: "Notes",sectionID:"2")
            
            let storyboard      = UIStoryboard(name: "Note", bundle: nil)
            let secondVC        = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
            //showNote_vc ShowNoteViewController
            secondVC.folderID.append(folderID2[indexPath.row] as! String)
            secondVC.name.append(nameVal2[indexPath.row] as! String)
            secondVC.typeVal.append("folder")
            secondVC.parentID.append(parentID2[indexPath.row] as! String)
            show(secondVC, sender: self)
            
        }else if collectionView == self.collectionView3{
            dashboardData = AppInfoData.addAppInfo(sectionName: "Notes",sectionID:"3")
            
            let storyboard      = UIStoryboard(name: "Note", bundle: nil)
            let secondVC        = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
            //showNote_vc ShowNoteViewController
            secondVC.folderID.append(folderID3[indexPath.row] as! String)
            secondVC.name.append(nameVal3[indexPath.row] as! String)
            secondVC.typeVal.append("folder")
            secondVC.parentID.append(parentID3[indexPath.row] as! String)
            show(secondVC, sender: self)
            
        }else if collectionView == self.collectionView4{
            
            dashboardData = AppInfoData.addAppInfo(sectionName: "Notes",sectionID:"4")
            
            let storyboard      = UIStoryboard(name: "Note", bundle: nil)
            let secondVC        = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
            //showNote_vc ShowNoteViewController
            secondVC.folderID.append(folderID4[indexPath.row] as! String)
            secondVC.name.append(nameVal4[indexPath.row] as! String)
            secondVC.typeVal.append("folder")
            secondVC.parentID.append(parentID4[indexPath.row] as! String)
            show(secondVC, sender: self)
            
        }
    }
    
    /* ==================== Toolbar Item Bottom Buttons =================== */
    
    @IBAction func openMenu(_ sender: Any) {
        if menu_open == false{
            UIView.animate(withDuration: 0.4) {
                self.mainMenuView.frame = CGRect(x: 0, y: 70, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
                self.mainMenuView.isHidden = false
                self.menu_open = true
                self.mainMenuBtn.image = UIImage(named: "xmark")
            }
        }else{
            UIView.animate(withDuration: 0.6) {
                self.mainMenuBtn.image = UIImage(named: "line.horizontal.3")
                self.mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: 0, height: 0)
                self.mainMenuView.isHidden = true
                self.menu_open = false
                
            }
        }
    }
    
    
    @IBAction func openMainMenu(_ sender: Any) {
        if menu_open == false{
            UIView.animate(withDuration: 0.4) {
                self.mainMenuView.frame = CGRect(x: 0, y: 70, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
                self.mainMenuView.isHidden = false
                self.menu_open = true
                self.mainMenuBtn.image = UIImage(named: "xmark")
            }
        }else{
            UIView.animate(withDuration: 0.6) {
                self.mainMenuBtn.image = UIImage(named: "line.horizontal.3")
                self.mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: 0, height: 0)
                self.mainMenuView.isHidden = true
                self.menu_open = false
                
            }
        }
    }
    
    @IBAction func openImage(_ sender: Any) {
        dashboardData = AppInfoData.addAppInfo(sectionName: "Images",sectionID:"4")
        
        let storyboard = UIStoryboard(name: "Note", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func openVideo(_ sender: Any) {
        dashboardData = AppInfoData.addAppInfo(sectionName: "Videos",sectionID:"2")
        
        let storyboard = UIStoryboard(name: "Note", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func openAudio(_ sender: Any) {
       dashboardData = AppInfoData.addAppInfo(sectionName: "Audios",sectionID:"3")
        
        let storyboard = UIStoryboard(name: "Note", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func allFolders(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Folders", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "folders_vc") as! FoldersViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func reminders(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Reminder", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "reminder_vc") as! ReminderViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    
    @IBAction func goToDashboard(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
        
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrDataMenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MainMenuCell") as! MainMenuTableViewCell
        cell.menuIcon.image = arrDataMenu[indexPath.row].img
        cell.menuNameLabel.text = arrDataMenu[indexPath.row].title
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let type = indexPath.row
        
        switch type {
        
        case (0):
            
            dashboardData = AppInfoData.addAppInfo(sectionName: "Notes",sectionID:"1")
            
            
            let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
            mainMenuView.isHidden = false
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
            
        case (1):
            
            let storyboard = UIStoryboard(name: "MyBookmarks", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "bookmark_vc") as! BookmarkViewController
            mainMenuView.isHidden = false
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
        case (2):
            print("Change Password View")
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            let destinationVC = storyboard?.instantiateViewController(withIdentifier: "change_pass") as? ChangePasswordViewController
            show(destinationVC!, sender: self)
            
        case (3):
            print("support View")
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            let destinationVC = storyboard?.instantiateViewController(withIdentifier: "support") as? SupportViewController
            show(destinationVC!, sender: self)
            
        case (4):
            
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            let destinationVC = storyboard?.instantiateViewController(withIdentifier: "faq") as? FAQViewController
            show(destinationVC!, sender: self)
            
        case (5):
            
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            let destinationVC = storyboard?.instantiateViewController(withIdentifier: "subscription_vc") as? SubscriptionViewController
            show(destinationVC!, sender: self)
            
            
        case (6):
            let defaults = UserDefaults.standard
            defaults.set(false, forKey: "isLogged")
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "login_vc") as! ViewController
            
            UIApplication.shared.windows.first?.rootViewController = nextViewController
            
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
        default:
            dashboardData = AppInfoData.addAppInfo(sectionName: "",sectionID:"")
        }
        
    }
    
}
