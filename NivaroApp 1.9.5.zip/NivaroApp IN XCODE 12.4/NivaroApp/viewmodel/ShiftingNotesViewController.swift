//
//  ShiftingNotesViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 31/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class ShiftingNotesViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {

    // Swip Folder Data
    var shiftingValue   : [Any] = []
    var shiftingFolders : [Any] = []
    
    let user_id       = UserDefaults.standard.string(forKey: "userID")
    var noteID        = ""
   
    var sectionID     = ""
    
    @IBOutlet weak var swipFolderTableView: UITableView!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        getAllFolderOfSection(sectionID: sectionID)
        swipFolderTableView.delegate = self
        swipFolderTableView.dataSource = self
        // Do any additional setup after loading the view.
        swipFolderTableView.tableFooterView = UIView()
    }
    
    
    func getAllFolderOfSection(sectionID:String){
        
        var item : [Any] = []
        var klik : [Any] = []
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/Show_folder_by_section/")!)
        request.httpMethod  = "POST"
        let postString      = "control=show_sec_folder&userID=\(user_id!)&sectionID=\(sectionID)"
        request.httpBody    = postString.data(using: .utf8)
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                print ("error")
            }else{
                if let urlContent = data{
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                
                                if let content = json["data"] as? [[String:Any]] {
                                    for category in content{
                                        let folderID    =   category["folderID"]!
                                        let name        =   category["name"]!
                                        
                                        item.append(name)
                                        klik.append(folderID)
                                    }
                                    DispatchQueue.main.async {
                                        self.shiftingFolders = item
                                        self.shiftingValue   = klik
                                        self.swipFolderTableView.reloadData()
                                    }
                                }// json Conversion close for data
                            }else{
                                let message = "No Any Data Found"
                                let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
                                self.present(alert, animated: true)
                                // duration in seconds
                                let duration: Double = 3
                                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + duration) {
                                    alert.dismiss(animated: true)
                                }
                            }// Close Status conversion OF Result
                        }
                    } catch let error {
                        print(error.localizedDescription)
                    }// Do And Catch Close
                }// URL Content CLose
            }//Task Control Close
        }
        task.resume()
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shiftingFolders.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = swipFolderTableView.dequeueReusableCell(withIdentifier: "sfnCell", for: indexPath) as! SwipFolderNoteTableViewCell
        cell.labelName.text  = shiftingFolders[indexPath.row] as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let folderSelect = shiftingValue[indexPath.row] as! String
        
        print("Note ID = \(noteID)")
        // move note api call
        var request         = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/move_notes/")!)
        request.httpMethod  = "POST"
        let postString      = "userID=\(user_id!)&noteID=\(noteID)&control=move_notes&folderID=\(folderSelect)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                DispatchQueue.main.async {
                                    let message = json["message"] as! String
                                    let alert = UIAlertController(title: "Nivaro Success", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }else{
                                DispatchQueue.main.async {
                                    let message = "Can't Move Note Now. Try Later."
                                    let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    }catch let error {
                       
                        let err = (error.localizedDescription)
                        let message = err
                        DispatchQueue.main.async {
                            let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }
            }
        }
        task.resume()
        
        dismissController()
    }
    
    func dismissController() {
        DispatchQueue.main.async {
            self.navigationController?.popViewController(animated: true)
            self.dismiss(animated: true, completion: nil)
        }
    }
 

}
