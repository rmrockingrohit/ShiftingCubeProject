//
//  ReminderViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 20/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit
import UserNotifications

class ReminderViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource{
    
    
    
    var spiner            = UIActivityIndicatorView()
    var dashboardData     = [AppInfoDelegete]()
    var arrDataMenu       = [MainMenuModel]()
    var allNotification   = [Notifications]()
    var countNotification = 0
    
    var notificationTitle : [Any] = []
    var identifires       : [Any] = []
    var dateTimes         : [Any] = []
    var notificationTxt   : [Any] = []
    
    var menu_open         :Bool = false
    
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var mainMenuView: UIView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var mainMenuBtn: UIBarButtonItem!
    @IBOutlet weak var menuTableView: UITableView!
    @IBOutlet weak var editProfile: UIButton!
    
    // getting user defaults
    let userID     = UserDefaults.standard.string(forKey: "userID")
    let usersName  = UserDefaults.standard.string(forKey: "UserName")
    
    override func viewDidLoad() {
        
        UNUserNotificationCenter.current().removeAllDeliveredNotifications()
        
        editProfile.isHidden = true
        
        let navBar = self.navigationController?.navigationBar
        
        navBar?.barTintColor = UIColor(hex: "#D35400")
        
        navBar?.tintColor = UIColor.white
        
        navBar?.isTranslucent = false
        
        navBar?.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
        super.viewDidLoad()
        
        //tableView.tableFooterView = UIView()
        
        mainMenuView.isHidden = true
        
        mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
        
        getPendingNotifications()
        
        arrDataMenu = MainMenuData.getMain()
        
        userNameLabel.text = usersName
        
        menu_open = false
        
        collectionView.delegate = self
        collectionView.dataSource = self
    }
    
    func getPendingNotifications(){
        let center = UNUserNotificationCenter.current()
        
        center.getPendingNotificationRequests { (notifications) in
            for item in notifications {
                if let trigger = item.trigger as? UNCalendarNotificationTrigger,
                   let triggerDate = trigger.nextTriggerDate(){
                    self.dateTimes.append(triggerDate)
               }
                self.identifires.append(item.identifier)
                self.notificationTitle.append(item.content.title)
                self.notificationTxt.append(item.content.body)
            }
        }
    }
    
    @objc func reload() {
        identifires.removeAll()
        notificationTxt.removeAll()
        notificationTitle.removeAll()
        
        let center = UNUserNotificationCenter.current()
        
        center.getPendingNotificationRequests { (notifications) in
            for item in notifications {
                if let trigger = item.trigger as? UNCalendarNotificationTrigger,
                   let triggerDate = trigger.nextTriggerDate(){
                    self.dateTimes.append(triggerDate)
               }
                self.identifires.append(item.identifier)
                self.notificationTitle.append(item.content.title)
                self.notificationTxt.append(item.content.body)
            }
        }
        DispatchQueue.main.async {
            self.collectionView.reloadData()
        }
       
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return arrDataMenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            
        let cell = tableView.dequeueReusableCell(withIdentifier: "MainMenuCell") as! MainMenuTableViewCell
        cell.menuIcon.image = arrDataMenu[indexPath.row].img
        cell.menuNameLabel.text = arrDataMenu[indexPath.row].title
        
        return cell
            
    }
    
    @objc func dropDownMenu(indexPath:Int){
        
        let identifire = identifires[indexPath] as! String
        let setDate    = dateTimes[indexPath] as! Date
        
        let alert = UIAlertController(title: "Pending Notification Options", message: "Please Select an Option", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Edit Scheduler", style: .default , handler:{ (UIAlertAction)in
            
            self.setDateTime(identifire: identifire,indexPath:indexPath,date:setDate)
            
        }))
        
        alert.addAction(UIAlertAction(title: "Delete Scheduler", style: .default , handler:{ (UIAlertAction)in
            self.confirminationAlertWithIdentifire(identifire: identifire)
            
        }))
        
        alert.addAction(UIAlertAction(title: "Dismiss", style: .destructive, handler:nil))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    func confirminationAlertWithIdentifire(identifire:String) {
        
        let alert = UIAlertController(title: "Confirm Delete?", message: "Are you sure to delete this Notification?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil))
        
        alert.addAction(UIAlertAction(title: NSLocalizedString("Delete", comment: "Default action"), style: UIAlertAction.Style.default, handler: { _ in
            self.deleteNotification(identifire: identifire)
            self.successAlert(message: "Notification Deleted Successfully", title: "Nivaro Success")
            
            self.identifires.removeAll()
            self.notificationTxt.removeAll()
            self.notificationTitle.removeAll()
            
            let center = UNUserNotificationCenter.current()
            
            center.getPendingNotificationRequests { (notifications) in
                for item in notifications {
                    if let trigger = item.trigger as? UNCalendarNotificationTrigger,
                       let triggerDate = trigger.nextTriggerDate(){
                        self.dateTimes.append(triggerDate)
                   }
                    self.identifires.append(item.identifier)
                    self.notificationTitle.append(item.content.title)
                    self.notificationTxt.append(item.content.body)
                }
            }
            DispatchQueue.main.async {
                self.collectionView.reloadData()
            }
           
        }))
        
        alert.view.tintColor = UIColor.systemRed
        
        self.present(alert, animated: true, completion: nil)
    }
    
    
    func successAlert(message:String,title:String){
        let alert = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if tableView == menuTableView{
            let type = indexPath.row
            
            switch type {
            
            case (0):
                let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
                
                let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
                mainMenuView.isHidden = false
                let navigationController = UINavigationController(rootViewController: nextViewController)
                UIApplication.shared.windows.first?.rootViewController = navigationController
                UIApplication.shared.windows.first?.makeKeyAndVisible()
                
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                }
            case (1):
                
                let storyboard = UIStoryboard(name: "MyBookmarks", bundle: nil)
                
                let nextViewController = storyboard.instantiateViewController(withIdentifier: "bookmark_vc") as! BookmarkViewController
                mainMenuView.isHidden = false
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                }
                show(nextViewController, sender: self)
                
                
                
            case (2):
                let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
                mainMenuView.isHidden = true
                mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
                )
                
                let destinationVC = storyboard.instantiateViewController(withIdentifier: "change_pass") as? ChangePasswordViewController
                show(destinationVC!, sender: self)
                
            case (3):
                let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
                mainMenuView.isHidden = true
                mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
                )
                
                let destinationVC = storyboard.instantiateViewController(withIdentifier: "support") as? SupportViewController
                show(destinationVC!, sender: self)
                
            case (4):
                let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
                mainMenuView.isHidden = true
                mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
                )
                
                let destinationVC = storyboard.instantiateViewController(withIdentifier: "faq") as? FAQViewController
                show(destinationVC!, sender: self)
                
            case (5):
                let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
                mainMenuView.isHidden = true
                mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
                )
                
                let destinationVC = storyboard.instantiateViewController(withIdentifier: "subscription_vc") as? SubscriptionViewController
                show(destinationVC!, sender: self)
                
                
            case (6):
                let defaults = UserDefaults.standard
                defaults.set(false, forKey: "isLogged")
                mainMenuView.isHidden = true
                mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
                )
                
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                }
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                
                let nextViewController = storyboard.instantiateViewController(withIdentifier: "login_vc") as! ViewController
                
                UIApplication.shared.windows.first?.rootViewController = nextViewController
                
                UIApplication.shared.windows.first?.makeKeyAndVisible()
                
            default:
                dashboardData = AppInfoData.addAppInfo(sectionName: "",sectionID:"")
            }
        }
        
    }
    
    
    @IBAction func goToDashboard(_ sender: Any) {
        let storyboard           = UIStoryboard(name: "Dashboard", bundle: nil)
        let nextViewController   = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
        let navigationController = UINavigationController(rootViewController: nextViewController)
        
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
    
    func goToMAinMenu(){
        if menu_open == false{
            UIView.animate(withDuration: 0.4) {
                self.mainMenuView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height - 110)
                self.mainMenuView.isHidden = false
                self.menu_open = true
                self.mainMenuBtn.image = UIImage(named: "xmark")
            }
        }else{
            UIView.animate(withDuration: 0.6) {
                self.mainMenuBtn.image = UIImage(named: "line.horizontal.3")
                self.mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: 0, height: 0)
                self.mainMenuView.isHidden = true
                self.menu_open = false
                
            }
        }
    }
    
    @IBAction func mainMenu(_ sender: Any) {
        goToMAinMenu()
    }
    @IBAction func showMenu(_ sender: Any) {
        goToMAinMenu()
    }
    
    @IBAction func openImage(_ sender: Any) {
        dashboardData            = AppInfoData.addAppInfo(sectionName: "Images",sectionID:"4")
        let storyboard           = UIStoryboard(name: "Note", bundle: nil)
        let nextViewController   = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
        let navigationController = UINavigationController(rootViewController: nextViewController)
        
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func openVideo(_ sender: Any) {
        dashboardData            = AppInfoData.addAppInfo(sectionName: "Videos",sectionID:"2")
        let storyboard           = UIStoryboard(name: "Note", bundle: nil)
        let nextViewController   = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
        let navigationController = UINavigationController(rootViewController: nextViewController)
        
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func openAudio(_ sender: Any) {
        dashboardData            = AppInfoData.addAppInfo(sectionName: "Audios",sectionID:"3")
        let storyboard           = UIStoryboard(name: "Note", bundle: nil)
        let nextViewController   = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
        let navigationController = UINavigationController(rootViewController: nextViewController)
        
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func allFolders(_ sender: Any) {
        let storyboard           = UIStoryboard(name: "Folders", bundle: nil)
        let nextViewController   = storyboard.instantiateViewController(withIdentifier: "folders_vc") as! FoldersViewController
        let navigationController = UINavigationController(rootViewController: nextViewController)
        
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func reminders(_ sender: Any) {
        dashboardData            = AppInfoData.addAppInfo(sectionName: "Reminders",sectionID:"4")
        let storyboard           = UIStoryboard(name: "Reminder", bundle: nil)
        let nextViewController   = storyboard.instantiateViewController(withIdentifier: "reminder_vc") as! ReminderViewController
        let navigationController = UINavigationController(rootViewController: nextViewController)
        
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    
    
    @IBAction func editProfile(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
        mainMenuView.isHidden = true
        mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
        )
        
        let destinationVC = storyboard.instantiateViewController(withIdentifier: "change_pass") as? ChangePasswordViewController
        show(destinationVC!, sender: self)
        
    }
    
    func setDateTime(identifire:String,indexPath:Int,date:Date){
        
        let title = notificationTitle[indexPath] as! String
        let body  = notificationTxt[indexPath] as! String
        let trig  = dateTimes[indexPath] as! Foundation.Date
        
        let myDatePicker: UIDatePicker = UIDatePicker()
        myDatePicker.timeZone = NSTimeZone.local
        myDatePicker.frame = CGRect(x: 30, y: 15, width: 270, height: 200)
        myDatePicker.date = trig
        
        let alertController = UIAlertController(title: "Select Date And Time \n\n\n\n\n\n\n\n", message: nil, preferredStyle: UIAlertController.Style.alert)
        alertController.view.addSubview(myDatePicker)
        
        let somethingAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { alert -> Void in
 
            let dateFormatter = DateFormatter()

            dateFormatter.dateStyle = DateFormatter.Style.short
            dateFormatter.timeStyle = DateFormatter.Style.short

            let strDate        = dateFormatter.string(from: myDatePicker.date)
            let convertDate    = dateFormatter.date(from: strDate)
            
            let center = UNUserNotificationCenter.current()
            
            // schedule new notification
            center.requestAuthorization(options: [.alert, .badge, .sound]) { [self] (granted, error) in
                if granted {
                    self.scheduleNotification(dateString: convertDate!,title:title,body: body, identifire: identifire)
                    
                } else {
                    print("D'oh")
                }
            }
            
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil)
        
        alertController.addAction(somethingAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion:{})
    }
    
    func scheduleNotification(dateString:Date,title:String,body:String,identifire:String) {
        let center    = UNUserNotificationCenter.current()
        let content   = UNMutableNotificationContent()
        content.title = title
        content.body  = body
        content.categoryIdentifier = "alarm"
        content.userInfo = ["customData": "note"]
        content.sound = UNNotificationSound.default
        
        let calendar   = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day, .hour,.minute,.second], from: dateString.addingTimeInterval(2))
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        
        let identifires = UUID().uuidString
        
        let request = UNNotificationRequest(identifier: identifires, content: content, trigger: trigger)
        
        center.add(request, withCompletionHandler: {(error) in
            if error != nil {
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Reminder Error!", message: "Reminder Can't Set", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                
                self.deleteNotification(identifire: identifire)
                let center = UNUserNotificationCenter.current()
                self.identifires.removeAll()
                self.notificationTxt.removeAll()
                self.notificationTitle.removeAll()
                
                var a : [Any] = []
                var b : [Any] = []
                var c : [Any] = []
                var d : [Any] = []
                
                center.getPendingNotificationRequests { (notifications) in
                    for item in notifications {
                        if let trigger = item.trigger as? UNCalendarNotificationTrigger,
                           let triggerDate = trigger.nextTriggerDate(){
                            d.append(triggerDate)
                       }
                        a.append(item.identifier)
                        b.append(item.content.title)
                        c.append(item.content.body)
                    }
                }
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Reminder Set", message: "Reminder Set SuccessFully for '\(title)'", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: {_ in
                        self.identifires       = a
                        self.notificationTitle = b
                        self.notificationTxt   = c
                        self.dateTimes         = d
                        self.collectionView.reloadData()
                    }))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        })
    }
    
    
    func deleteNotification(identifire:String) {
        UNUserNotificationCenter.current().removePendingNotificationRequests(withIdentifiers: ["\(identifire)"])
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return identifires.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let myString = formatter.string(from: dateTimes[indexPath.row] as! Date)
        let yourDate = formatter.date(from: myString)
        formatter.dateFormat = "dd-MMM-yyyy hh:mm:ss a"
        let finelDate = formatter.string(from: yourDate!)
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "reminderCell", for: indexPath) as! ReminderCollectionViewCell
        
        cell.reminderTitle.text     = notificationTitle[indexPath.row] as? String
        cell.timing.text            = finelDate
        cell.options.tag            = indexPath.row
        cell.options.addTarget(self, action: #selector(createOptions), for: .touchUpInside)
        return cell
    }
    
    @objc func createOptions(sender:UIButton){
        let indexPathRow = sender.tag
        dropDownMenu(indexPath: indexPathRow)
    }
    
}

extension ReminderViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = UIScreen.main.bounds.width - 30
        return CGSize(width: width, height: 85)
    }
}
