//
//  ViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 11/05/21.
//

import UIKit

class ViewController: UIViewController {
    
    var spiner = UIActivityIndicatorView()
    
    @IBOutlet weak var loginVC: UIView!
    
    @IBOutlet weak var userMail: UITextField!
    
    @IBOutlet weak var userPass: UITextField!
    
    override func viewDidLoad() {
    
        super.viewDidLoad()
        
        if UserDefaults.standard.bool(forKey: "isLogged") == true{
            let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
        }
        
        // Do any additional setup after loading the view.
        
        userMail.textColor = UIColor(named: "lightgray")
        userPass.textColor = UIColor(named: "lightgray")
        
        let navBar = self.navigationController?.navigationBar
        
        navBar?.barTintColor = UIColor.systemRed
        
        navBar?.tintColor = UIColor.white
        
        navBar?.isTranslucent = false
        
        navBar?.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
    }

    @IBAction func signUpBtn(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "SignUp", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "signup_vc") as! SignUpViewController
        
        UIApplication.shared.windows.first?.rootViewController = nextViewController
        
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
    
    @IBAction func forgetPasswordBtn(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Forget", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "forget_vc") as! ForgetViewController
        
        UIApplication.shared.windows.first?.rootViewController = nextViewController
        
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
    
    
    @IBAction func logIn(_ sender: Any) {
        
        let userMailID = userMail.text!
        let password   = userPass.text!
        
        if userMailID == ""{
            
            DispatchQueue.main.async {
                
                let alertController = UIAlertController(title: "Nivaro Error", message: "Please Fill Email-ID", preferredStyle: UIAlertController.Style.alert)
                
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                    self.dismiss(animated: true, completion: nil)
                }))
                
                self.present(alertController, animated: true, completion: nil)
            }
            
        }else if password == ""{
            
            DispatchQueue.main.async {
                
                let alertController = UIAlertController(title: "Nivaro Error", message: "Please Fill Password", preferredStyle: UIAlertController.Style.alert)
                
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                    self.dismiss(animated: true, completion: nil)
                }))
                
                self.present(alertController, animated: true, completion: nil)
            }
            
        }else{
            
            self.view.isUserInteractionEnabled = false
            
            // Running Spiners
            spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
            spiner.center = view.center
            spiner.hidesWhenStopped = true
            spiner.style  = UIActivityIndicatorView.Style.large
            spiner.color  = .orange
            view.addSubview(spiner)
            spiner.startAnimating()
            
            var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/login/")!)
            
            request.httpMethod = "POST"
            
            let postString = "control=login&email=\(userMailID)&password=\(password)"
            
            request.httpBody = postString.data(using: .utf8)
            
            let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                
                if error != nil{
                    
                    DispatchQueue.main.async {
                        
                        self.spiner.stopAnimating()
                        self.view.isUserInteractionEnabled = true
                    }
                    
                    let errors = error?.localizedDescription
                    
                    let alert = UIAlertController(title: "Nivaro Error.", message: errors, preferredStyle: .alert)
                    self.present(alert, animated: true)
                    
                    // duration in seconds
                    let duration: Double = 3
                    
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + duration) {
                        
                        alert.dismiss(animated: true)
                        
                    }
                    
                }else{
                    
                    if let requestData = data {
                        
                        do {
                            var resultMessage : String
                            var resultJson : String
                            
                            let jsonResult = try JSONSerialization.jsonObject(with: requestData, options: JSONSerialization.ReadingOptions.mutableContainers) as! Dictionary<String, AnyObject> // Added "as anyObject" to fix syntax error in Xcode 8 Beta 6
                            
                            resultMessage = jsonResult["message"]! as! String
                            resultJson    = jsonResult["result"]! as! String
                            
                            if resultJson == "false"{
                                
                                DispatchQueue.main.async {
                                    let alertController = UIAlertController(title: "Nivaro Login Error", message: resultMessage, preferredStyle: UIAlertController.Style.alert)
                                    
                                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                                        self.dismiss(animated: true, completion: nil)
                                    }))
                                    
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    self.present(alertController, animated: true, completion: nil)
                                }
                                
                            }else{
                                
                                // Define UserDefault For Data Store In Local Device
                                let defaults = UserDefaults.standard
                                
                                //Getting Response To dataVer Variable
                                if let dataVer  = jsonResult["data"]{
                                    
                                    // Storing Response Data to userData Key
                                    defaults.set(dataVer["userID"] as Any?, forKey: "userID")
                                    defaults.set(dataVer["name"] as Any?, forKey: "UserName")
                                    defaults.set(password, forKey: "loginKey")
                                    
                                    // Setting And Storing Login Info In isLogged Variable
                                    defaults.set(true, forKey: "isLogged")
                                    // Defining the baseUrl For App
                                    defaults.set("https://nivaroapp.nivaro.com.au",forKey: "baseUrl")
                                    defaults.synchronize()
                                    
                                    DispatchQueue.main.async {
                                        self.spiner.stopAnimating()
                                        self.view.isUserInteractionEnabled = true
                                        self.showSecondViewController()
                                    }
                                
                                }else{
                                    let alertController = UIAlertController(title: "Nivaro Login Error", message: "No Data Found", preferredStyle: UIAlertController.Style.alert)
                                    
                                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                                        self.dismiss(animated: true, completion: nil)
                                    }))
                                    
                                    self.present(alertController, animated: true, completion: nil)
                                    
                                }
                            }
                        }catch{
                            self.spiner.stopAnimating()
                            print("JSON Processing Failed")
                            
                        }
                    }// If Close
                    
                }// else closed
                
                
            }// task completed
            
            task.resume()
            
        }
        
    }
    
    func showSecondViewController() {
        let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
}

