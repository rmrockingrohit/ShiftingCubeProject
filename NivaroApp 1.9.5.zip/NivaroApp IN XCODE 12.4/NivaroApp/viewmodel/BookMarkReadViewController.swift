//
//  BookMarkReadViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 19/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class BookMarkReadViewController: UIViewController,UITextViewDelegate {
    
    @IBOutlet weak var navbarItem: UINavigationItem!
    
    @IBOutlet weak var textView: UITextView!
    
    var passVal1 = ""
    var passVal2 = ""
    var passVar3 = ""
    
    // Defing Global Array For Element Fetch
    var folderID    : String = ""
    var userid      : String = ""
    var sectionid   : String = ""
    var strtotime   : String = ""
    var count       : String = ""
    var name        : String = ""
    var imageVal    : String = ""
    var notetxt     : String = ""
    var notepass    : String = ""
    var istagged    : String = ""
    var labelnames  : String = ""
    var iconcolor   : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textView.isHidden = true
        navbarItem.title = passVar3
        // getting Note
        getNote(noteID:passVal1)
        
        if passVal2 == "1"{
            textView.isHidden = false
            textView.attributedText = notetxt.htmlToAttributedString
        }
    }
    
    func getNote(noteID:String){
        
        var folder_ID    : String = ""
        var user_ID      : String = ""
        var name_Val     : String = ""
        
        var section_ID   : String = ""
        var count_Val    : String = ""
       
        //var image_Val    : String = ""
        var note_txt     : String = ""
        var note_pass    : String = ""
        var is_tagged    : String = ""
        var label_names  : String = ""
        var icon_color   : String = ""
        
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/view_note")!)
        request.httpMethod  = "POST"
        let postString      = "noteID=\(noteID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                if let content = json["data"] as? [[String:Any]] {
                                    // Array Collection For Notes
                                    for nt in content{
                                        
                                        let folderIDs  =   nt["noteID"]!
                                        let userIDs    =   nt["userID"]!
                                        let names      =   nt["note_name"]!
                                        let section_ids =  ""
                                        let counts     =   ""
                                        // Add Null For Notes Properties
                                        let noteTextss =   nt["text"]!
                                        let notePass   =   nt["password"]!
                                        let isTag      =   nt["is_taged"]!
                                        let lblName    =   nt["label_name"]!
                                        let icnColor   =   nt["icon_color"]!
                                        
                                        folder_ID = folderIDs as! String
                                        user_ID   = userIDs as! String
                                        name_Val  = names as! String
                                        section_ID = section_ids
                                        count_Val = counts
                                        note_txt = noteTextss as! String
                                        note_pass = notePass as! String
                                        is_tagged = isTag as! String
                                        label_names = lblName as! String
                                        icon_color  = icnColor as! String
                                    }
                                }
                                
                                DispatchQueue.main.async {
                                    self.folderID  = folder_ID
                                    self.userid    = user_ID
                                    self.sectionid = section_ID
                                    self.count     = count_Val
                                    self.name      = name_Val
                                    self.notetxt   = note_txt
                                    self.notepass  = note_pass
                                    self.istagged  = is_tagged
                                    self.labelnames = label_names
                                    self.iconcolor  = icon_color
                                    
                                    self.textView.attributedText = self.notetxt.htmlToAttributedString
                                }
                                
                            }else{
                                print("Responce Error")
                            }
                        }
                    } catch let error {
                        print(error.localizedDescription)
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
}

extension String {
    var htmlToAttributedString: NSAttributedString? {
        guard let data = data(using: .utf8) else { return nil }
        do {
            return try NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding:String.Encoding.utf8.rawValue], documentAttributes: nil)
        } catch {
            return nil
        }
    }
    var htmlToString: String {
        return htmlToAttributedString?.string ?? ""
    }
}
