//
//  NoteReadViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 31/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit
import WebKit
import UserNotifications


class NoteReadViewController: UIViewController,UITextViewDelegate,UNUserNotificationCenterDelegate, WKNavigationDelegate,WKUIDelegate{
    
    var noteID    = ""
    var parentID  = ""
    var navTitle  = ""
    
    var folderID       : String = ""
    var userid         : String = ""
    var html           : String = ""
    var fileID         : String = ""
    var label_name     : String = ""
    var note_name      : String = ""
    var is_taged       : String = ""
    var userID         : String = ""
    var password       : String = ""
    
    
    @IBOutlet weak var webView: WKWebView!
    
    @IBOutlet weak var passwordBArBTN: UIBarButtonItem!
    @IBOutlet weak var bookmarkBarBTN: UIBarButtonItem!
    @IBOutlet weak var navbarTitle: UINavigationItem!
    
    
    let user_id    = UserDefaults.standard.string(forKey: "userID")
    let loginKey   = UserDefaults.standard.string(forKey:"loginKey")
    
    var spiner  = UIActivityIndicatorView()
    let headerString = "<head><meta name='viewport' content='width=device-width, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0, user-scalable=no'></head>"
    
    
    
    @IBOutlet weak var navbarItem: UINavigationBar!
    
    override func viewDidLoad() {
        
        webView.frame = view.bounds
        webView.navigationDelegate = self
        webView.backgroundColor = UIColor.black
        getNoteDetails(noteID: noteID)
        navbarTitle.title = navTitle
        super.viewDidLoad()
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        webView.frame = view.bounds
        webView.navigationDelegate = self
        webView.backgroundColor = UIColor.black
        getNoteDetails(noteID: noteID)
    }
    

    
    func webView(_ webView: WKWebView, decidePolicyFor navigationAction: WKNavigationAction, decisionHandler: @escaping (WKNavigationActionPolicy) -> Void) {
        if navigationAction.navigationType == .linkActivated  {
            if let url = navigationAction.request.url{
                
                let urlString = url.path
                var correctUrl:URL
                
                if urlString.hasPrefix("https://") || urlString.hasPrefix("http://"){
                    correctUrl = NSURL(string: urlString)! as URL
                }else {
                    let correctedURL = "http://\(urlString)"
                    correctUrl = NSURL(string: correctedURL)! as URL
                }
                
                if #available(iOS 10.0, *) {
                    UIApplication.shared.open(correctUrl, options: [:], completionHandler: nil)
                } else {
                    UIApplication.shared.openURL(correctUrl)
                }
            }
        }
        decisionHandler(.allow)
    }
    
    /* Geting Note Information By Note ID */
    func getNoteDetails(noteID:String){
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/view_note/")!)
        request.httpMethod  = "POST"
        let postString      = "noteID=\(noteID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                
                                if let content = json["data"] as? [[String:Any]] {
                                    DispatchQueue.main.async {
                                        self.folderID = content[0]["noteID"] as! String
                                        self.userid   = content[0]["userID"] as! String
                                        self.html     = content[0]["text"] as! String
                                        self.fileID   = content[0]["fileID"] as! String
                                        self.label_name = content[0]["label_name"] as! String
                                        self.note_name  = content[0]["note_name"] as! String
                                        self.is_taged   = content[0]["is_taged"] as! String
                                        self.userID     = content[0]["userID"] as! String
                                        self.password   = content[0]["password"] as? String ?? ""
                                        
                                        
                                        
                                        
                                        if self.is_taged == "true"{
                                            self.bookmarkBarBTN.tintColor  = UIColor.systemRed
                                        }else{
                                            self.bookmarkBarBTN.tintColor  = UIColor.white
                                        }
                                        
                                        if self.password.isEmpty == false {
                                            self.passwordBArBTN.tintColor  = UIColor.systemRed
                                        }else{
                                            self.passwordBArBTN.tintColor  = UIColor.white
                                        }
                                        
                                        //self.fileName.text = self.note_name
                                        self.webView.autoresizingMask = [.flexibleWidth,.flexibleHeight]
                                        self.webView.loadHTMLString(self.headerString + self.html, baseURL: nil)
                                    }
                                }else{
                                    print("JSON DECODE ERROR")
                                }
                            }else{
                                print("Responce Error")
                            }
                        }
                    } catch let error {
                        print(error.localizedDescription)
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    
    /* Edit Note */
    @IBAction func editNote(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Note", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "editor_vc") as! EditorViewController
        nextViewController.noteID = noteID
        show(nextViewController, sender: self)
    }
    
    
    
    /* Share Note */
    @IBAction func shareIT(_ sender: Any) {
//        let items = [self.html.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)]
//        let ac = UIActivityViewController(activityItems: items, applicationActivities: nil)
//        present(ac, animated: true)
        
        //self.convertToPdfFileAndShare()
        
        let pdfData = createPdfFile(printFormatter: webView.viewPrintFormatter())
        pdfData.write(toFile: "/path/to/file", atomically: true)
        
        let ac = UIActivityViewController(activityItems: [pdfData], applicationActivities: nil)
        present(ac, animated: true)
        
    }
    
    func createPdfFile(printFormatter: UIViewPrintFormatter) -> NSData {
        let renderer = UIPrintPageRenderer()
        renderer.addPrintFormatter(printFormatter, startingAtPageAt: 0);
        let paperSize = CGSize(width: self.view.frame.size.width, height: self.view.frame.size.height)
        let printableRect = CGRect(x: 0, y: 0, width: paperSize.width, height: paperSize.height)
        let paperRect = CGRect(x: 0, y: 0, width: paperSize.width, height: paperSize.height);
        renderer.setValue(NSValue(cgRect: paperRect), forKey: "paperRect")
        renderer.setValue(NSValue(cgRect: printableRect), forKey: "printableRect")
        return renderer.printToPDF()
    }
    
    
    
    func convertToPdfFileAndShare(){
        let textMessage = self.html.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
        
        let fmt = UIMarkupTextPrintFormatter(markupText: textMessage)
        
        // 2. Assign print formatter to UIPrintPageRenderer
        let render = UIPrintPageRenderer()
        render.addPrintFormatter(fmt, startingAtPageAt: 0)
        
        // 3. Assign paperRect and printableRect
        let page = CGRect(x: 0, y: 0, width: 595.2, height: 841.8) // A4, 72 dpi
        render.setValue(page, forKey: "paperRect")
        render.setValue(page, forKey: "printableRect")
        
        // 4. Create PDF context and draw
        let pdfData = NSMutableData()
        UIGraphicsBeginPDFContextToData(pdfData, .zero, nil)
        
        for i in 0..<render.numberOfPages {
            UIGraphicsBeginPDFPage();
            render.drawPage(at: i, in: UIGraphicsGetPDFContextBounds())
        }
        
        UIGraphicsEndPDFContext();
        
        // 5. Save PDF file
        guard let outputURL = try? FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false).appendingPathComponent("output").appendingPathExtension("pdf")
            else { fatalError("Destination URL not created") }
        
        pdfData.write(to: outputURL, atomically: true)
        print("open \(outputURL.path)")
        
        if FileManager.default.fileExists(atPath: outputURL.path){
            
            let url = URL(fileURLWithPath: outputURL.path)
            let activityViewController: UIActivityViewController = UIActivityViewController(activityItems: [url], applicationActivities: nil)
            activityViewController.popoverPresentationController?.sourceView=self.view
            
            //If user on iPad
            if UIDevice.current.userInterfaceIdiom == .pad {
                if activityViewController.responds(to: #selector(getter: UIViewController.popoverPresentationController)) {
                }
            }
            present(activityViewController, animated: true, completion: nil)

        }
        else {
            print("document was not found")
        }
        
    }
    
    
    
    /* Tagging Note */
    @IBAction func bookMarkIt(_ sender: Any) {
        if is_taged == "true"{
            let alert = UIAlertController(title: "Bookmark Alert", message: "This Note Is Allredy Bookmarked. Do you want to remove From Bookmark ?", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: { action in
                
                // Remove From Bookmark
                self.taggingNote(tags: "false")
                
            }))
            
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            
            taggingNote(tags: "true")
        }
    }
    
    func taggingNote(tags:String) {
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/add_tag/")!)
        request.httpMethod  = "POST"
        let postString      = "control=tag_note&userID=\(self.userID)&noteID=\(self.noteID)&tags=\(tags)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                }
                
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    self.is_taged   = tags
                                    if self.is_taged == "true"{
                                        self.bookmarkBarBTN.tintColor  = UIColor.systemRed
                                    }else{
                                        self.bookmarkBarBTN.tintColor  = UIColor.white
                                    }
                                }
                            }else{
                                
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    let alert = UIAlertController(title: "Nivaro Error", message: "Server seems busy try later", preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                
                            }
                        }
                    } catch let error {
                        
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: error.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    /* Delete Note */
    
    @IBAction func deleteNote(_ sender: Any) {
        let alert = UIAlertController(title: "Confirm Delete ?", message: "Are You Sure To Delete This Note?", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: { action in
            
            // Remove From Bookmark
            self.deleteNoteNow()
            
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func deleteNoteNow(){
        
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        let deleteID = noteID
        let user_id  = userID
        
        // Calling API
        var request         = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/delete_note/")!)
        request.httpMethod  = "POST"
        let postString      = "userID=\(user_id)&noteID=\(deleteID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let message = "Loading Error. Try again"
                    let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                
                if let urlContent = data{
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                self.spiner.stopAnimating()
                                self.view.isUserInteractionEnabled = true
                                
                                self.dismissController()
                            }else{
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    let message = "No Any Data Found"
                                    let alert = UIAlertController(title: "Nivaro Success", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                        
                    }catch let error {
                        
                        let err = (error.localizedDescription)
                        let message = err
                        DispatchQueue.main.async {
                            
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }
            }
        }
        task.resume()
    }
    
    
    
    /* Add Note Password */
    @IBAction func setPassword(_ sender: Any) {
        var message:String = ""
        if password != ""{
            message = "If You want to remove password leave the password and verify password textbox blank."
        }else{
            message = "all fields are mandatory."
        }
        setNotePassword(message:message)
    }
    
    func setNotePassword(message:String){
        if password != ""{
            
            let alertController = UIAlertController(title: "Update Note Password", message:message, preferredStyle: UIAlertController.Style.alert)
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter Login Password"
            }
            
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter File Password"
            }
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter Verify Password"
            }
            
            let saveAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { [self] alert -> Void in
                
                let loginPassword   = alertController.textFields![0] as UITextField
                let notePassword    = alertController.textFields![1] as UITextField
                let verifyPassword  = alertController.textFields![2] as UITextField
                
                let alertLoginTxt   = loginPassword.text!
                let alertNotePass   = notePassword.text!
                let verifyNotePass  = verifyPassword.text!
                
                if alertLoginTxt != loginKey{
                    let message = "Login Password Not Matched. Try Again."
                    setNotePassword(message:message)
                }else if alertNotePass != verifyNotePass{
                    let message = "Password Not Matched With Verify Password. Password And Verify Password Shuld Be same."
                    setNotePassword(message:message)
                }else{
                    savePasswordForNote(notePass: alertNotePass)
                }
                
            })
            
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler:nil)
            
            alertController.addAction(saveAction)
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true, completion: nil)
            
        }else{
            
            let alertController = UIAlertController(title: "Set Note Password", message: message, preferredStyle: UIAlertController.Style.alert)
            /* Add Text Boxes */
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter Login Password"
            }
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter File Password"
            }
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter Verify Password"
            }
            
            let saveAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { [self] alert -> Void in
                
                let loginPassword   = alertController.textFields![0] as UITextField
                let notePassword    = alertController.textFields![1] as UITextField
                let verifyPassword  = alertController.textFields![2] as UITextField
                
                let alertLoginTxt   = loginPassword.text!
                let alertNotePass   = notePassword.text!
                let verifyNotePass  = verifyPassword.text!
                
                if alertLoginTxt != loginKey{
                    
                    let message = "Login Password Not Matched. Try Again."
                    setNotePassword(message:message)
                    
                }else if alertNotePass.isEmpty{
                    
                    let message = "Password And Verify Password could not be blank. Please enter Password And Verify Password."
                    setNotePassword(message:message)
                    
                }else if alertNotePass != verifyNotePass{
                    
                    let message = "Password Not Matched With Verify Password. Password And Verify Password Shuld Be same."
                    setNotePassword(message:message)
                    
                }else{
                    savePasswordForNote(notePass: alertNotePass)
                }
                
            })
            
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler:nil)
            
            alertController.addAction(saveAction)
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true, completion: nil)
            
        }
    }
    
    
    func savePasswordForNote(notePass:String) {
        
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        //notePasswordSet api call
        var request         = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/SetPassword/")!)
        request.httpMethod  = "POST"
        let postString      = "noteID=\(noteID)&password=\(notePass)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    self.password = notePass
                                    
                                    var titleAlert = ""
                                    if notePass != ""{
                                        self.passwordBArBTN.tintColor  = UIColor.systemRed
                                        titleAlert = "Password Set Successfully"
                                    }else{
                                        self.passwordBArBTN.tintColor  = UIColor.white
                                        titleAlert = "Password Removed Successfully"
                                    }
                                    let message = json["message"] as! String
                                    let alert = UIAlertController(title: titleAlert, message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                
                            }else{
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    let message = "Can't set note password. Please try later."
                                    let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    }catch let error {
                        let err = (error.localizedDescription)
                        let message = err
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }
            }
        }
        task.resume()
        
    }
    
    
    /* Shifting Note to Other Folder */
    
    @IBAction func shiftingNote(_ sender: Any) {
        let displayVC = UIStoryboard(name: "Note", bundle: nil).instantiateViewController(withIdentifier: "shifting_vc") as! ShiftingNotesViewController
        displayVC.noteID = noteID
        displayVC.sectionID  = "1"
        self.present(displayVC, animated: true, completion: nil)
    }
    
    
    
    /* Set Reminder */
    
    @IBAction func setNoteReminder(_ sender: Any) {
        let myDatePicker: UIDatePicker = UIDatePicker()
        // setting properties of the datePicker
        myDatePicker.timeZone = NSTimeZone.local
        myDatePicker.frame = CGRect(x: 30, y: 15, width: 270, height: 200)
        
        let alertController = UIAlertController(title: "Select Date And Time \n\n\n\n\n\n\n\n", message: nil, preferredStyle: UIAlertController.Style.alert)
        alertController.view.addSubview(myDatePicker)
        
        let somethingAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { alert -> Void in
            
            
            let dateFormatter = DateFormatter()
            
            dateFormatter.dateStyle   = DateFormatter.Style.short
            dateFormatter.timeStyle   = DateFormatter.Style.short
            dateFormatter.dateFormat  = "yyyy-MM-dd HH:mm:ss"
            
            let strDate = dateFormatter.string(from: myDatePicker.date)
            let date    = dateFormatter.date(from: strDate)
            
            // Creating Usernotification
            let center = UNUserNotificationCenter.current()
            
            center.requestAuthorization(options: [.alert, .badge, .sound]) { [self] (granted, error) in
                if granted {
                    self.scheduleNotification(dateString: date!,dateInString:strDate)
                } else {
                    print("D'oh")
                }
            }
            
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil)
        
        alertController.addAction(somethingAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion:{})
    }
    
    
    func scheduleNotification(dateString:Date,dateInString:String) {
        
        let center    = UNUserNotificationCenter.current()
        let content   = UNMutableNotificationContent()
        content.title = note_name
        content.body  = html.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
        content.categoryIdentifier = "alarm"
        content.userInfo = ["type": "note","noteID":"\(String(describing: self.html))"]
        content.sound = UNNotificationSound.default
        
        let calendar   = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day, .hour,.minute,.second], from: dateString.addingTimeInterval(2))
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        
        let identifires = UUID().uuidString
        
        let request = UNNotificationRequest(identifier: identifires, content: content, trigger: trigger)
        
        center.add(request, withCompletionHandler: {(error) in
            if error != nil {
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Reminder Error!", message: "Reminder Can't Set", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                
                //let dateFormatter = DateFormatter()
                let saveData = ["identifire":identifires, "title":self.note_name, "body": self.html, "time":dateInString]
                
                DispatchQueue.main.async {
                    
                    NotificationData.notify.save(object:saveData)
                    
                    let alert = UIAlertController(title: "Reminder Set", message: "Reminder Set SuccessFully for '\(self.note_name)'", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        })
    }
    
    
    /* Global Function */
    
    func dismissController() {
        DispatchQueue.main.async {
            self.navigationController?.popViewController(animated: true)
            self.dismiss(animated: true, completion: nil)
        }
    }
}

extension UIPrintPageRenderer {
    func printToPDF() -> NSData {
        let pdfData = NSMutableData()
        UIGraphicsBeginPDFContextToData(pdfData, self.paperRect, nil)
        self.prepare(forDrawingPages: NSMakeRange(0, self.numberOfPages))
        let bounds = UIGraphicsGetPDFContextBounds()
        for i in 0..<self.numberOfPages {
            UIGraphicsBeginPDFPage();
            self.drawPage(at: i, in: bounds)
        }
        UIGraphicsEndPDFContext();
        return pdfData;
    }
}
