//
//  CooseColorViewController.swift
//  NivaroApp
//
//  Created by Rohit Mishra on 29/03/1943 Saka.
//  Copyright © 1943 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class CooseColorViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource {
    
    var colors     : [Any]        = []
    var colorName  : [Any]        = []

    var fileID = ""
    
    var dashboardData    = [AppInfoDelegete]()
    var arrData          = [DashboardModel]()
    let userID           = UserDefaults.standard.string(forKey: "userID")
    
    @IBOutlet weak var collectionViews: UICollectionView!
    
    override func viewDidLoad() {
        getAllColors()
        super.viewDidLoad()
    }
    
    func getAllColors() {
        
        var colorList  :[Any] = []
        var colorNames :[Any] = []
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/show_color/")!)
        request.httpMethod  = "POST"
        let postString      = "control=show_color"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            
                            if let status = json["result"] as? String, status == "true" {
                                if let color  = json["data"] as? [[String:String]] {
                                    
                                    for list in color{
                                        let code = list["code"]!
                                        colorList.append(code)
                                        
                                        let name = list["name"]!
                                        colorNames.append(name)
                                    }
                                    
                                    DispatchQueue.main.async {
                                        self.colors    = colorList
                                        self.colorName = colorNames
                                        self.collectionViews.reloadData()
                                    }
                                    
                                }
                            }else{
                                print(json["message"] as! String)
                            }
                        }
                    } catch let error {
                        print(error.localizedDescription)
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return colors.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "colorCell", for: indexPath) as! ChooseCollectionViewCell
        
        cell.layer.cornerRadius       = 5
        cell.colorLbl.backgroundColor = hexStringToUIColor(hex: colors[indexPath.row] as! String)
        cell.colorNameLbl.text        = (colorName[indexPath.row] as! String)
        
        
        return cell
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        dashboardData   = AppInfoData.getAppInfo()
        //let sectionID   = dashboardData[0].sectionID
        let selectedColor = colors[indexPath.row] as! String
        
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/change_color/")!)
        request.httpMethod  = "POST"
        let postString      = "control=rename_note&userID=\(String(describing: userID!))&noteID=\(fileID)&icon_color=\(selectedColor)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Icon Color", message: error?.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                               print("Color Set Successfully")
                                pageLoad = "yes"
                                DispatchQueue.main.async {
                                    let alert = UIAlertController(title: "Icon Color", message: "Icon Color Changed Successfully", preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                
                            }else{
                                DispatchQueue.main.async {
                                    let alert = UIAlertController(title: "Icon Color Error", message: "Unable To Connect With Server Try Later.", preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            let alert = UIAlertController(title: "Icon Color", message: error.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "Click", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                        
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
        
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()

        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }

        if ((cString.count) != 6) {
            return UIColor.gray
        }

        var rgbValue:UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)

        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    


}
