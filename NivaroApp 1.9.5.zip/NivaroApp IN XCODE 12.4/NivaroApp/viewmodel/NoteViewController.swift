//
//  NoteViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 14/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//
import Foundation
import UIKit
import MediaPlayer
import Alamofire
import MobileCoreServices
import AudioToolbox

public protocol ImagePickerDelegate: class {
    func didSelect(image: UIImage?)
}

public protocol VideoPickerDelegate: class {
    func didSelect(url: URL?)
}

public struct HTTPMethod: RawRepresentable, Equatable, Hashable {
    public static let connect = HTTPMethod(rawValue: "CONNECT")
    public static let delete = HTTPMethod(rawValue: "DELETE")
    public static let get = HTTPMethod(rawValue: "GET")
    public static let head = HTTPMethod(rawValue: "HEAD")
    public static let options = HTTPMethod(rawValue: "OPTIONS")
    public static let patch = HTTPMethod(rawValue: "PATCH")
    public static let post = HTTPMethod(rawValue: "POST")
    public static let put = HTTPMethod(rawValue: "PUT")
    public static let trace = HTTPMethod(rawValue: "TRACE")
    
    public let rawValue: String
    
    public init(rawValue: String) {
        self.rawValue = rawValue
    }
}

var pageLoad : String = "no"

class NoteViewController: UIViewController,UICollectionViewDataSource, UICollectionViewDelegate,UISearchBarDelegate,UITextFieldDelegate,UIImagePickerControllerDelegate, UINavigationControllerDelegate,URLSessionDelegate, URLSessionTaskDelegate, URLSessionDataDelegate,MPMediaPickerControllerDelegate,UITableViewDelegate,UITableViewDataSource, AVAudioRecorderDelegate{
    
    
    // Get Out Let Of View
    @IBOutlet weak var collectionView: UICollectionView!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var navbarItem: UINavigationItem!
    
    @IBOutlet weak var addFileandFolderView: UIView!
    
    @IBOutlet weak var addFilesOrFolderView: UIView!
    
    @IBOutlet weak var addFileOrFolderMainView: UIView!
    
    @IBOutlet weak var addFileOrFolderLabel: UILabel!
    
    @IBOutlet weak var addFolderText: UITextField!
    
    @IBOutlet weak var addFilesLibraryView: UIView!
    
    @IBOutlet weak var mainMenuView: UIView!
    
    @IBOutlet weak var menuTableView: UITableView!
    
    @IBOutlet weak var menuPresentView: UIView!
    
    @IBOutlet weak var userNameLabel: UILabel!
    
    @IBOutlet weak var userInfoView: UIView!
    
    @IBOutlet weak var mainMenuBtn: UIBarButtonItem!
    
    @IBOutlet weak var deleteBtn: UIBarButtonItem!
    
    
    
    
    
    var audioRecorder: AVAudioRecorder!
    var recordButton: UIButton!
    var recordingSession: AVAudioSession!
    
    var menu_open:Bool = false
    
    
    var spiner  = UIActivityIndicatorView()
    
    // getting Dashboard Click Info
    var dashboardData    = [AppInfoDelegete]()
    var arrData          = [DashboardModel]()
    var arrDataMenu      = [MainMenuModel]()
    
    
    let pickerController = UIImagePickerController()
    let mediaPicker      = MPMediaPickerController(mediaTypes:.anyAudio)
    
    // getting user defaults
    let userID     = UserDefaults.standard.string(forKey: "userID")
    let usersName  = UserDefaults.standard.string(forKey: "UserName")
    let loginKey   = UserDefaults.standard.string(forKey:"loginKey")
    
    // Defing Global Array For Element Fetch
    var folderID    : [Any] = []
    var userid      : [Any] = []
    var parentID    : [Any] = []
    var sectionid   : [Any] = []
    var strtotime   : [Any] = []
    var count       : [Any] = []
    var name        : [Any] = []
    var typeVal     : [Any] = []
    var imageVal    : [Any] = []
    var notetxt     : [Any] = []
    var notepass    : [Any] = []
    var istagged    : [Any] = []
    var labelnames  : [Any] = []
    var iconcolor   : [Any] = []
    var noteIDS     : [Any] = []
    
    var countNote   = ""
    var expireSubs : Int? = 0
    
    // Assign Search Variable
    var folderIDSearch     : [Any] = []
    var useridSearch       : [Any] = []
    var parentIDSearch     : [Any] = []
    var sectionidSearch    : [Any] = []
    var strtotimeSearch    : [Any] = []
    var countSearch        : [Any] = []
    var nameSearch         : [Any] = []
    var typeValSearch      : [Any] = []
    var imageValSearch     : [Any] = []
    var notetxtSearch      : [Any] = []
    var notepassSearch     : [Any] = []
    var istaggedSearch     : [Any] = []
    var labelnamesSearch   : [Any] = []
    var iconcolorSearch    : [Any] = []
    
    var uploadItem : URL? = nil
    var pickerImgs : UIImage? = nil
    var videoPath: URL?
    var videoURL : URL?
    
    // Creating A Note Global Var
    var NoteParentCheck = "0"
    var is_parent       = "0"
    var reloadView      = "false"
    
    var screenSize: CGRect!
    var screenWidth: CGFloat!
    var screenHeight: CGFloat!
    
    var video               : Data?     = nil
    var colorIndexPath      : String    = ""
    var checkListForCell    : [String]  = []
    var deleteIndex         : [Int]  = []
    
    
    
    
    @IBOutlet weak var editProfile: UIButton!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        editProfile.isHidden = true
        dashboardData = AppInfoData.getAppInfo()
        let sectionName = dashboardData[0].sectionName
        let sectionID   = dashboardData[0].sectionID
        
        self.navbarItem.title = sectionName
        
        // Customization Of Search Bar Item
        searchBar.searchBarStyle = UISearchBar.Style.prominent
        searchBar.isTranslucent = false
        let textFieldInsideSearchBar = self.searchBar.value(forKey: "searchField") as? UITextField
        textFieldInsideSearchBar?.backgroundColor = UIColor(red: 0 / 255, green: 0 / 255, blue: 0 / 255, alpha: 0.2)
        
        
        self.searchBar.barTintColor  = UIColor(red: 0 / 255, green: 0 / 255, blue: 0 / 255, alpha: 0)
        self.searchBar.layer.cornerRadius = 10.0
        self.searchBar.layer.borderWidth  = 2
        self.searchBar.layer.borderColor  = UIColor(hex: "#D35400")?.cgColor
        
        mainMenuView.isHidden = true
        mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
        arrData = DashboardData.getAllDashboardItem()
        
        arrDataMenu = MainMenuData.getMain()
        
        userNameLabel.text = usersName
        
        
        // Customization Of NavigationBar
        let navBar = self.navigationController?.navigationBar
        
        let tinColor = UIColor(hex: "#D35400")
        
        navBar?.barTintColor = tinColor
        
        navBar?.tintColor = UIColor.white
        
        navBar?.isTranslucent = false
        
        navBar?.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
        
        // Customzation Of UICollectionView And Its Cell
        //self.collectionView.dragInteractionEnabled = true
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        spiner.backgroundColor = UIColor.black
        spiner.alpha = 0.8
        view.addSubview(spiner)
        
        spiner.startAnimating()
        
        self.view.isUserInteractionEnabled = false
        
        // Loading Collection View Contents
        getSectionFolders(userID: userID!, sectionID: sectionID, control: "show_sec_folder")
        
        // Add Folder View Properties
        addFileandFolderView.isHidden = true
        addFileandFolderView.alpha    = 0.0
        
        //Add File Or Folder View Properties
        addFilesOrFolderView.layer.cornerRadius = 10
        addFilesOrFolderView.layer.borderWidth  = 2
        addFilesOrFolderView.layer.borderColor  = CGColor(red: 255/255, green: 10/255, blue: 0, alpha: 1)
        addFileOrFolderMainView.isHidden = true
        addFolderText.layer.borderWidth  = 1.0
        addFolderText.layer.borderColor  = CGColor(red: 255/255, green: 10/255, blue: 0, alpha: 1)
        addFolderText.setLeftPaddingPoints(15)
        addFolderText.setRightPaddingPoints(15)
        
        addFilesLibraryView.isHidden = true
        addFilesLibraryView.layer.borderWidth  = 1.0
        addFilesLibraryView.layer.borderColor  = CGColor(red: 255/255, green: 10/255, blue: 0, alpha: 1)
        
        pickerController.delegate = self
        
        mediaPicker.delegate = self
        mediaPicker.allowsPickingMultipleItems = false
        
        deleteBtn.isEnabled = false
        
        menu_open = false
        
        let longPressedGesture = UILongPressGestureRecognizer(target: self, action: #selector(handleLongPress(gestureRecognizer:)))
        longPressedGesture.minimumPressDuration = 0.3
        longPressedGesture.delegate = self as? UIGestureRecognizerDelegate
        longPressedGesture.delaysTouchesBegan = true
        self.collectionView?.addGestureRecognizer(longPressedGesture)
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        if pageLoad != "no"{
            print("reload Data")
            
            dashboardData = AppInfoData.getAppInfo()
            let sectionID = dashboardData[0].sectionID
            getFolderItemData(userID: userID!, folder_id: is_parent, control: "show_note", sectionID: sectionID)
            
            pageLoad = "no"
        }else{
            print("do not reload")
        }
    }
    
    func reloadDataView(){
        dashboardData = AppInfoData.getAppInfo()
        let sectionID = dashboardData[0].sectionID
        if reloadView == "true"{
            getFolderItemData(userID: userID!, folder_id: is_parent, control: "show_note", sectionID: sectionID)
        }
    }
    /* Long Press Gestures */
    
    @objc func handleLongPress(gestureRecognizer: UILongPressGestureRecognizer) {
        guard let collectionViews = self.collectionView else{
            return
        }
        
        switch gestureRecognizer.state {
        case .began:
            guard let targetPath = self.collectionView.indexPathForItem(at: gestureRecognizer.location(in: self.collectionView)) else{
                return
            }
            self.collectionView.beginInteractiveMovementForItem(at: targetPath)
        case .changed:
            self.collectionView.updateInteractiveMovementTargetPosition(gestureRecognizer.location(in: self.collectionView))
        case .ended :
            collectionViews.endInteractiveMovement()
        default:
            collectionViews.endInteractiveMovement()
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, canMoveItemAt indexPath: IndexPath) -> Bool {
        if ((typeVal[indexPath.row] as? String == "note")){
            if typeVal[indexPath.row] as? String != "note"{
                return false
            }else{
                return true
            }
        }else{
            return false
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, moveItemAt sourceIndexPath: IndexPath, to destinationIndexPath: IndexPath) {
        
        if ((typeVal[sourceIndexPath.row] as? String == "note") && (typeVal[destinationIndexPath.row] as? String == "note")){
            
            let folderid = folderID.remove(at: sourceIndexPath.row)
            folderID.insert(folderid, at: destinationIndexPath.row)
            
            let useriD = userid.remove(at: sourceIndexPath.row)
            userid.insert(useriD, at: destinationIndexPath.row)
            
            let parentid = parentID.remove(at: sourceIndexPath.row)
            parentID.insert(parentid, at: destinationIndexPath.row)
            
            let sectionIDS = sectionid.remove(at: sourceIndexPath.row)
            sectionid.insert(sectionIDS, at: destinationIndexPath.row)
            
            let counts = count.remove(at: sourceIndexPath.row)
            count.insert(counts, at: destinationIndexPath.row)
            
            let names = name.remove(at: sourceIndexPath.row)
            name.insert(names, at: destinationIndexPath.row)
            
            let typeval = typeVal.remove(at: sourceIndexPath.row)
            typeVal.insert(typeval, at: destinationIndexPath.row)
            
            let imageval = imageVal.remove(at: sourceIndexPath.row)
            imageVal.insert(imageval, at: destinationIndexPath.row)
            
            let notetxts = notetxt.remove(at: sourceIndexPath.row)
            notetxt.insert(notetxts, at: destinationIndexPath.row)
            
            let notepasss = notepass.remove(at: sourceIndexPath.row)
            notepass.insert(notepasss, at: destinationIndexPath.row)
            
            let istaggeds = istagged.remove(at: sourceIndexPath.row)
            istagged.insert(istaggeds, at: destinationIndexPath.row)
            
            let labelnamess = labelnames.remove(at: sourceIndexPath.row)
            labelnames.insert(labelnamess, at: destinationIndexPath.row)
            
            let iconcolors = iconcolor.remove(at: sourceIndexPath.row)
            iconcolor.insert(iconcolors, at: destinationIndexPath.row)
            
            let allNoteID = noteIDS.remove(at: sourceIndexPath.row)
            noteIDS.insert(allNoteID, at: destinationIndexPath.row)
            
            let farray  = noteIDS.filter {$0 as! String != "*"}
            let jsonArr = self.json(from: farray)
            updateNoteMove(userID:self.userID!,arr:jsonArr!)
        }else{
            pageLoad = "yes"
            self.reloadDataView()
            let alert = UIAlertController(title: "Nivaro Swapping Warning", message: "Note can't swap with folder.Please swap file with file", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
            
        }
    }
    
    func updateNoteMove(userID:String,arr:String){
        let indicator: UIActivityIndicatorView = UIActivityIndicatorView(style: UIActivityIndicatorView.Style.gray)
        indicator.frame = CGRect(x: 0, y: 0, width: 40, height: 40)
        indicator.center = view.center
        self.view.addSubview(indicator)
        self.view.bringSubviewToFront(indicator)
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/Move_note_position")!)
        request.httpMethod  = "POST"
        let postString      = "control=move_notes_position&userID=\(userID)&noteID=\(arr)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
                
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                DispatchQueue.main.async {
                                    self.collectionView.reloadData()
                                }
                            }else{
                                DispatchQueue.main.async {
                                    self.collectionView.reloadData()
                                }
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                        
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    /* Long Press Gusture Closed */
    
    // COLLECTION VIEW CELL PROPERTIES
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        
        return folderID.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "parentNoteCell", for: indexPath) as! NotesCollectionViewCell
        
        // ------------ Empty all Checkbox Array
        self.checkListForCell.removeAll()
        self.deleteIndex.removeAll()
        
        //############################# CELL PROPERTIES FOR EACH CELL
        cell.layer.cornerRadius    = 5
        cell.layer.borderWidth     = 2.0
        cell.layer.borderColor     = UIColor(hex: "#D35400")?.cgColor
        cell.layer.backgroundColor = UIColor(hex: "#D35400")?.cgColor
        
        
        //############################## Storing Parent ID In is_parent variable
        is_parent = parentID[indexPath.row] as! String
        let sectionID   = dashboardData[0].sectionID
        
        //############################## DEFINE CELLS OBJECTS
        cell.imagePreview.isHidden  = true
        cell.colorBox.isHidden      = true
        cell.labelName.isHidden     = true
        cell.checkBox.isHidden      = true
        
        //############################## IF PARENT FOLDER
        if is_parent == "0"{
            
            cell.cellImage.image        = UIImage(named: "folder.fill")
            cell.cellLabel.text         = name[indexPath.row] as? String
            
            cell.colorBox.isHidden = true
            cell.checkBox.isHidden = true
            deleteBtn.isEnabled    = false
            
        }else{ //######################## ELSE FOLDERS DATA
            
            deleteBtn.isEnabled = true
            
            //########################### IF FOLDER IN SUB FOLDER
            if typeVal[indexPath.row] as! String == "folder"{
                cell.cellImage.image       = imageVal[indexPath.row] as? UIImage
                cell.cellImage.isHidden    = false
            }else{
                //###################### IF FILE IN SUB FOLDER
                cell.colorBox.isHidden = false
                cell.checkBox.isHidden = false
                var color:UIColor?
                
                //############### ICON COLOR MANAGEMENT FOR CELL ########
                if iconcolor[indexPath.row] as! String != ""{
                    
                    color = hexStringToUIColor(hex:iconcolor[indexPath.row] as! String)
                    cell.colorBox.setBackgroundImage(UIImage(named:"largecircle.fill.circle"), for: .normal)
                    //cell.colorBox.tintColor = .lightGray
                    
                }else{
                    
                    color = UIColor.link
                    cell.colorBox.setBackgroundImage(UIImage(systemName: "circle.dashed"), for: .normal)
                    //cell.colorBox.tintColor = .lightGray
                }
                
                cell.colorBox.tintColor = color
                cell.colorBox.addTarget(self, action: #selector(editButtonTapped), for: UIControl.Event.touchUpInside)
                
                //############## Cell CHECKBOX Setup########################
                
                cell.checkBox.addTarget(self, action: #selector(cellCheckBox), for: UIControl.Event.touchUpInside)
                
                if self.checkListForCell.isEmpty{
                    cell.checkBox.setBackgroundImage(UIImage(named: "square"), for: .normal)
                }else{
                    cell.checkBox.setBackgroundImage(UIImage(named: "checkmark.square.fill"), for: .normal)
                }
                
                cell.labelName.isHidden    = true
                
                //########################## IF FILE IS PASSWORD PROTECTED
                if notepass[indexPath.row] as! String != ""{
                    
                    cell.cellImage.image     = UIImage(named: "lock.doc.fill")
                    
                    if labelnames[indexPath.row] as! String != ""{
                        cell.labelName.isHidden = false
                        cell.labelName.text      = labelnames[indexPath.row] as? String
                    }
                    
                }else{
                    if sectionID == "4"{
                        //cell.cellImage.isHidden     = true
                        cell.imagePreview.isHidden  = false
                        cell.imagePreview.image     = imageVal[indexPath.row] as? UIImage
                    }else{
                        cell.imagePreview.isHidden  = true
                        cell.cellImage.image        = imageVal[indexPath.row] as? UIImage
                        cell.cellImage.isHidden     = false
                    }
                    
                    if labelnames[indexPath.row] as! String != ""{
                        cell.labelName.isHidden = false
                        cell.labelName.text      = labelnames[indexPath.row] as? String
                    }
                }
            }
            cell.cellLabel.text   = name[indexPath.row] as? String
        }
        return cell
    }
    
    func hexStringToUIColor (hex:String) -> UIColor {
        var cString:String = hex.trimmingCharacters(in: .whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString.remove(at: cString.startIndex)
        }
        
        if ((cString.count) != 6) {
            return UIColor.gray
        }
        
        var rgbValue:UInt64 = 0
        Scanner(string: cString).scanHexInt64(&rgbValue)
        
        return UIColor(
            red: CGFloat((rgbValue & 0xFF0000) >> 16) / 255.0,
            green: CGFloat((rgbValue & 0x00FF00) >> 8) / 255.0,
            blue: CGFloat(rgbValue & 0x0000FF) / 255.0,
            alpha: CGFloat(1.0)
        )
    }
    
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        let cell_name   = name[indexPath.row] as! String
        let clickedCell = folderID[indexPath.row] as! String
        let type        = typeVal[indexPath.row] as! String
        let sectionID   = dashboardData[0].sectionID
        
        if type == "folder"{
            navbarItem.title = cell_name
            // Create Click Item As PArent
            folderID.removeAll()
            userid.removeAll()
            parentID.removeAll()
            sectionid.removeAll()
            count.removeAll()
            name.removeAll()
            typeVal.removeAll()
            imageVal.removeAll()
            notetxt.removeAll()
            notepass.removeAll()
            istagged.removeAll()
            labelnames.removeAll()
            iconcolor.removeAll()
            
            // Get Folder Clik Data From API
            getFolderItemData(userID: userID!, folder_id: clickedCell, control: "show_note",sectionID:sectionID)
            
        }else{
            
            // Checking For Password Protection Files
            if notepass[indexPath.row] as! String != ""{
                
                let alertController = UIAlertController(title: "Please enter \(cell_name)'s password", message: "This file is password protected.", preferredStyle: UIAlertController.Style.alert)
                alertController.addTextField { (textField : UITextField!) -> Void in
                    textField.placeholder = "Enter File Password"
                }
                
                let saveAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { [self] alert -> Void in
                    
                    let firstTextField = alertController.textFields![0] as UITextField
                    let passwordField  = firstTextField.text!
                    
                    if passwordField   !=  notepass[indexPath.row] as! String{
                        
                        let alert = UIAlertController(title: "File Password Error!", message: "Password Not Matched. Try Again.", preferredStyle: .alert)
                        self.present(alert, animated: true, completion: nil)
                        
                        // change to desired number of seconds (in this case 5 seconds)
                        let when = DispatchTime.now() + 3
                        DispatchQueue.main.asyncAfter(deadline: when){
                            // your code with delay
                            alert.dismiss(animated: true, completion: nil)
                        }
                        
                    }else{
                        
                        if sectionID == "1"{
                            
                            let storyboard       = UIStoryboard(name: "Note", bundle: nil)
                            let secondVC        = storyboard.instantiateViewController(withIdentifier: "noteRead_vc") as! NoteReadViewController
                            secondVC.noteID      = folderID[indexPath.row] as! String
                            secondVC.parentID    = parentID[indexPath.row] as! String
                            secondVC.navTitle    = name[indexPath.row] as! String
                            
                            show(secondVC, sender: self)
                            
                        }else if sectionID == "4"{
                            
                            let storyboard = UIStoryboard(name: "Note", bundle: nil)
                            let secondVC = storyboard.instantiateViewController(withIdentifier: "showImage_vc")as! ImagePreviewViewController
                            
                            secondVC.mainFolderID     = is_parent
                            secondVC.sectionID        = "4"
                            secondVC.clikedID         = folderID[indexPath.row] as! String
                            secondVC.folderTitle      = name[indexPath.row] as! String
                            show(secondVC, sender: self)
                            
                        }else if sectionID == "2"{
                            let storyboard = UIStoryboard(name: "Note", bundle: nil)
                            let secondVC = storyboard.instantiateViewController(withIdentifier: "showVideo_vc")as! ShowVideoViewController
                            
                            secondVC.noteID      = folderID[indexPath.row] as! String
                            secondVC.parentID    = parentID[indexPath.row] as! String
                            secondVC.nameImg     = name[indexPath.row] as! String
                            secondVC.videoUrl    = notetxt[indexPath.row] as! String
                            secondVC.sections    = "2"
                            
                            show(secondVC, sender: self)
                            
                        }else if sectionID == "3"{
                            let storyboard = UIStoryboard(name: "Note", bundle: nil)
                            let secondVC = storyboard.instantiateViewController(withIdentifier: "showVideo_vc")as! ShowVideoViewController
                            
                            secondVC.noteID      = folderID[indexPath.row] as! String
                            secondVC.parentID    = parentID[indexPath.row] as! String
                            secondVC.nameImg     = name[indexPath.row] as! String
                            secondVC.videoUrl    = notetxt[indexPath.row] as! String
                            secondVC.sections    = "3"
                            
                            show(secondVC, sender: self)
                        }
                        
                    }
                    
                })
                let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler:nil)
                
                alertController.addAction(saveAction)
                alertController.addAction(cancelAction)
                alertController.addAction(UIAlertAction(title: "Forget Password", style: UIAlertAction.Style.default, handler:{ [self] alert -> Void in
                    forgetFilePassword(fileID:folderID[indexPath.row] as! String,fileName:name[indexPath.row] as! String, message: "Update New File Password", indexPath: indexPath.row)
                }
                
                ))
                
                self.present(alertController, animated: true, completion: nil)
                
            }else{
                
                if sectionID == "1"{
                    
                    let storyboard       = UIStoryboard(name: "Note", bundle: nil)
                    let secondVC        = storyboard.instantiateViewController(withIdentifier: "noteRead_vc") as! NoteReadViewController
                    
                    secondVC.noteID      = folderID[indexPath.row] as! String
                    secondVC.parentID    = parentID[indexPath.row] as! String
                    secondVC.navTitle    = name[indexPath.row] as! String
                    show(secondVC, sender: self)
                    
                }else if sectionID == "4"{
                    
                    let storyboard = UIStoryboard(name: "Note", bundle: nil)
                    let secondVC = storyboard.instantiateViewController(withIdentifier: "showImage_vc")as! ImagePreviewViewController
                    
                    secondVC.mainFolderID     = is_parent
                    secondVC.sectionID        = "4"
                    secondVC.clikedID         = folderID[indexPath.row] as! String
                    secondVC.folderTitle      = name[indexPath.row] as! String
                    show(secondVC, sender: self)
                    
                }else if sectionID == "2"{
                    let storyboard = UIStoryboard(name: "Note", bundle: nil)
                    let secondVC = storyboard.instantiateViewController(withIdentifier: "showVideo_vc")as! ShowVideoViewController
                    
                    secondVC.noteID      = folderID[indexPath.row] as! String
                    secondVC.parentID    = parentID[indexPath.row] as! String
                    secondVC.nameImg     = name[indexPath.row] as! String
                    secondVC.videoUrl    = notetxt[indexPath.row] as! String
                    secondVC.sections    = "2"
                    
                    show(secondVC, sender: self)
                    
                }else if sectionID == "3"{
                    let storyboard = UIStoryboard(name: "Note", bundle: nil)
                    let secondVC = storyboard.instantiateViewController(withIdentifier: "showVideo_vc")as! ShowVideoViewController
                    
                    secondVC.noteID      = folderID[indexPath.row] as! String
                    secondVC.parentID    = parentID[indexPath.row] as! String
                    secondVC.nameImg     = name[indexPath.row] as! String
                    secondVC.videoUrl    = notetxt[indexPath.row] as! String
                    secondVC.sections    = "3"
                    
                    show(secondVC, sender: self)
                }
            }
        }
    }
    
    @objc func editButtonTapped(_ sender: Any){
        
        guard let cell = (sender as AnyObject).superview?.superview as? UICollectionViewCell else {
            return // or fatalError() or whatever
        }
        
        let indexPath = collectionView.indexPath(for: cell)
        let storyboard = UIStoryboard(name: "Note", bundle: nil)
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "choose_color") as! CooseColorViewController
        nextViewController.fileID = folderID[indexPath!.row] as! String
        show(nextViewController, sender: self)
        
    }
    
    @objc func cellCheckBox(_ sender: Any){
        
        let convertedPoint : CGPoint = (sender as AnyObject).convert(CGPoint.zero, to: self.collectionView)
        
        let indexPath = self.collectionView.indexPathForItem(at: convertedPoint)
        
        let cell = self.collectionView.cellForItem(at: indexPath!) as! NotesCollectionViewCell
        
        if self.checkListForCell.contains(folderID[indexPath!.row] as! String){
            cell.checkBox.setBackgroundImage(UIImage(named: "square"), for: .normal)
            self.checkListForCell = self.checkListForCell.filter(){
                $0 != folderID[indexPath!.row] as! String
            }
            
            self.deleteIndex = self.deleteIndex.filter(){
                $0 != indexPath!.row
            }
            
            cell.checkBox.tintColor = UIColor(hex: "#D35400")
            
        }else{
            self.deleteIndex.append(indexPath!.row)
            self.checkListForCell.append(folderID[indexPath!.row] as! String)
            cell.checkBox.setBackgroundImage(UIImage(named: "checkmark.square.fill"), for: .normal)
            cell.checkBox.tintColor = UIColor(hex: "#D35400")
            
        }
    }
    
    func forgetFilePassword(fileID:String,fileName:String,message:String,indexPath:Int){
        let alertController = UIAlertController(title: "Forget Password", message:message, preferredStyle: UIAlertController.Style.alert)
        /* Add Text Boxes */
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter Login Password"
        }
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter New Password"
        }
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter Verify New Password"
        }
        
        let saveAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { [self] alert -> Void in
            
            let loginPassword   = alertController.textFields![0] as UITextField
            let notePassword    = alertController.textFields![1] as UITextField
            let verifyPassword  = alertController.textFields![2] as UITextField
            
            let alertLoginTxt   = loginPassword.text!
            let alertNotePass   = notePassword.text!
            let verifyNotePass  = verifyPassword.text!
            
            if alertLoginTxt != loginKey{
                
                let messageTxt = "Login Password Not Matched. Try Again."
                forgetFilePassword(fileID: fileID, fileName: fileName, message: messageTxt, indexPath: indexPath)
                
            }else if alertNotePass.isEmpty{
                
                let messageTxt = "Password And Verify Password could not be blank. Please enter Password And Verify Password."
                forgetFilePassword(fileID: fileID, fileName: fileName, message: messageTxt, indexPath: indexPath)
                
            }else if alertNotePass != verifyNotePass{
                
                let messageTxt = "Password Not Matched With Verify Password. Password And Verify Password Shuld Be same."
                forgetFilePassword(fileID: fileID, fileName: fileName, message: messageTxt, indexPath: indexPath)
                
            }else{
                savePasswordForNote(notePass: alertNotePass, noteID: fileID, indexPath: indexPath)
            }
            
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler:nil)
        
        alertController.addAction(saveAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    @IBAction func deleteFiles(_ sender: Any) {
        if self.checkListForCell.isEmpty != false{
            let alert = UIAlertController(title: "No Any File Selected", message: "Please Select File and Then Press Delete", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            let alert = UIAlertController(title: "Are You Sure To Delete File", message: "", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { action in
                
                let selectedStrings = self.json(from: self.checkListForCell)
                self.checkListForCell.removeAll()
                self.deleteNotesApiCall(userID: self.userID!, noteID: selectedStrings!)
                
            }))
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }
        
    }
    
    func json(from object:Any) -> String? {
        guard let data = try? JSONSerialization.data(withJSONObject: object, options: []) else {
            return nil
        }
        return String(data: data, encoding: String.Encoding.utf8)
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        return arrDataMenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MainMenuCell") as! MainMenuTableViewCell
        cell.menuIcon.image = arrDataMenu[indexPath.row].img
        cell.menuNameLabel.text = arrDataMenu[indexPath.row].title
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let type = indexPath.row
        
        switch type {
        
        case (0):
            let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
            mainMenuView.isHidden = false
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
        case (1):
            
            let storyboard = UIStoryboard(name: "MyBookmarks", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "bookmark_vc") as! BookmarkViewController
            mainMenuView.isHidden = false
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            show(nextViewController, sender: self)
            
            
            
        case (2):
            let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            let destinationVC = storyboard.instantiateViewController(withIdentifier: "change_pass") as? ChangePasswordViewController
            show(destinationVC!, sender: self)
            
        case (3):
            let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            let destinationVC = storyboard.instantiateViewController(withIdentifier: "support") as? SupportViewController
            show(destinationVC!, sender: self)
            
        case (4):
            let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            let destinationVC = storyboard.instantiateViewController(withIdentifier: "faq") as? FAQViewController
            show(destinationVC!, sender: self)
            
        case (5):
            let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            let destinationVC = storyboard.instantiateViewController(withIdentifier: "subscription_vc") as? SubscriptionViewController
            show(destinationVC!, sender: self)
            
            
        case (6):
            let defaults = UserDefaults.standard
            defaults.set(false, forKey: "isLogged")
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "login_vc") as! ViewController
            
            UIApplication.shared.windows.first?.rootViewController = nextViewController
            
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
        default:
            dashboardData = AppInfoData.addAppInfo(sectionName: "",sectionID:"")
        }
        
    }
    
    // SEARCH BAR PROPERTIES
    
    func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
        
        
        if (searchBar.text!.isEmpty){
            self.folderID   = self.folderIDSearch
            self.userid     = self.useridSearch
            self.parentID   = self.parentIDSearch
            self.sectionid  = self.sectionidSearch
            self.count      = self.countSearch
            self.name       = self.nameSearch
            self.typeVal    = self.typeValSearch
            self.imageVal   = self.imageValSearch
            self.notetxt    = self.notetxtSearch
            self.notepass   = self.notepassSearch
            self.istagged   = self.istaggedSearch
            self.labelnames = self.labelnamesSearch
            self.iconcolor  = self.iconcolorSearch
        }else{
            var nameValSearch    : [Any] = []
            var folderValSearch  : [Any] = []
            var userValSearch    : [Any] = []
            var parentValSearch  : [Any] = []
            var sectionValSearch : [Any] = []
            var countValSearch   : [Any] = []
            var typeSearchVal    : [Any] = []
            var imageSearchVal   : [Any] = []
            var noteValSearch    : [Any] = []
            var notepassValSearch: [Any] = []
            var tagValSearch     : [Any] = []
            var lableValSearch   : [Any] = []
            var colorValSearch   : [Any] = []
            
            for (index,item) in nameSearch.enumerated(){
                
                if ((item as! String).lowercased().contains((searchBar.text?.lowercased())!)){
                    nameValSearch.append(nameSearch[index] as! String)
                    folderValSearch.append(folderIDSearch[index] as! String)
                    userValSearch.append(useridSearch[index] as! String)
                    parentValSearch.append(parentIDSearch[index] as! String)
                    sectionValSearch.append(sectionidSearch[index] as! String)
                    countValSearch.append(countSearch[index] as! String)
                    typeSearchVal.append(typeValSearch[index] as! String)
                    if is_parent != "0"{
                        imageSearchVal.append(imageValSearch[index] as! UIImage)
                        noteValSearch.append(notetxtSearch[index] as! String)
                        notepassValSearch.append(notepassSearch[index] as! String)
                        tagValSearch.append(istaggedSearch[index] as! String)
                        lableValSearch.append(labelnamesSearch[index] as! String)
                        colorValSearch.append(iconcolorSearch[index] as! String)
                    }
                    
                }
                
            }
            
            DispatchQueue.main.async { [self] in
                self.folderID   = folderValSearch
                self.userid     = userValSearch
                self.parentID   = parentValSearch
                self.sectionid  = sectionValSearch
                self.count      = countValSearch
                self.name       = nameValSearch
                self.typeVal    = typeSearchVal
                self.imageVal   = imageSearchVal
                self.notetxt    = noteValSearch
                self.notepass   = notepassValSearch
                self.istagged   = tagValSearch
                self.labelnames = lableValSearch
                self.iconcolor  = colorValSearch
            }
            
        }
        
        self.collectionView.reloadData()
        
    }
    
    @IBAction func addFilesAndFolders(_ sender: Any) {
        if is_parent == "0"{
            
            UIView.animate(withDuration: 0.7) {
                self.addFileOrFolderMainView.isHidden = false
                self.addFileOrFolderMainView.alpha    = 1.0
                self.addFileOrFolderLabel.text        = "Add New Folder"
                self.addFolderText.attributedPlaceholder = NSAttributedString(string: "Enter Folder Name",attributes: [NSAttributedString.Key.foregroundColor: UIColor.systemRed])
            }
        }else{
            
            UIView.animate(withDuration: 0.7) {
                self.addFileandFolderView.isHidden = false
                self.addFileandFolderView.alpha    = 1.0
            }
        }
        
    }
    
    @IBAction func goBackOneStep(_ sender: Any) {
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        spiner.backgroundColor = UIColor.black
        spiner.alpha = 0.8
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        if is_parent != "0"{
            
            let sectionID = dashboardData[0].sectionID
            getPriviousFolderData(folder_id: is_parent, sectionID: sectionID)
            
        }else{
            
            let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
        }
        
        
        
    }
    
    
    @IBAction func notificationList(_ sender: Any) {
        // Show all Notification List Sended By Admin
    }
    
    @IBAction func goToDashboard(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
    
    
    
    
    
    //--------------------------- Add Media Files
    
    
    
    
    @IBAction func addFolder(_ sender: Any) {
        addFileandFolderView.isHidden = true
        addFileandFolderView.alpha    = 0.0
        
        UIView.animate(withDuration: 0.7) {
            self.addFileOrFolderMainView.isHidden = false
            self.addFileOrFolderMainView.alpha    = 1.0
            self.addFileOrFolderLabel.text        = "Add New Folder"
            self.addFolderText.attributedPlaceholder = NSAttributedString(string: "Enter Folder Name",
                                                                          attributes: [NSAttributedString.Key.foregroundColor: UIColor.systemRed])
        }
    }
    
    @IBAction func addFile(_ sender: Any) {
        addFileandFolderView.isHidden = true
        addFileandFolderView.alpha    = 0.0
        
        dashboardData = AppInfoData.getAppInfo()
        let section_name = dashboardData[0].sectionName
        
        // Checking If Subscription Expire
        let today         = Date().timeIntervalSince1970
        let expriry       = self.expireSubs
  
        if (Int(today) <= expriry!) {
            
            let countsVal :Int
            
            if self.countNote == "Unlimited"{
                countsVal = 1
            }else{
                countsVal = Int(self.countNote) ?? 0
            }
            
            if section_name == "Notes"{
                if countsVal > 0 {
                    UIView.animate(withDuration: 0.7) {
                        let storyboard       = UIStoryboard(name: "Note", bundle: nil)
                        let secondVC         = storyboard.instantiateViewController(withIdentifier: "editor_vc") as! EditorViewController
                        secondVC.is_new      = "1"
                        secondVC.noteID      = ""
                        secondVC.parentID    = self.is_parent
                        secondVC.countNote   = self.countNote
                        self.show(secondVC, sender: self)
                    }
                }else{
                    self.subscriptionFailedAlert(title:"Limit Expired For Note",message:"Your subscription limit has been expired for NOTE CREATION. Please purchase new subscription for continue.");
                }
            }else if section_name == "Images"{
                if countsVal > 0 {
                    
                    let alert = UIAlertController(title: "Select Media File From ", message: "Please Select an Option", preferredStyle: .actionSheet)
                    
                    alert.addAction(UIAlertAction(title: "Select From Library", style: .default , handler:{ (UIAlertAction)in
                        self.getMediaFromLib()
                    }))
                    
                    alert.addAction(UIAlertAction(title: "Select From Camera", style: .default , handler:{ (UIAlertAction)in
                        self.getMediaFromCamera()
                    }))
                    
                    alert.addAction(UIAlertAction(title: "Dismiss", style: .destructive, handler:nil))
                    
                    self.present(alert, animated: true, completion: nil)
                }else{
                    self.subscriptionFailedAlert(title:"Limit Expired For Image",message:"Your subscription limit has been expired for IMAGE UPLOAD. Please purchase new subscription for continue.");
                }
                
                //addFilesLibraryView.isHidden = false
                
            }else if section_name == "Videos"{
                if countsVal > 0 {
                    let alert = UIAlertController(title: "Select Media File From ", message: "Please Select an Option", preferredStyle: .actionSheet)
                    
                    alert.addAction(UIAlertAction(title: "Select From Library", style: .default , handler:{ (UIAlertAction)in
                        self.getMediaFromLib()
                    }))
                    
                    alert.addAction(UIAlertAction(title: "Select From Camera", style: .default , handler:{ (UIAlertAction)in
                        self.getMediaFromCamera()
                    }))
                    
                    alert.addAction(UIAlertAction(title: "Dismiss", style: .destructive, handler:nil))
                    
                    self.present(alert, animated: true, completion: nil)
                }else{
                    self.subscriptionFailedAlert(title:"Limit Expired For Video",message:"Your subscription limit has been expired for VIDEO UPLOAD. Please purchase new subscription for continue.");
                }
                
            }else if section_name == "Audios"{
                if countsVal > 0 {
                    let alert = UIAlertController(title: "Record Your Audio", message: "", preferredStyle: .actionSheet)
                    
                    alert.addAction(UIAlertAction(title: "Record Media From Recorder", style: .default , handler:{ (UIAlertAction)in
                        let storyBoard: UIStoryboard = UIStoryboard(name: "Note", bundle: nil)
                        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "recording_vc") as! RecordingViewController
                        nextViewController.folderID = self.is_parent
                        nextViewController.countNote = self.countNote
                        self.show(nextViewController, sender: self)
                        
                    }))
                    
                    alert.addAction(UIAlertAction(title: "Dismiss", style: .destructive, handler:nil))
                    
                    self.present(alert, animated: true, completion: nil)
                }else{
                    self.subscriptionFailedAlert(title:"Limit Expired For Audio",message:"Your subscription limit has been expired for AUDIO UPLOAD. Please purchase new subscription for continue.");
                }
            }
            
        }else{
            
            // If Subscription Date Is Expired
            let alert = UIAlertController(title: "Subscription Failed", message: "Your subscription has expired.Please purchase subscription to continue creation.", preferredStyle: .actionSheet)
            
            alert.addAction(UIAlertAction(title: "Purchase", style: .default , handler:{ (UIAlertAction)in
                let storyBoard: UIStoryboard = UIStoryboard(name: "Dashboard", bundle: nil)
                let nextViewController = storyBoard.instantiateViewController(withIdentifier: "paymentVC") as! PaymentViewController
                self.show(nextViewController, sender: self)
                
            }))
            
            alert.addAction(UIAlertAction(title: "Dismiss", style: .destructive, handler:nil))
            
            self.present(alert, animated: true, completion: nil)
        }
        
    }
    
    func subscriptionFailedAlert(title:String,message:String) {
        let alert = UIAlertController(title: title, message: message, preferredStyle: .actionSheet)
        
        alert.addAction(UIAlertAction(title: "Purchase", style: .default , handler:{ (UIAlertAction)in
            let storyBoard: UIStoryboard = UIStoryboard(name: "Dashboard", bundle: nil)
            let nextViewController = storyBoard.instantiateViewController(withIdentifier: "paymentVC") as! PaymentViewController
            self.show(nextViewController, sender: self)
            
        }))
        
        alert.addAction(UIAlertAction(title: "Dismiss", style: .destructive, handler:nil))
        
        self.present(alert, animated: true, completion: nil)
    }
    
    @objc func getMediaFromLib(){
        if section_name == "Images"{
            pickerController.allowsEditing          = false
            pickerController.sourceType             = .photoLibrary
            pickerController.modalPresentationStyle = .popover
            pickerController.mediaTypes             = [kUTTypeImage as String]
            present(pickerController, animated: true, completion: nil)
            
        }else if section_name == "Videos"{
            pickerController.allowsEditing          = false
            pickerController.sourceType             = .photoLibrary
            pickerController.modalPresentationStyle = .popover
            pickerController.mediaTypes             = [kUTTypeMovie as String]
            
            present(pickerController, animated: true, completion: nil)
        }
    }
    
    
    @objc func getMediaFromCamera(){
        pickerController.allowsEditing          = false
        pickerController.sourceType             = .camera
        pickerController.modalPresentationStyle = .popover
        pickerController.cameraDevice           = .rear // rear Vs front
        pickerController.cameraFlashMode        = .on // on, off Vs auto
        if section_name == "Images"{
            pickerController.mediaTypes         = [kUTTypeImage as String]
            pickerController.cameraCaptureMode  = .photo // Default media type .photo vs .video
        }else if section_name == "Videos"{
            pickerController.mediaTypes         = [kUTTypeMovie as String]
            pickerController.videoExportPreset  = AVAssetExportPresetHEVC1920x1080
            pickerController.cameraCaptureMode  = .video // Default media type .photo vs .video
        }
        present(pickerController, animated: true, completion: nil)
    }
    
    
    func imagePickerController(_ picker: UIImagePickerController,
                               didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        let mediaType = info[UIImagePickerController.InfoKey.mediaType] as! CFString
        switch mediaType {
        case kUTTypeImage:
            pickerImgs = info[UIImagePickerController.InfoKey.originalImage] as? UIImage
            
        case kUTTypeMovie:
            
            let videoDataURL    = info[UIImagePickerController.InfoKey.mediaURL] as! NSURL?
            //let videoPath       = videoDataURL?.path
            let video3          = try? NSData(contentsOf: videoDataURL! as URL, options: .mappedIfSafe)
            
            self.video = video3 as Data?
            
            if let videoDataURL = info[UIImagePickerController.InfoKey.mediaURL] as? NSURL {
                do {
                    
                    let documents      = try FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: false)
                    let destinationURL = documents.appendingPathComponent("video.mov")
                    
                    try? FileManager.default.removeItem(at: destinationURL)
                    
                    let destinationURL2 = documents.appendingPathComponent("video.mov")
                    
                    // but just copy from the video URL to the destination URL
                    
                    try FileManager.default.copyItem(at: videoDataURL as URL, to: destinationURL2)
                    
                    self.videoPath = destinationURL2
                    
                    self.uploadItem =  info[UIImagePickerController.InfoKey.mediaURL] as? URL
                    
                } catch {
                    print(error)
                }
            }
            
            self.addFileOrFolderLabel.text        = "Add New Video File"
            self.addFolderText.attributedPlaceholder = NSAttributedString(string: "Enter Video Name",attributes: [NSAttributedString.Key.foregroundColor: UIColor.systemRed])
        default:
            print("Mismatched type: \(mediaType)")
        }
        //addFileOrFolderMainView.isHidden = false
        
        dismiss(animated: true, completion: nil)
        
        self.getAlertFields(message: "Please Enter Media File Name.")
    }
    
    
    // Media Image And Video
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    
    func getAlertFields(message:String){
        
        self.dashboardData = AppInfoData.getAppInfo()
        let sectionID   = self.dashboardData[0].sectionID
        
        let alertController = UIAlertController(title: "Add Media File", message: message, preferredStyle: .alert)
        // creating text fields
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter Image Name"
        }
        
        // checking for Image Or Video File  (4 = image, 2 = video)
        if sectionID == "4"{
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter Image Label. (Optional)"
            }
        }
        
        let saveAction = UIAlertAction(title: "Save", style: .default, handler: { alert -> Void in
            
            let nameMedia   = alertController.textFields![0] as UITextField
            // Check for NameMedia Is Not Empty
            
            if nameMedia.text!.isEmpty{
                self.getAlertFields(message: "Media File Name Required.")
            }else{
                if sectionID == "4"{
                    let labelMedia  = alertController.textFields![1] as UITextField
                    
                    self.uploadToServer(userID: self.userID!, noteName: nameMedia.text!, folderID: self.is_parent, labelName: labelMedia.text!, sectionID: sectionID)
                }else{
                    self.uploadVideoFiles(userID: self.userID!, noteName: nameMedia.text!, folderID: self.is_parent, labelName: "", sectionID: sectionID)
                }
            }
            
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: .default, handler: nil )
        
        alertController.addAction(saveAction)
        alertController.addAction(cancelAction)
        
        self.present(alertController, animated: true, completion: nil)
    }
    
    // Media Audio
    
    
    func mediaPickerDidCancel(_ mediaPicker: MPMediaPickerController) {
        self.dismiss(animated: true, completion: nil)
    }
    
    func mediaPicker(_ mediaPicker: MPMediaPickerController, didPickMediaItems mediaItemCollection: MPMediaItemCollection) {
        
        print(mediaItemCollection.items[0].assetURL as Any)
        self.dismiss(animated: true, completion: nil)
    }
    
    func mediaPickerDidCancel(mediaPicker: MPMediaPickerController) {
        
        self.dismiss(animated: true, completion: nil)
    }
    
    func export(_ assetURL: URL, completionHandler: @escaping (_ fileURL: URL?, _ error: Error?) -> ()) {
        let asset = AVURLAsset(url: assetURL)
        guard let exporter = AVAssetExportSession(asset: asset, presetName: AVAssetExportPresetAppleM4A) else {
            completionHandler(nil, ExportError.unableToCreateExporter)
            return
        }
        
        let fileURL = URL(fileURLWithPath: NSTemporaryDirectory())
            .appendingPathComponent(NSUUID().uuidString)
            .appendingPathExtension("m4a")
        
        exporter.outputURL = fileURL
        exporter.outputFileType = AVFileType(rawValue: "com.apple.m4a-audio")
        
        exporter.exportAsynchronously {
            if exporter.status == .completed {
                completionHandler(fileURL, nil)
            } else {
                completionHandler(nil, exporter.error)
            }
        }
    }
    
    func exampleUsage(with mediaItem: MPMediaItem) {
        if let assetURL = mediaItem.assetURL {
            export(assetURL) { fileURL, error in
                guard let fileURL = fileURL, error == nil else {
                    print("export failed: \(String(describing: error))")
                    return
                }
                
                // use fileURL of temporary file here
                print("\(fileURL)")
            }
        }
    }
    
    enum ExportError: Error {
        case unableToCreateExporter
    }
    
    //------------------ Add Media Files Closed -----------------
    
    public func getSectionFolders(userID:String,sectionID:String,control:String){
        
        var folder_ID    : [Any] = []
        var user_ID      : [Any] = []
        var name_Val     : [Any] = []
        var parent_ID    : [Any] = []
        var section_ID   : [Any] = []
        var count_Val    : [Any] = []
        var types        : [Any] = []
        
        
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/section_folder")!)
        request.httpMethod  = "POST"
        let postString      = "control=\(control)&userID=\(userID)&section_id=\(sectionID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
                
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                if let content = json["data"] as? [[String:String]] {
                                    if content.count != 0{
                                        for category in content{
                                            let folderIDs    =   category["folderID"]!
                                            let userIDs      =   category["userID"]!
                                            let parentIDs    =   category["parentID"]!
                                            let sewctionIDs  =   category["section_id"]!
                                            let names        =   category["name"]!
                                            let countss      =   category["count"]!
                                            let typess       =   "folder"
                                            
                                            name_Val.append(names)
                                            folder_ID.append(folderIDs)
                                            user_ID.append(userIDs)
                                            parent_ID.append(parentIDs)
                                            section_ID.append(sewctionIDs)
                                            count_Val.append(countss)
                                            types.append(typess)
                                        }
                                    }
                                    
                                    DispatchQueue.main.async {
                                        
                                        self.folderID  = folder_ID
                                        self.name      = name_Val
                                        self.userid    = user_ID
                                        self.parentID  = parent_ID
                                        self.sectionid = section_ID
                                        self.count     = count_Val
                                        self.typeVal   = types
                                        
                                        self.folderIDSearch  = folder_ID
                                        self.nameSearch      = name_Val
                                        self.useridSearch    = user_ID
                                        self.parentIDSearch  = parent_ID
                                        self.sectionidSearch = section_ID
                                        self.countSearch     = count_Val
                                        self.typeValSearch   = types
                                        
                                        self.collectionView.reloadData()
                                        self.spiner.stopAnimating()
                                        self.view.isUserInteractionEnabled = true
                                    }
                                }
                            }else{
                                DispatchQueue.main.async {
                                    
                                    self.folderID  = folder_ID
                                    self.name      = name_Val
                                    self.userid    = user_ID
                                    self.parentID  = parent_ID
                                    self.sectionid = section_ID
                                    self.count     = count_Val
                                    self.typeVal   = types
                                    
                                    self.collectionView.reloadData()
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                }
                                print("Responce Error")
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                        
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    public func getFolderItemData(userID:String,folder_id:String,control:String,sectionID:String){
        
        DispatchQueue.main.async { [self] in
            spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height))
            spiner.center = view.center
            spiner.style  = UIActivityIndicatorView.Style.large
            spiner.color  = .orange
            spiner.hidesWhenStopped = true
            spiner.backgroundColor = UIColor.black
            spiner.alpha = 0.8
            view.addSubview(spiner)
            spiner.startAnimating()
            self.view.isUserInteractionEnabled = false
        }
        
        
        var folder_ID    : [Any] = []
        var user_ID      : [Any] = []
        var name_Val     : [Any] = []
        var parent_ID    : [Any] = []
        var section_ID   : [Any] = []
        var count_Val    : [Any] = []
        var type_Val     : [Any] = []
        var image_Val    : [Any] = []
        var note_txt     : [Any] = []
        var note_pass    : [Any] = []
        var is_tagged    : [Any] = []
        var label_names  : [Any] = []
        var icon_color   : [Any] = []
        var noteID       : [Any] = []
        var subscription_exp : Int? = 0
        var noteCounts   = ""
        
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/show_note/")!)
        request.httpMethod  = "POST"
        let postString      = "control=\(control)&userID=\(userID)&folderID=\(folder_id)&section_id=\(sectionID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                if let content  = json["data"]  as? [String: Any] {
                                    let notes   = content["notes"] as! [[String:Any]]
                                    let folders = content["folders"] as! [[String:Any]]
                                    let subscriptions = content["subscriptions"] as! [[String:Any]]
                                    
                                    // Array Collection For Folders
                                    for fold in folders{
                                        // FolderProperties
                                        let folderIDs  =   fold["folderID"]!
                                        let userIDs    =   fold["userID"]!
                                        let names      =   fold["name"]!
                                        let parent_IDs =   fold["parentID"]!
                                        let section_ids =  fold["section_id"]!
                                        let counts     =   fold["count"]!
                                        let typeds     =   fold["type"]!
                                        let imgs       =   UIImage(named: "folder.fill")
                                        // Add Null For Notes Properties
                                        let noteTextss =   ""
                                        let notePass   =   ""
                                        let isTag      =   "false"
                                        let lblName    =   ""
                                        let icnColor   =   ""
                                        let notesID     =   "*"
                                        
                                        folder_ID.append(folderIDs)
                                        user_ID.append(userIDs)
                                        name_Val.append(names)
                                        parent_ID.append(parent_IDs)
                                        section_ID.append(section_ids)
                                        count_Val.append(counts)
                                        type_Val.append(typeds)
                                        image_Val.append(imgs!)
                                        note_txt.append(noteTextss)
                                        note_pass.append(notePass)
                                        is_tagged.append(isTag)
                                        label_names.append(lblName)
                                        icon_color.append(icnColor)
                                        noteID.append(notesID)
                                    }
                                    
                                    // Array Collection For Notes
                                    for nt in notes{
                                        let folderIDs  =   nt["noteID"]!
                                        let userIDs    =   nt["userID"]!
                                        let names      =   nt["note_name"]!
                                        let parent_IDs =   nt["folderID"]!
                                        let section_ids =  ""
                                        let counts     =   ""
                                        let typeds     =   nt["type"]!
                                        
                                        if sectionID == "4"{
                                            let url  = URL(string: nt["text"] as! String)
                                            let data = try? Data(contentsOf: url!)
                                            let imgs = UIImage(data: data!)
                                            image_Val.append(imgs!)
                                        }else if sectionID == "1"{
                                            
                                            let imgs       =   UIImage(named: "doc.text.fill")
                                            image_Val.append(imgs!)
                                        }else if sectionID == "2"{
                                            let imgs       =   UIImage(named: "video")
                                            image_Val.append(imgs!)
                                        }else if sectionID == "3"{
                                            let imgs       =   UIImage(named: "music.quarternote.3")
                                            image_Val.append(imgs!)
                                        }
                                        
                                        // Add Null For Notes Properties
                                        let noteTextss =   nt["text"]!
                                        let notePass   =   nt["password"]!
                                        let isTag      =   nt["is_taged"]!
                                        let lblName    =   nt["label_name"]!
                                        let icnColor   =   nt["icon_color"]!
                                        
                                        noteID.append(folderIDs)
                                        folder_ID.append(folderIDs)
                                        user_ID.append(userIDs)
                                        name_Val.append(names)
                                        parent_ID.append(parent_IDs)
                                        section_ID.append(section_ids)
                                        count_Val.append(counts)
                                        type_Val.append(typeds)
                                        //image_Val.append(imgs!)
                                        note_txt.append(noteTextss)
                                        note_pass.append(notePass)
                                        is_tagged.append(isTag)
                                        label_names.append(lblName)
                                        icon_color.append(icnColor)
                                    }
                                    
                                    for subs in subscriptions{
                                        subscription_exp  = subs["timestamp"] as? Int
                                        noteCounts        = subs["noteCounts"]  as! String
                                    }
                                    
                                    
                                    
                                    DispatchQueue.main.async {
                                        self.folderID  = folder_ID
                                        self.userid    = user_ID
                                        self.parentID  = parent_ID
                                        self.sectionid = section_ID
                                        self.count     = count_Val
                                        self.name      = name_Val
                                        self.typeVal   = type_Val
                                        self.imageVal  = image_Val
                                        self.notetxt   = note_txt
                                        self.notepass  = note_pass
                                        self.istagged  = is_tagged
                                        self.labelnames = label_names
                                        self.iconcolor  = icon_color
                                        self.noteIDS    = noteID
                                        
                                        // serach variables
                                        self.folderIDSearch   = folder_ID
                                        self.useridSearch     = user_ID
                                        self.parentIDSearch   = parent_ID
                                        self.sectionidSearch  = section_ID
                                        self.countSearch      = count_Val
                                        self.nameSearch       = name_Val
                                        self.typeValSearch    = type_Val
                                        self.imageValSearch   = image_Val
                                        self.notetxtSearch    = note_txt
                                        self.notepassSearch   = note_pass
                                        self.istaggedSearch   = is_tagged
                                        self.labelnamesSearch = label_names
                                        self.iconcolorSearch  = icon_color
                                        
                                        self.countNote = noteCounts
                                        self.expireSubs = subscription_exp
                                        
                                        if self.parentID.isEmpty{
                                            self.is_parent = folder_id
                                        }
                                        self.collectionView.reloadData()
                                        self.spiner.stopAnimating()
                                        self.view.isUserInteractionEnabled = true
                                    }
                                }
                                
                            }else{
                                DispatchQueue.main.async {
                                    self.folderID  = folder_ID
                                    self.userid    = user_ID
                                    self.parentID  = parent_ID
                                    self.sectionid = section_ID
                                    self.count     = count_Val
                                    self.name      = name_Val
                                    self.typeVal   = type_Val
                                    self.imageVal  = image_Val
                                    self.notetxt   = note_txt
                                    self.notepass  = note_pass
                                    self.istagged  = is_tagged
                                    self.labelnames = label_names
                                    self.iconcolor  = icon_color
                                    
                                    if self.parentID.isEmpty{
                                        self.is_parent = folder_id
                                    }
                                    self.collectionView.reloadData()
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                }
                                print("Responce Error")
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            self.folderID  = folder_ID
                            self.userid    = user_ID
                            self.parentID  = parent_ID
                            self.sectionid = section_ID
                            self.count     = count_Val
                            self.name      = name_Val
                            self.typeVal   = type_Val
                            self.imageVal  = image_Val
                            self.notetxt   = note_txt
                            self.notepass  = note_pass
                            self.istagged  = is_tagged
                            self.labelnames = label_names
                            self.iconcolor  = icon_color
                            
                            if self.parentID.isEmpty{
                                self.is_parent = folder_id
                            }
                            self.collectionView.reloadData()
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                        
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    public func getPriviousFolderData(folder_id:String,sectionID:String){
        
        var folder_ID    : [Any] = []
        var user_ID      : [Any] = []
        var name_Val     : [Any] = []
        var parent_ID    : [Any] = []
        var section_ID   : [Any] = []
        var count_Val    : [Any] = []
        var type_Val     : [Any] = []
        var image_Val    : [Any] = []
        var note_txt     : [Any] = []
        var note_pass    : [Any] = []
        var is_tagged    : [Any] = []
        var label_names  : [Any] = []
        var icon_color   : [Any] = []
        
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/PriviousData/")!)
        request.httpMethod  = "POST"
        let postString      = "folderID=\(folder_id)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                if let content  = json["data"]  as? [String: Any] {
                                    let notes   = content["notes"] as! [[String:Any]]
                                    let folders = content["folders"] as! [[String:Any]]
                                    
                                    // Array Collection For Folders
                                    for fold in folders{
                                        // FolderProperties
                                        let folderIDs  =   fold["folderID"]!
                                        let userIDs    =   fold["userID"]!
                                        let names      =   fold["name"]!
                                        let parent_IDs =   fold["parentID"]!
                                        let section_ids =  fold["section_id"]!
                                        let counts     =   fold["count"]!
                                        let typeds     =   fold["type"]!
                                        let imgs       =   UIImage(named: "folder.fill")
                                        // Add Null For Notes Properties
                                        let noteTextss =   ""
                                        let notePass   =   ""
                                        let isTag      =   "false"
                                        let lblName    =   ""
                                        let icnColor   =   ""
                                        
                                        folder_ID.append(folderIDs)
                                        user_ID.append(userIDs)
                                        name_Val.append(names)
                                        parent_ID.append(parent_IDs)
                                        section_ID.append(section_ids)
                                        count_Val.append(counts)
                                        type_Val.append(typeds)
                                        image_Val.append(imgs!)
                                        note_txt.append(noteTextss)
                                        note_pass.append(notePass)
                                        is_tagged.append(isTag)
                                        label_names.append(lblName)
                                        icon_color.append(icnColor)
                                    }
                                    
                                    // Array Collection For Notes
                                    for nt in notes{
                                        let folderIDs  =   nt["noteID"]!
                                        let userIDs    =   nt["userID"]!
                                        let names      =   nt["note_name"]!
                                        let parent_IDs =   nt["folderID"]!
                                        let section_ids =  ""
                                        let counts     =   ""
                                        let typeds     =   nt["type"]!
                                        
                                        if sectionID == "4"{
                                            let urlImg      = URL(string:nt["text"]! as! String)
                                            if let dataImg  = try? Data(contentsOf: urlImg!)
                                            {
                                                let img: UIImage = UIImage(data: dataImg)!
                                                image_Val.append(img)
                                            }
                                        }else if sectionID == "1"{
                                            
                                            let imgs       =   UIImage(named: "doc.text.fill")
                                            image_Val.append(imgs!)
                                        }else if sectionID == "2"{
                                            let imgs       =   UIImage(named: "video")
                                            image_Val.append(imgs!)
                                        }else if sectionID == "3"{
                                            let imgs       =   UIImage(named: "music.quarternote.3")
                                            image_Val.append(imgs!)
                                        }
                                        
                                        // Add Null For Notes Properties
                                        let noteTextss =   nt["text"]!
                                        let notePass   =   nt["password"]!
                                        let isTag      =   nt["is_taged"]!
                                        let lblName    =   nt["label_name"]!
                                        let icnColor   =   nt["icon_color"]!
                                        
                                        folder_ID.append(folderIDs)
                                        user_ID.append(userIDs)
                                        name_Val.append(names)
                                        parent_ID.append(parent_IDs)
                                        section_ID.append(section_ids)
                                        count_Val.append(counts)
                                        type_Val.append(typeds)
                                        // image_Val.append(imgs!)
                                        note_txt.append(noteTextss)
                                        note_pass.append(notePass)
                                        is_tagged.append(isTag)
                                        label_names.append(lblName)
                                        icon_color.append(icnColor)
                                    }
                                    
                                    DispatchQueue.main.async {
                                        self.folderID  = folder_ID
                                        self.userid    = user_ID
                                        self.parentID  = parent_ID
                                        self.sectionid = section_ID
                                        self.count     = count_Val
                                        self.name      = name_Val
                                        self.typeVal   = type_Val
                                        self.imageVal  = image_Val
                                        self.notetxt   = note_txt
                                        self.notepass  = note_pass
                                        self.istagged  = is_tagged
                                        self.labelnames = label_names
                                        self.iconcolor  = icon_color
                                        
                                        self.collectionView.reloadData()
                                        
                                        self.spiner.stopAnimating()
                                        self.view.isUserInteractionEnabled = true
                                        
                                        
                                    }
                                }
                                
                            }else{
                                
                                DispatchQueue.main.async {
                                    
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    
                                }
                                print("Responce Error")
                            }
                        }
                    } catch let error {
                        
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    
    /* ----------------------------------  Over Ride For Tuch Detection ----------------------*/
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        
        let touch: UITouch? = touches.first
        //location is relative to the current view
        // do something with the touched point
        if touch?.view != addFileandFolderView {
            addFileandFolderView.isHidden = true
            addFileandFolderView.alpha    = 0.0
        }
        
        if touch?.view != addFilesOrFolderView{
            addFileOrFolderMainView.isHidden = true
            addFileOrFolderMainView.alpha    = 0.0
        }
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    
    
    
    /* ==================== Toolbar Item Bottom Buttons =================== */
    
    @IBAction func openMenu(_ sender: Any) {
        
        if menu_open == false{
            UIView.animate(withDuration: 0.4) {
                self.mainMenuView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height - 100)
                self.mainMenuView.isHidden = false
                self.menu_open = true
                self.mainMenuBtn.image = UIImage(named: "xmark")
            }
        }else{
            UIView.animate(withDuration: 0.6) {
                self.mainMenuBtn.image = UIImage(named: "line.horizontal.3")
                self.mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: 0, height: 0)
                self.mainMenuView.isHidden = true
                self.menu_open = false
                
            }
        }
        
    }
    
    @IBAction func openImage(_ sender: Any) {
        dashboardData = AppInfoData.addAppInfo(sectionName: "Images",sectionID:"4")
        
        let storyboard = UIStoryboard(name: "Note", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func openVideo(_ sender: Any) {
        dashboardData = AppInfoData.addAppInfo(sectionName: "Videos",sectionID:"2")
        
        let storyboard = UIStoryboard(name: "Note", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func openAudio(_ sender: Any) {
        dashboardData = AppInfoData.addAppInfo(sectionName: "Audios",sectionID:"3")
        
        let storyboard = UIStoryboard(name: "Note", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func allFolders(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Folders", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "folders_vc") as! FoldersViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func reminders(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Reminder", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "reminder_vc") as! ReminderViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func addNewFile(_ sender: Any) {
        
        addFileOrFolderMainView.isHidden = true
        
        let userTxt     = userID!
        let nameTxt     = addFolderText.text!
        let sectionTxt  = dashboardData[0].sectionID
        let parenTxt    = is_parent
        
        if sectionTxt == "1"{
            if addFileOrFolderLabel.text == "Add New Note File"{
                addNote(userID: userTxt, noteName: nameTxt, text: "", folderID: parenTxt, sectionID: sectionTxt)
            }else{
                addNewFolder(userID: userTxt, name: nameTxt, parentID: parenTxt, sectionID: sectionTxt)
            }
        }else if sectionTxt == "2"{
            
            if addFileOrFolderLabel.text == "Add New Video File"{
                uploadVideoFiles(userID: userTxt, noteName: nameTxt, folderID: parenTxt, labelName: "", sectionID: sectionTxt)
            }else{
                addNewFolder(userID: userTxt, name: nameTxt, parentID: parenTxt, sectionID: sectionTxt)
            }
            
        }else if sectionTxt == "3"{
            
            if addFileOrFolderLabel.text == ""{
                uploadToServer(userID: userTxt, noteName: nameTxt, folderID: parenTxt, labelName: "", sectionID: sectionTxt)
            }else{
                addNewFolder(userID: userTxt, name: nameTxt, parentID: parenTxt, sectionID: sectionTxt)
            }
        }else if sectionTxt == "4"{
            print("Image upload")
            if addFileOrFolderLabel.text == "Add New Image File"{
                uploadToServer(userID: userTxt, noteName: nameTxt, folderID: parenTxt, labelName: "", sectionID: sectionTxt)
            }else{
                addNewFolder(userID: userTxt, name: nameTxt, parentID: parenTxt, sectionID: sectionTxt)
            }
        }
    }
    
    func addNewFolder(userID:String,name:String,parentID:String,sectionID:String){
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/Create_folders/")!)
        request.httpMethod  = "POST"
        let postString      = "name=\(name)&userID=\(userID)&parentID=\(parentID)&sectionID=\(sectionID)"
        request.httpBody    = postString.data(using: .utf8)
        
        
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            
                            if let status = json["result"] as? String, status == "true" {
                                
                                if self.is_parent == "0"{
                                    
                                    self.folderID.removeAll()
                                    self.userid.removeAll()
                                    self.parentID.removeAll()
                                    self.sectionid.removeAll()
                                    self.count.removeAll()
                                    self.name.removeAll()
                                    self.typeVal.removeAll()
                                    self.imageVal.removeAll()
                                    self.notetxt.removeAll()
                                    self.notepass.removeAll()
                                    self.istagged.removeAll()
                                    self.labelnames.removeAll()
                                    self.iconcolor.removeAll()
                                    
                                    DispatchQueue.main.async {
                                        
                                        self.addFileOrFolderMainView.isHidden = true
                                    }
                                    self.getSectionFolders(userID: userID, sectionID: sectionID, control: "show_sec_folder")
                                    
                                }else{
                                    
                                    self.folderID.removeAll()
                                    self.userid.removeAll()
                                    self.parentID.removeAll()
                                    self.sectionid.removeAll()
                                    self.count.removeAll()
                                    self.name.removeAll()
                                    self.typeVal.removeAll()
                                    self.imageVal.removeAll()
                                    self.notetxt.removeAll()
                                    self.notepass.removeAll()
                                    self.istagged.removeAll()
                                    self.labelnames.removeAll()
                                    self.iconcolor.removeAll()
                                    // Get Folder Clik Data From API
                                    
                                    DispatchQueue.main.async {
                                        self.addFileOrFolderMainView.isHidden = true
                                    }
                                    
                                    self.getFolderItemData(userID: userID, folder_id: parentID, control: "show_note",sectionID:sectionID)
                                    
                                }
                                
                            }else{
                                print("JSON ERROR")
                                DispatchQueue.main.async {
                                    let alert = UIAlertController(title: "Nivaro Error", message: "Server seems busy try later", preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    func addNote(userID:String,noteName:String,text:String,folderID:String,sectionID:String){
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/add_note/")!)
        request.httpMethod  = "POST"
        let postString      = "note_name=\(noteName)&userID=\(userID)&text=\(text)&folderID=\(folderID)&section_id=\(sectionID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            
                            if let status = json["result"] as? String, status == "true" {
                                
                                self.folderID.removeAll()
                                self.userid.removeAll()
                                self.parentID.removeAll()
                                self.sectionid.removeAll()
                                self.count.removeAll()
                                self.name.removeAll()
                                self.typeVal.removeAll()
                                self.imageVal.removeAll()
                                self.notetxt.removeAll()
                                self.notepass.removeAll()
                                self.istagged.removeAll()
                                self.labelnames.removeAll()
                                self.iconcolor.removeAll()
                                // Get Folder Clik Data From API
                                DispatchQueue.main.async {
                                    self.addFileOrFolderMainView.isHidden = true
                                }
                                self.getFolderItemData(userID: userID, folder_id: self.is_parent, control: "show_note",sectionID:sectionID)
                                
                            }else{
                                DispatchQueue.main.async {
                                    let alert = UIAlertController(title: "Nivaro Error", message: error?.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    @IBAction func getFileFromGallery(_ sender: Any) {
        DispatchQueue.main.async{
            self.addFilesLibraryView.isHidden  = true
        }
        
        
        if section_name == "Images"{
            pickerController.allowsEditing          = false
            pickerController.sourceType             = .photoLibrary
            pickerController.modalPresentationStyle = .popover
            pickerController.mediaTypes             = [kUTTypeImage as String]
            present(pickerController, animated: true, completion: nil)
            
        }else if section_name == "Videos"{
            pickerController.allowsEditing          = false
            pickerController.sourceType             = .photoLibrary
            pickerController.modalPresentationStyle = .popover
            pickerController.mediaTypes             = [kUTTypeMovie as String]
            
            present(pickerController, animated: true, completion: nil)
        }
        
    }
    
    
    @objc func selectMediaFiles(){
        self.present(mediaPicker, animated: true, completion: nil)
    }
    
    
    @IBAction func getFilesFromCamera(_ sender: Any) {
        DispatchQueue.main.async{
            self.addFilesLibraryView.isHidden  = true
        }
        pickerController.allowsEditing          = false
        pickerController.sourceType             = .camera
        pickerController.modalPresentationStyle = .popover
        
        
        pickerController.cameraDevice = .rear // rear Vs front
        pickerController.cameraFlashMode = .on // on, off Vs auto
        if section_name == "Images"{
            
            pickerController.mediaTypes          = [kUTTypeImage as String]
            pickerController.cameraCaptureMode   = .photo // Default media type .photo vs .video
            
        }else if section_name == "Videos"{
            
            pickerController.mediaTypes         = [kUTTypeMovie as String]
            pickerController.videoExportPreset  = AVAssetExportPresetHEVC1920x1080
            pickerController.cameraCaptureMode       = .video // Default media type .photo vs .video
            
        }
        
        present(pickerController, animated: true, completion: nil)
    }
    
    func uploadToServer(userID:String,noteName:String,folderID:String,labelName:String,sectionID:String){
        
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        spiner.backgroundColor = UIColor.black
        spiner.alpha = 0.8
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        var countVal : String = ""
        
        if self.countNote != "Unlimited"{
            countVal = "\(Int(self.countNote)! - 1)"
        }else{
            countVal = self.countNote
        }
        
        let myUrl = NSURL(string: "https://nivaroapp.nivaro.com.au/api/ios/UploadFiles");
        let request = NSMutableURLRequest(url:myUrl! as URL);
        request.httpMethod = "POST";
        let param = [
            "userID"        : userID,
            "note_name"     : noteName,
            "folderID"      : folderID,
            "label_name"    : labelName,
            "sectionID"     : sectionID,
            "imageCounts"   : countVal
        ]
        
        let boundary = generateBoundaryString()
        
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        
        
        let imageData = pickerImgs!.jpegData(compressionQuality:0.8)
        
        if(imageData==nil)  {
            spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
            return;
            
        }
        
        request.httpBody = createBodyWithParameters(parameters: param, filePathKey: "img", imageDataKey: imageData! as NSData, boundary: boundary) as Data
        
        let task = URLSession.shared.dataTask(with: request as URLRequest) {
            data, response, error in
            
            if error != nil {
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    let alert = UIAlertController(title: "Nivaro Alert", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
                
                return
            }else{
                
                if let urlContent = data{
                    do {
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            
                            if let status = json["result"] as? String, status == "true" {
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    let alert = UIAlertController(title: "Nivaro Upload Success", message: "\(noteName) Uploaded SuccessFully", preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                    self.getFolderItemData(userID: self.userID!, folder_id: self.is_parent, control: "show_note", sectionID: sectionID)
                                }
                            }else{
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    let alert = UIAlertController(title: "Nivaro Upload Error", message: "Upload Error. try later", preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                    self.getFolderItemData(userID: self.userID!, folder_id: self.is_parent, control: "show_note", sectionID: sectionID)
                                }
                            }
                            
                        }
                    }catch{
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Alert", message: error.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }
                }
                
            }
        }
        task.resume()
    }
    
    
    
    
    /* UPLOAD VIDEO FILE */
    
    func uploadVideoFiles(userID:String,noteName:String,folderID:String,labelName:String,sectionID:String){
        
        let progressView = UIProgressView()
        let uploadLBL    = UILabel()
        let alertView    = UIAlertController(title: "", message: "Video uploading..", preferredStyle: .alert)
        
        
        self.present(alertView, animated: true, completion:{
            let margin:CGFloat = 8.0
            let rect = CGRect(x: margin, y: 72.0, width: alertView.view.frame.width - margin * 2.0 , height: 2.0)
            progressView.frame = rect
            progressView.progress = 0
            progressView.tintColor = UIColor.systemBlue
            alertView.view.addSubview(progressView)
            
            uploadLBL.frame = CGRect(x: 10, y: 90, width: Int((alertView.view.frame.width - margin * 2.0)), height: 30)
            uploadLBL.textAlignment = .center
            uploadLBL.text  = "0%"
            uploadLBL.textColor = UIColor.systemBlue
            alertView.view.addSubview(uploadLBL)
        })
        
        
        
        let timestamp = NSDate().timeIntervalSince1970 // just for some random name.
        let endPoint = URL(string: "https://nivaroapp.nivaro.com.au/api/ios/UploadVideo")
        
        
        // check for limit in subscription
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/CheckSubscriptionLimit/")!)
        request.httpMethod  = "POST"
        let postString      = "userID=\(userID)&sectionID=\(sectionID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            
                            if let status = json["result"] as? String, status == "true" {
                                
                                
                                
                                AF.upload(multipartFormData: { (multipartFormData) in
                                    multipartFormData.append(self.uploadItem!, withName: "Video", fileName: "\(timestamp).mp4", mimeType: "\(timestamp)/mp4")
                                }, to: endPoint!,method: .post)
                                .uploadProgress { progress in
                                    progressView.progress = Float(Int(progress.fractionCompleted * 100))
                                    uploadLBL.text = String(Int(progress.fractionCompleted * 100)) + "%"
                                }
                                .responseJSON { (response) in
                                    
                                    if response.value != nil {
                                        let jsonData     = response.value as! [String:Any]
                                        let dataResponce = jsonData["data"] as! String
                                        self.updateVideoData(userID:userID,noteName:noteName,folderID:folderID,labelName:labelName,sectionID:sectionID,image:dataResponce)
                                        
                                    }
                                    
                                    alertView.dismiss(animated: true, completion: nil)
                                }
                            }else{
                                DispatchQueue.main.async {
                                    let alert = UIAlertController(title: "Nivaro Error", message: json["message"] as? String, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
        
    }
    
    
    func updateVideoData(userID:String,noteName:String,folderID:String,labelName:String,sectionID:String,image:String){
        var countVal : String = ""
        
        if self.countNote != "Unlimited"{
            countVal = "\(Int(self.countNote)! - 1)"
        }else{
            countVal = self.countNote
        }
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/UploadVideoData/")!)
        request.httpMethod  = "POST"
        let postString      = "userID=\(userID)&noteName=\(noteName)&folderID=\(folderID)&labelName=\(labelName)&sectionID=\(sectionID)&image=\(image)&countUpd=\(countVal)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            
                            if let status = json["result"] as? String, status == "true" {
                                // Get Folder Clik Data From API
                                self.getFolderItemData(userID: userID, folder_id: self.is_parent, control: "show_note",sectionID:sectionID)
                            }else{
                                DispatchQueue.main.async {
                                    let alert = UIAlertController(title: "Nivaro Error", message: error?.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    private func mimeType(for path: String) -> String {
        let pathExtension = URL(fileURLWithPath: path).pathExtension as NSString
        guard
            let uti = UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, pathExtension, nil)?.takeRetainedValue(),
            let mimetype = UTTypeCopyPreferredTagWithClass(uti, kUTTagClassMIMEType)?.takeRetainedValue()
        else {
            return "application/octet-stream"
        }
        
        return mimetype as String
    }
    
    func createMimeType(fileExtension : String) -> String{
        if let oUTT = UTTypeCreatePreferredIdentifierForTag(kUTTagClassFilenameExtension, fileExtension as NSString, nil)?.takeRetainedValue(){
            if let mimeType = UTTypeCreatePreferredIdentifierForTag(oUTT, kUTTagClassMIMEType, nil)?.takeRetainedValue(){
                return mimeType as String
            }
        }
        return ""
    }
    
    /* UPLOAD VIDEO ENDS*/
    
    
    func createBodyWithParameters(parameters: [String: String]?, filePathKey: String?, imageDataKey: NSData, boundary: String) -> NSData {
        let body = NSMutableData();
        
        if parameters != nil {
            for (key, value) in parameters! {
                body.appendString(string: "--\(boundary)\r\n")
                body.appendString(string: "Content-Disposition: form-data; name=\"\(key)\"\r\n\r\n")
                body.appendString(string: "\(value)\r\n")
            }
        }
        
        
        let filename = "user-profile.jpg"
        let mimetype = "image/jpg"
        
        body.appendString(string: "--\(boundary)\r\n")
        body.appendString(string: "Content-Disposition: form-data; name=\"\(filePathKey!)\"; filename=\"\(filename)\"\r\n")
        body.appendString(string: "Content-Type: \(mimetype)\r\n\r\n")
        body.append(imageDataKey as Data)
        body.appendString(string: "\r\n")
        body.appendString(string: "--\(boundary)--\r\n")
        return body
    }
    
    func generateBoundaryString() -> String {
        return "Boundary-\(NSUUID().uuidString)"
    }
    
    
    
    @IBAction func mainMenuOpen(_ sender: Any) {
        if menu_open == false{
            UIView.animate(withDuration: 0.4) {
                self.mainMenuView.frame = CGRect(x: 0, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
                self.mainMenuView.isHidden = false
                self.menu_open = true
                self.mainMenuBtn.image = UIImage(named: "xmark")
            }
        }else{
            UIView.animate(withDuration: 0.6) {
                self.mainMenuBtn.image = UIImage(named: "line.horizontal.3")
                self.mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: 0, height: 0)
                self.mainMenuView.isHidden = true
                self.menu_open = false
                
            }
        }
    }
    
    
    
    
    
    func savePasswordForNote(notePass:String,noteID:String,indexPath: Int) {
        
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        //notePasswordSet api call
        var request         = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/SetPassword/")!)
        request.httpMethod  = "POST"
        let postString      = "noteID=\(noteID)&password=\(notePass)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    self.notepass[indexPath] = notePass
                                    
                                    let message = json["message"] as! String
                                    let alert = UIAlertController(title: "Success", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                
                            }else{
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    let message = "Can't set note password. Please try later."
                                    let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    }catch let error {
                        let err = (error.localizedDescription)
                        let message = err
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }
            }
        }
        task.resume()
    }
    
    
    func deleteNotesApiCall(userID:String,noteID:String){
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        let deleteID = noteID
        let user_id  = userID
        
        // Calling API
        var request         = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/Delete_note/")!)
        request.httpMethod  = "POST"
        let postString      = "userID=\(user_id)&noteID=\(deleteID)&control=delete_note"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let message = error?.localizedDescription
                    let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                
                if let urlContent = data{
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                //let sectionID   = self.dashboardData[0].sectionID
                                DispatchQueue.main.async {
                                    
                                    for i in self.deleteIndex{
                                        self.folderID.remove(at: i)
                                        self.userid.remove(at: i)
                                        self.parentID.remove(at: i)
                                        self.sectionid.remove(at: i)
                                        self.count.remove(at: i)
                                        self.name.remove(at: i)
                                        self.typeVal.remove(at: i)
                                        self.notetxt.remove(at: i)
                                        self.notepass.remove(at: i)
                                        self.istagged.remove(at: i)
                                        self.labelnames.remove(at: i)
                                        self.iconcolor.remove(at: i)
                                        
                                    }
                                    
                                    self.checkListForCell.removeAll()
                                    self.deleteIndex.removeAll()
                                    
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    self.collectionView.reloadData()
                                    
                                    
                                    // Get Folder Clik Data From API
                                    //self.getFolderItemData(userID: self.userID!, folder_id: self.is_parent, control: "show_note",sectionID:sectionID)
                                }
                            }else{
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    //                                    let message = "No Any Data Found"
                                    //                                    let alert = UIAlertController(title: "Nivaro Success", message: message, preferredStyle: UIAlertController.Style.alert)
                                    //                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    //                                    self.present(alert, animated: true, completion: nil)
                                    
                                }
                            }
                        }
                        
                    }catch let error {
                        
                        let err = (error.localizedDescription)
                        let message = err
                        DispatchQueue.main.async {
                            
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }
            }
        }
        task.resume()
    }
}





/* #######################################  UIVIEW EXTENSION CODE ######################################*/
extension UITextField {
    func setLeftPaddingPoints(_ amount:CGFloat){
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.leftView = paddingView
        self.leftViewMode = .always
    }
    func setRightPaddingPoints(_ amount:CGFloat) {
        let paddingView = UIView(frame: CGRect(x: 0, y: 0, width: amount, height: self.frame.size.height))
        self.rightView = paddingView
        self.rightViewMode = .always
    }
}

extension NSMutableData{
    func appendString(string: String) {
        let data = string.data(using: String.Encoding.utf8, allowLossyConversion: true)
        append(data!)
    }
}

extension Data{
    mutating func appendString(string: String) {
        let data = string.data(using: String.Encoding.utf8, allowLossyConversion: true)
        append(data!)
    }
}

extension ViewController: UIImagePickerControllerDelegate {
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        
        if let videoURL = info[UIImagePickerController.InfoKey.mediaURL] as? URL {
            print(videoURL)
        }
        self.dismiss(animated: true, completion: nil)
    }
    
    func documentsDirectoryURL() -> URL {
        let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
        let documentsDirectory = paths[0]
        return documentsDirectory
    }
}



extension NoteViewController: UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: 100.0, height: 125.0)
    }
}


extension String
{
    func toDateString( inputDateFormat inputFormat  : String,  ouputDateFormat outputFormat  : String ) -> String
    {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = inputFormat
        let date = dateFormatter.date(from: self)
        dateFormatter.dateFormat = outputFormat
        return dateFormatter.string(from: date!)
    }
}

