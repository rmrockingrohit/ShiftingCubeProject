//
//  MainMenuViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 20/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class MainMenuViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var MainMenuView: UIView!
    @IBOutlet weak var menuPresentView: UIView!
    @IBOutlet weak var userInfoView: UIView!
    @IBOutlet weak var editProfile: UIButton!
    
    var dashboardData = [AppInfoDelegete]()
    var arrDataMenu = [MainMenuModel]()
    
    //userDefaultes
    let usersName  = UserDefaults.standard.string(forKey: "UserName")
    
    override func viewDidLoad() {
        editProfile.isHidden = true
        arrDataMenu = MainMenuData.getMain()
        
        userNameLabel.text = usersName
        
        super.viewDidLoad()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrDataMenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MainMenuCell") as! MainMenuTableViewCell
        cell.menuIcon.image = arrDataMenu[indexPath.row].img
        cell.menuNameLabel.text = arrDataMenu[indexPath.row].title
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let type = indexPath.row
        
        switch type {
        
        case (0):
            
            dashboardData = AppInfoData.addAppInfo(sectionName: "Notes",sectionID:"1")
            
            
            let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
           
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
        case (1):
            
            let storyboard = UIStoryboard(name: "MyBookmarks", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "bookmark_vc") as! BookmarkViewController
        
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            
        case (2):
            
            let destinationVC = storyboard?.instantiateViewController(withIdentifier: "change_pass") as? ChangePasswordViewController
            show(destinationVC!, sender: self)
            
        case (3):
            
            let destinationVC = storyboard?.instantiateViewController(withIdentifier: "support") as? SupportViewController
            show(destinationVC!, sender: self)
            
        case (4):
            
            let destinationVC = storyboard?.instantiateViewController(withIdentifier: "faq") as? ChangePasswordViewController
            show(destinationVC!, sender: self)
            
        case (5):
            let destinationVC = storyboard?.instantiateViewController(withIdentifier: "faq") as? ChangePasswordViewController
            show(destinationVC!, sender: self)
          
        case (6):
            let destinationVC = storyboard?.instantiateViewController(withIdentifier: "faq") as? ChangePasswordViewController
            show(destinationVC!, sender: self)
            
        default:
            dashboardData = AppInfoData.addAppInfo(sectionName: "",sectionID:"")
        }
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        
        let touch: UITouch? = touches.first
        //location is relative to the current view
        // do something with the touched point
        if ((touch?.view != menuPresentView) || (touch?.view != userInfoView)) {
            
            menuPresentView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
        }
        
        
    }
}
