//
//  AdminNotificationViewController.swift
//  NivaroApp
//
//  Created by rohit mishra on 27/07/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class AdminNotificationViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    

    @IBOutlet weak var noLabel: UILabel!
    @IBOutlet weak var tableView: UITableView!
    var spiner  = UIActivityIndicatorView()
    let userID     = UserDefaults.standard.string(forKey: "userID")
    
    var titleNotify    : [Any] = []
    var notify         : [Any] = []
    var timeStamp      : [Any] = []
    var dateTime       : [Any] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.dataSource = self
        tableView.delegate   = self
        tableView.isHidden   = true
        noLabel.isHidden     = true
        self.getAdminNotificationList()
        tableView.tableFooterView = UIView()
    }
    
    
    
    override func viewWillAppear(_ animated: Bool) {
        tableView.reloadData()
    }
    
    func getAdminNotificationList(){
        
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        //spiner.backgroundColor = UIColor.black
        //spiner.alpha = 0.8
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        
        // Array Declearing
        var notifyTitle         :[Any]   = []
        var notifyNotification  :[Any]   = []
        var notifyTime          :[Any]   = []
        var timestampDate       :[Any]   = []
        
 
        // Geting Active Record In Database
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/AdminNotification")!)
        request.httpMethod  = "POST"
        let postString      = "userID=\(userID!)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
                
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                               
                                if let content = json["data"] as? [[String:String]] {
                                    if content.count != 0{
                                        for notify in content{
                                            let timeDateStamp = notify["timestamp"]!
                                            if Int(timeDateStamp)! <= Int((Date().timeIntervalSince1970)) {
                                                notifyTitle.append(notify["title"]!)
                                                notifyNotification.append(notify["notification_text"]!)
                                                notifyTime.append(notify["timestamp"]!)
                                                timestampDate.append(notify["dateTime"]!)
                                            }
                                        }
                                    }
                                    DispatchQueue.main.async {
                                        self.titleNotify = notifyTitle
                                        self.notify      = notifyNotification
                                        self.timeStamp   = notifyTime
                                        self.dateTime    = timestampDate
                                        
                                        if self.titleNotify.count > 0 {
                                            self.noLabel.isHidden   = true
                                            self.tableView.isHidden = false
                                            self.tableView.reloadData()
                                        }else{
                                            self.noLabel.isHidden   = false
                                            self.tableView.isHidden = true
                                        }
                                        self.spiner.stopAnimating()
                                        self.view.isUserInteractionEnabled = true
                                        
                                        
                                    }
                                }
                            }else{
                                DispatchQueue.main.async {
                                    self.noLabel.isHidden   = false
                                    self.tableView.isHidden = true
                                }
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                        
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return titleNotify.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell   = tableView.dequeueReusableCell(withIdentifier: "adminNotification", for: indexPath) as! AdminNotificationTableViewCell
            
        let string          = notify[indexPath.row] as? String
        cell.title.text     = titleNotify[indexPath.row] as? String
        cell.shortDesc.text = string!.replacingOccurrences(of: "<[^>]+>", with: "", options: .regularExpression, range: nil)
        cell.timeDate.text  = dateTime[indexPath.row] as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let storyboard       = UIStoryboard(name: "Note", bundle: nil)
        let secondVC         = storyboard.instantiateViewController(withIdentifier: "showNotificationModel") as! ShowNotificationModelViewController
        
        let title = titleNotify[indexPath.row] as! String
        let notificationString = notify[indexPath.row] as! String
        
        secondVC.titleNotification   =  title
        secondVC.notification        =  notificationString
        
        self.modalPresentationStyle = .popover
        self.present(secondVC, animated: true)
    }
    
    

}
