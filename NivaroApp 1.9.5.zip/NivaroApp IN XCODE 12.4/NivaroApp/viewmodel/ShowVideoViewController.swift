//
//  ShowVideoViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 24/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit
import Foundation
import AVKit
import AVFoundation
import UserNotifications

class ShowVideoViewController: UIViewController,UITextViewDelegate,UITableViewDelegate,UITableViewDataSource, UITextFieldDelegate {
    
    var isPlayed     = false
    
    @IBOutlet weak var navigationBar: UINavigationItem!
    
    @IBOutlet weak var taggedBtn: UIBarButtonItem!
    
    @IBOutlet weak var passwordBtn: UIBarButtonItem!
    
    @IBOutlet weak var shiftingFolderMainView: UIView!
    
    @IBOutlet weak var shiftingFolderTableView: UITableView!
    
    @IBOutlet weak var playerView: UIView!
    
    
    var noteID         : String = ""
    var parentID       : String = ""
    var folderID       : String = ""
    var userid         : String = ""
    var html           : String = ""
    var fileID         : String = ""
    var label_name     : String = ""
    var note_name      : String = ""
    var is_taged       : String = ""
    var userID         : String = ""
    var password       : String = ""
    var nameImg        : String = ""
    var videoUrl       : String = ""
    var sections       : String = ""
    
    var spiner  = UIActivityIndicatorView()
    
    // Swip Folder Data
    var shiftingValue   : [Any] = []
    var shiftingFolders : [Any] = []
    
    let user_id    = UserDefaults.standard.string(forKey: "userID")
    let loginKey   = UserDefaults.standard.string(forKey:"loginKey")
    
    var datePicker  = UIDatePicker()
    var timePicker  = UIDatePicker()
    
    override func viewDidLoad() {
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        getAllFolderOfSection()
        shiftingFolderMainView.isHidden = true
        shiftingFolderTableView.delegate = self
        
        super.viewDidLoad()
        
        getNoteDetails(noteID: noteID)
        
        navigationBar.title = nameImg
        
        shiftingFolderTableView.tableFooterView = UIView()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
//        if sections == "2"{
            
            guard let videoURL = URL(string: videoUrl) else {
                return
            }
            
            let player = AVPlayer(url: videoURL)
            let playerLayer = AVPlayerLayer(player: player)
            playerLayer.frame = CGRect(x: 0,  y: 0 , width: playerView.frame.width, height: playerView.frame.height)//self.playerView.bounds
            
            
            let button = UIButton()
            //button.backgroundColor   = UIColor.systemRed
            button.frame.size.width  = 100
            button.frame.size.height = 100
            button.frame = CGRect(x: self.playerView.frame.size.width/2 - button.frame.size.width/2, y: self.playerView.frame.size.height/2 - button.frame.size.height/2, width: button.frame.width, height: button.frame.height)
            //button.setBackgroundImage(UIImage(named: "play.circle"), for: UIControl.State.highlighted)
            button.tintColor = UIColor.white
            button.backgroundColor = UIColor.orange
            button.setBackgroundImage(UIImage(named: "play.circle"), for: UIControl.State.normal)
            button.addTarget(self, action: #selector(playVideoBtn), for: .touchUpInside)
            button.layer.cornerRadius = 5
            
            self.playerView.layer.addSublayer(playerLayer)
            self.playerView.addSubview(button)
            player.pause()
        
        spiner.stopAnimating()
        self.view.isUserInteractionEnabled = true
    }
    
    
    @objc func playVideoBtn(_ sender: Any) {

            var player               = AVPlayer()
            let playerViewController = AVPlayerViewController()

            guard let videoURL = URL(string: videoUrl) else {
                return
            }

            player = AVPlayer(url: videoURL)
            playerViewController.player = player
            self.present(playerViewController, animated: true) {
                playerViewController.player?.play()
            }
    }
    
    func getNoteDetails(noteID:String){
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/view_note/")!)
        request.httpMethod  = "POST"
        let postString      = "noteID=\(noteID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                
                                if let content = json["data"] as? [[String:Any]] {
                                    DispatchQueue.main.async {
                                        self.folderID = content[0]["noteID"] as! String
                                        self.userid   = content[0]["userID"] as! String
                                        self.html     = content[0]["text"] as! String
                                        self.fileID   = content[0]["fileID"] as! String
                                        self.label_name = content[0]["label_name"] as! String
                                        self.note_name  = content[0]["note_name"] as! String
                                        self.is_taged   = content[0]["is_taged"] as! String
                                        self.userID     = content[0]["userID"] as! String
                                        self.password   = content[0]["password"] as? String ?? ""
                                        
                                        
                                        
                                        
                                        if self.is_taged == "true"{
                                            self.taggedBtn.image = UIImage(named: "bookmark.circle.fill")
                                            self.taggedBtn.tintColor  = UIColor.systemRed
                                        }else{
                                            self.taggedBtn.image = UIImage(named: "bookmark.circle")
                                            self.taggedBtn.tintColor  = UIColor.white
                                        }
                                        
                                        if self.password.isEmpty == false {
                                            self.passwordBtn.tintColor  = UIColor.systemRed
                                        }else{
                                            self.passwordBtn.tintColor  = UIColor.white
                                        }
                                        
                                        // Player Load Video
                                        //let url = URL(string: self.html)!
                                        
                                        //                                        self.player = AVPlayer(url: url)
                                        //                                        self.player.play()
                                    }
                                }else{
                                    print("JSON DECODE ERROR")
                                }
                            }else{
                                print("Responce Error")
                            }
                        }
                    } catch let error {
                        print(error.localizedDescription)
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    func getAllFolderOfSection(){
        
        var item : [Any] = []
        var klik : [Any] = []
        
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/Show_folder_by_section/")!)
        request.httpMethod  = "POST"
        let postString      = "control=show_sec_folder&userID=\(user_id!)&sectionID=\(sections)"
        request.httpBody    = postString.data(using: .utf8)
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                print ("error")
            }else{
                if let urlContent = data{
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                
                                if let content = json["data"] as? [[String:Any]] {
                                    for category in content{
                                        let folderID    =   category["folderID"]!
                                        let name        =   category["name"]!
                                        
                                        item.append(name)
                                        klik.append(folderID)
                                    }
                                    DispatchQueue.main.async {
                                        self.shiftingFolders = item
                                        self.shiftingValue   = klik
                                        self.shiftingFolderTableView.reloadData()
                                    }
                                }// json Conversion close for data
                            }else{
                                let message = "No Any Data Found"
                                let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
                                self.present(alert, animated: true)
                                // duration in seconds
                                let duration: Double = 3
                                DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + duration) {
                                    alert.dismiss(animated: true)
                                }
                            }// Close Status conversion OF Result
                        }
                    } catch let error {
                        print(error.localizedDescription)
                    }// Do And Catch Close
                }// URL Content CLose
            }//Task Control Close
        }
        task.resume()
    }
    
    
    /* TOOLBAR ICON BTN */
    
    @IBAction func showShiftingFolder(_ sender: Any) {
        shiftingFolderMainView.isHidden = false
        shiftingFolderTableView.reloadData()
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return shiftingFolders.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = shiftingFolderTableView.dequeueReusableCell(withIdentifier: "sfnCell", for: indexPath) as! SwipFolderNoteTableViewCell
        cell.labelName.text  = shiftingFolders[indexPath.row] as? String
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let folderSelect = shiftingValue[indexPath.row] as! String
        shiftingFolderMainView.isHidden = true
        
        // move note api call
        var request         = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/move_notes/")!)
        request.httpMethod  = "POST"
        let postString      = "userID=\(user_id!)&noteID=\(noteID)&control=move_notes&folderID=\(folderSelect)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                DispatchQueue.main.async {
                                    let message = json["message"] as! String
                                    let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }else{
                                DispatchQueue.main.async {
                                    let message = "Can't Move Note Now. Try Later."
                                    let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    }catch let error {
                        
                        let err = (error.localizedDescription)
                        let message = err
                        DispatchQueue.main.async {
                            let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }
            }
        }
        task.resume()
    }
    
    
    @IBAction func shareIt(_ sender: Any) {
      
        let videoUrl = URL(string: self.videoUrl)
        let activityVC = UIActivityViewController(activityItems: [videoUrl!] , applicationActivities: nil)
        
        present(activityVC, animated: true, completion: nil)
    }
    
    @IBAction func taggedImage(_ sender: Any) {
        if is_taged == "true"{
            let alert = UIAlertController(title: "Bookmark Alert", message: "This Note Is Allredy Bookmarked. Do you want to remove From Bookmark ?", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: { action in
                
                // Remove From Bookmark
                self.taggingNote(tags: "false")
                
            }))
            
            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            
            taggingNote(tags: "true")
        }
    }
    
    
    func taggingNote(tags:String) {
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/add_tag/")!)
        request.httpMethod  = "POST"
        let postString      = "control=tag_note&userID=\(self.userID)&noteID=\(self.noteID)&tags=\(tags)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                DispatchQueue.main.async {
                                    self.is_taged   = tags
                                    if self.is_taged == "true"{
                                        self.taggedBtn.image      = UIImage(named: "bookmark.circle.fill")
                                        self.taggedBtn.tintColor  = UIColor.systemRed
                                    }else{
                                        self.taggedBtn.image = UIImage(named: "bookmark.circle")
                                        self.taggedBtn.tintColor  = UIColor.white
                                    }
                                }
                            }else{
                                let alert = UIAlertController(title: "Nivaro Error", message: "Server seems busy try later", preferredStyle: UIAlertController.Style.alert)
                                alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                self.present(alert, animated: true, completion: nil)
                            }
                        }
                    } catch let error {
                        print(error.localizedDescription)
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    @IBAction func setPassword(_ sender: Any) {
        
        if password != ""{
           
            let Message = "This Video Is Password Protected . If You need To Remove Password Then left Password Field Blank."
            setNotePassword(message: Message)
        }else{
            
            let Message = "All Fields Are Mendetory!.Please Fill All Fields."
            setNotePassword(message: Message)
        }
    }
    
    func setNotePassword(message:String){
        if password != ""{
            
            let alertController = UIAlertController(title: "Update Note Password", message:message, preferredStyle: UIAlertController.Style.alert)
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter Login Password"
            }
            
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter File Password"
            }
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter Verify Password"
            }
            
            let saveAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { [self] alert -> Void in
                
                let loginPassword   = alertController.textFields![0] as UITextField
                let notePassword    = alertController.textFields![1] as UITextField
                let verifyPassword  = alertController.textFields![2] as UITextField
                
                let alertLoginTxt   = loginPassword.text!
                let alertNotePass   = notePassword.text!
                let verifyNotePass  = verifyPassword.text!
                
                if alertLoginTxt != loginKey{
                    let message = "Login Password Not Matched. Try Again."
                    setNotePassword(message:message)
                }else if alertNotePass != verifyNotePass{
                    let message = "Password Not Matched With Verify Password. Password And Verify Password Shuld Be same."
                    setNotePassword(message:message)
                }else{
                    savePasswordForNote(notePass: alertNotePass)
                }
                
            })
            
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler:nil)
            
            alertController.addAction(saveAction)
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true, completion: nil)
            
        }else{
            
            let alertController = UIAlertController(title: "Set Password", message: message, preferredStyle: UIAlertController.Style.alert)
            /* Add Text Boxes */
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter Login Password"
            }
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter File Password"
            }
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter Verify Password"
            }
            
            let saveAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { [self] alert -> Void in
                
                let loginPassword   = alertController.textFields![0] as UITextField
                let notePassword    = alertController.textFields![1] as UITextField
                let verifyPassword  = alertController.textFields![2] as UITextField
                
                let alertLoginTxt   = loginPassword.text!
                let alertNotePass   = notePassword.text!
                let verifyNotePass  = verifyPassword.text!
                
                if alertLoginTxt != loginKey{
                    
                    let message = "Login Password Not Matched. Try Again."
                    setNotePassword(message:message)
                    
                }else if alertNotePass.isEmpty{
                    
                    let message = "Password And Verify Password could not be blank. Please enter Password And Verify Password."
                    setNotePassword(message:message)
                    
                }else if alertNotePass != verifyNotePass{
                    
                    let message = "Password Not Matched With Verify Password. Password And Verify Password Shuld Be same."
                    setNotePassword(message:message)
                    
                }else{
                    savePasswordForNote(notePass: alertNotePass)
                }
                
            })
            
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler:nil)
            
            alertController.addAction(saveAction)
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true, completion: nil)
            
        }
    }
    
    
    func savePasswordForNote(notePass:String) {
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        //notePasswordSet api call
        var request         = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/SetPassword/")!)
        request.httpMethod  = "POST"
        let postString      = "noteID=\(noteID)&password=\(notePass)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    self.password = notePass
                                    
                                    var titleAlert = ""
                                    if notePass != ""{
                                        self.passwordBtn.tintColor  = UIColor.systemRed
                                        titleAlert = "Password Set Successfully"
                                    }else{
                                        self.passwordBtn.tintColor  = UIColor.white
                                        titleAlert = "Password Removed Successfully"
                                    }
                                    let message = json["message"] as! String
                                    let alert = UIAlertController(title: titleAlert, message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                
                            }else{
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    let message = "Can't set note password. Please try later."
                                    let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    }catch let error {
                        let err = (error.localizedDescription)
                        let message = err
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }
            }
        }
        task.resume()
        
    }
    
    
    @IBAction func deleteItem(_ sender: Any) {
        let alert = UIAlertController(title: "Confirm Delete ?", message: "Are You Sure To Delete This Note?", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: { action in
            
            // Remove From Bookmark
            self.deleteNoteNow()
            
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    func deleteNoteNow(){
        
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        let deleteID = noteID
        let user_id  = userID
        
        // Calling API
        var request         = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/delete_note/")!)
        request.httpMethod  = "POST"
        let postString      = "userID=\(user_id)&noteID=\(deleteID)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let message = "Loading Error. Try again"
                    let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                
                if let urlContent = data{
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    self.dismissController()
                                }
                            }else{
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    let message = "No Any Data Found"
                                    let alert = UIAlertController(title: "Nivaro Success", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                        
                    }catch let error {
                        
                        let err = (error.localizedDescription)
                        let message = err
                        DispatchQueue.main.async {
                            
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }
            }
        }
        task.resume()
    }
    
    
    func dismissController() {
        
        DispatchQueue.main.async {
            let noteVC = self.storyboard?.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController

            noteVC.reloadView = "true"
            pageLoad = "yes"
            self.navigationController?.popViewController(animated: true)
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func setAlarm(_ sender: Any) {
        let myDatePicker: UIDatePicker = UIDatePicker()
        // setting properties of the datePicker
        myDatePicker.timeZone = NSTimeZone.local
        myDatePicker.frame = CGRect(x: 30, y: 15, width: 270, height: 200)

        let alertController = UIAlertController(title: "Select Date And Time \n\n\n\n\n\n\n\n", message: nil, preferredStyle: UIAlertController.Style.alert)
        alertController.view.addSubview(myDatePicker)
        
        let somethingAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { alert -> Void in
            
            let dateFormatter = DateFormatter()

            dateFormatter.dateStyle   = DateFormatter.Style.short
            dateFormatter.timeStyle   = DateFormatter.Style.short
            dateFormatter.dateFormat  = "yyyy-MM-dd HH:mm:ss"

            let strDate = dateFormatter.string(from: myDatePicker.date)
            let date    = dateFormatter.date(from: strDate)
            
            // Creating Usernotification
            let center = UNUserNotificationCenter.current()

            center.requestAuthorization(options: [.alert, .badge, .sound]) { [self] (granted, error) in
                if granted {
                    self.scheduleNotification(dateString:date!, dateInString: strDate)
                } else {
                    print("D'oh")
                }
            }
            
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil)
        
        alertController.addAction(somethingAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion:{})
    }
    
    
    func scheduleNotification(dateString:Date,dateInString:String) {
        
        let center    = UNUserNotificationCenter.current()
        let content   = UNMutableNotificationContent()
        content.title = note_name
        content.body  = html
        content.categoryIdentifier = "alarm"
        content.userInfo = ["type": "video","videoID":"\(String(describing: videoUrl))"]
        content.sound = UNNotificationSound.default
        
        let calendar   = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day, .hour,.minute,.second], from: dateString.addingTimeInterval(2))
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        
        let identifires = UUID().uuidString
        
        let request = UNNotificationRequest(identifier: identifires, content: content, trigger: trigger)
        
        center.add(request, withCompletionHandler: {(error) in
            if error != nil {
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Reminder Error!", message: "Reminder Can't Set", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                
                //let dateFormatter = DateFormatter()
//                let saveData = ["identifire":identifires, "title":self.note_name, "body": self.html, "time":dateInString]
                
                DispatchQueue.main.async {
                    //NotificationData.notify.save(object:saveData)
                    
                    let alert = UIAlertController(title: "Reminder Set", message: "Reminder Set SuccessFully for '\(self.note_name)'", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        })
    }

    
    /* ----------------------------------  Over Ride For Tuch Detection ----------------------*/
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        
        let touch: UITouch? = touches.first
        //location is relative to the current view
        
        if touch?.view != shiftingFolderTableView {
            shiftingFolderMainView.isHidden = true
        }
        
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}
