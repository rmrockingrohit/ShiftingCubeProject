//
//  SupportViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 19/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class SupportViewController: UIViewController,UITextViewDelegate {

    let usersName  = UserDefaults.standard.string(forKey: "UserName")
    let loginKey   = UserDefaults.standard.string(forKey: "loginKey")
    let userID     = UserDefaults.standard.string(forKey: "userID")
    
    
    @IBOutlet weak var subjectText: UITextField!
    @IBOutlet weak var queryText: UITextField!
    @IBOutlet weak var outletPasswordView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        outletPasswordView.layer.borderWidth = 1.0
        outletPasswordView.layer.borderColor = CGColor(red: 255/255, green: 14/255, blue: 0/255, alpha: 1)
        
        subjectText.textColor   = UIColor(named: "lightgray")
        queryText.textColor = UIColor(named: "lightgray")
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }

    @IBAction func sendQuery(_ sender: Any) {
        
        let subjectTxt = subjectText.text
        let queryTxt   = queryText.text
        
        if (((subjectTxt?.isEmpty) != nil) || (subjectTxt == "")){
            let alert = UIAlertController(title: "Nivaro Subject Blank", message: "Subject Field can't be empty.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else if (((queryTxt?.isEmpty) != nil) || (queryTxt == "")){
            let alert = UIAlertController(title: "Nivaro Subject Blank", message: "Subject Field can't be empty.", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
        }else{
            
            var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/support/")!)
                        request.httpMethod  = "POST"
                        let postString      = "control=support&userID=\(userID!)&subject=\(subjectTxt!)&query=\( queryTxt!)"
                        request.httpBody    = postString.data(using: .utf8)
                        
                        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
                            if error != nil{
                                print(error?.localizedDescription as Any)
                            }else{
                                if let urlContent = data{
                                    do{
                                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: String] {
                                            if let status = json["result"], status == "true" {
                                                
                                                DispatchQueue.main.async {
                                                    let alert = UIAlertController(title: "Nivaro Query Submited", message: "Hi ! \(self.usersName!). Your Query hasbeen Submitted. We Will Contect You As soon.", preferredStyle: UIAlertController.Style.alert)
                                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                                    self.present(alert, animated: true, completion: nil)
                                                }
                                                
                                            }else{
                                                
                                                DispatchQueue.main.async {
                                                    let alert = UIAlertController(title: "Nivaro", message: "Query can't submit now . Try later.", preferredStyle: UIAlertController.Style.alert)
                                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                                    self.present(alert, animated: true, completion: nil)
                                                }
                                                
                                            }
                                        }
                                    } catch let error {
                                        DispatchQueue.main.async {
                                            let alert = UIAlertController(title: "Nivaro", message: error.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                            self.present(alert, animated: true, completion: nil)
                                        }
                                       
                                    }// Do And Catch Close
                                }// URL Content CLose]
                            }//Task Control Close
                        }
                        task.resume()
            
        }
            
        
    }
    

}
