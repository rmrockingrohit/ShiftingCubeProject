//
//  PaymentViewController.swift
//  NivaroApp
//
//  Created by rohit mishra on 15/07/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit
import WebKit

class PaymentViewController: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    let userID  = UserDefaults.standard.string(forKey: "userID")
    
    override func viewDidLoad() {
        super.viewDidLoad()
       
            self.view.addSubview(webView)
        let url = URL(string: "https://payment.nivaro.com.au/stripe/Welcome/index?userID="+userID!)
            webView.load(URLRequest(url: url!))
    }
}
