//
//  FAQViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 19/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit
import WebKit

class FAQViewController: UIViewController,WKNavigationDelegate {
    
    @IBOutlet weak var webView: WKWebView!
    var spiner  = UIActivityIndicatorView()
    
    let viewportScriptString = "var meta = document.createElement('meta'); meta.setAttribute('name', 'viewport'); meta.setAttribute('content', 'width=device-width'); meta.setAttribute('initial-scale', '1.0'); meta.setAttribute('maximum-scale', '1.0'); meta.setAttribute('minimum-scale', '1.0'); meta.setAttribute('user-scalable', 'no'); document.getElementsByTagName('head')[0].appendChild(meta);"
    let disableSelectionScriptString = "document.documentElement.style.webkitUserSelect='none';"
    let disableCalloutScriptString = "document.documentElement.style.webkitTouchCallout='none';"
    
    
//    override func viewDidLoad() {
//        super.viewDidLoad()
//        let url = URL(string: "https://faq.nivaro.com.au/")!
//        webView.load(URLRequest(url: url))
//    }
        
//    func webView(_ webView: WKWebView, didCommit navigation: WKNavigation!) {
//        // Spiners Start
//        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
//        spiner.center = view.center
//        spiner.style  = UIActivityIndicatorView.Style.large
//        spiner.color  = .orange
//        spiner.hidesWhenStopped = true
//        view.addSubview(spiner)
//        spiner.startAnimating()
//        self.view.isUserInteractionEnabled = false
//    }
//
//    func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
//        DispatchQueue.main.async {
//            self.spiner.stopAnimating()
//            self.view.isUserInteractionEnabled = true
//        }
//    }
    
    
    override func viewDidLoad() {
            // 1 - Make user scripts for injection
        let viewportScript = WKUserScript(source: viewportScriptString, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        let disableSelectionScript = WKUserScript(source: disableSelectionScriptString, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        let disableCalloutScript = WKUserScript(source: disableCalloutScriptString, injectionTime: .atDocumentEnd, forMainFrameOnly: true)

            // 2 - Initialize a user content controller
            // From docs: "provides a way for JavaScript to post messages and inject user scripts to a web view."
            let controller = WKUserContentController()

            // 3 - Add scripts
            controller.addUserScript(viewportScript)
            controller.addUserScript(disableSelectionScript)
            controller.addUserScript(disableCalloutScript)

            // 4 - Initialize a configuration and set controller
            let config = WKWebViewConfiguration()
            config.userContentController = controller

            // 5 - Initialize webview with configuration
            let nativeWebView = WKWebView(frame: CGRect.zero, configuration: config)

            // 6 - Webview options
            nativeWebView.scrollView.isScrollEnabled = true               // Make sure our view is interactable
            nativeWebView.scrollView.bounces = false                    // Things like this should be handled in web code
            nativeWebView.allowsBackForwardNavigationGestures = false   // Disable swiping to navigate
            nativeWebView.contentMode = .scaleToFill                    // Scale the page to fill the web view
            // 7 - Set the scroll view delegate
            nativeWebView.scrollView.delegate = NativeWebViewScrollViewDelegate.shared
        
            let url = URL(string: "https://faq.nivaro.com.au/")!
            webView.load(URLRequest(url: url))
        }
    
}

class NativeWebViewScrollViewDelegate: NSObject, UIScrollViewDelegate {

    // MARK: - Shared delegate
    static var shared = NativeWebViewScrollViewDelegate()

    // MARK: - UIScrollViewDelegate
    func viewForZoomingInScrollView(scrollView: UIScrollView) -> UIView? {
        return nil
    }

}
