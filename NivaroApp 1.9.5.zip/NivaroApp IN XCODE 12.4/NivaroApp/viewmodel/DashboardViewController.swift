//
//  DashboardViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 13/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//
import Foundation
import UIKit

class DashboardViewController: UIViewController,UICollectionViewDelegate,UICollectionViewDataSource,UITableViewDelegate,UITableViewDataSource{
    
    
    @IBOutlet weak var mainMenuView: UIView!
    @IBOutlet weak var menuTableView: UITableView!
    @IBOutlet weak var collectionView: UICollectionView!
    @IBOutlet weak var menuPresentView: UIView!
    @IBOutlet weak var userNameLabel: UILabel!
    @IBOutlet weak var userInfoView: UIView!
    @IBOutlet weak var mainMenuBtn: UIBarButtonItem!
    
    @IBOutlet weak var editProfile: UIButton!
    
    var screenSize: CGRect!
    var screenWidth: CGFloat!
    var screenHeight: CGFloat!
    var dashboardData = [AppInfoDelegete]()
    var arrData = [DashboardModel]()
    var arrDataMenu = [MainMenuModel]()
    
    var spiner  = UIActivityIndicatorView()
    
    //userDefaultes
    let usersName  = UserDefaults.standard.string(forKey: "UserName")
    var menu_open:Bool = false
    
    override func viewDidLoad() {
        editProfile.isHidden = true
        super.viewDidLoad()
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        mainMenuView.isHidden = true
        mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
        
        arrData = DashboardData.getAllDashboardItem()
        
        arrDataMenu = MainMenuData.getMain()
        
        userNameLabel.text = usersName
        
        let navBar = self.navigationController?.navigationBar
        
        let tinColor = UIColor(hex: "#D35400")
        navBar?.barTintColor = tinColor
        
        navBar?.tintColor = UIColor.white
        
        navBar?.isTranslucent = false
        
        navBar?.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
        
        self.collectionView.contentInset = UIEdgeInsets(top: 5, left: 5, bottom: 10, right: 10)
        self.collectionView.dataSource = self
        self.collectionView.delegate = self
        
        screenSize = UIScreen.main.bounds
        screenWidth = screenSize.width
        screenHeight = screenSize.height
        
        //let collectionViewFLowLayout = UICollectionViewFlowLayout()
        
        let layout: UICollectionViewFlowLayout = UICollectionViewFlowLayout()
        layout.sectionInset = UIEdgeInsets(top: 20, left: 20, bottom: 20, right: 20)
        layout.itemSize = CGSize(width: screenWidth / 2, height: screenWidth / 2)
        layout.minimumInteritemSpacing = 0
        layout.minimumLineSpacing = 0
       //self.collectionView = UICollectionView(frame: self.view.frame, collectionViewLayout: layout)
        
        spiner.stopAnimating()
        self.view.isUserInteractionEnabled = true
        
        menu_open = false
        
    }
    
    
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
            return arrData.count
        
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
       
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "dashCell", for: indexPath) as! DashboardCollectionViewCell
            cell.images.image = arrData[indexPath.row].img
            cell.names.text   = arrData[indexPath.row].title
            cell.layer.cornerRadius = 10
            return cell
        
    }
    
    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
        
       
            if indexPath.row == 0
            {
                return CGSize(width: screenWidth, height: screenWidth/2)
            }
        
        return CGSize(width: screenWidth/2, height: screenWidth/2);
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        let type = arrData[indexPath.row].title
        
        
        //switch type {
        
        //case ("Notes"):
        if type == "Notes"{
            dashboardData = AppInfoData.addAppInfo(sectionName: "Notes",sectionID:"1")
            
            let storyboard = UIStoryboard(name: "Note", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
        //case ("Images"):
        }else if type == "Images"{
            dashboardData = AppInfoData.addAppInfo(sectionName: "Images",sectionID:"4")
            
            let storyboard = UIStoryboard(name: "Note", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
        //case ("Videos"):
        }else if type == "Videos"{
            dashboardData = AppInfoData.addAppInfo(sectionName: "Videos",sectionID:"2")
            
            let storyboard = UIStoryboard(name: "Note", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
        //case ("Audios"):
        }else if type == "Audios"{
            dashboardData = AppInfoData.addAppInfo(sectionName: "Audios",sectionID:"3")
            
            let storyboard = UIStoryboard(name: "Note", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
        //case ("Reminders"):
        }else if type == "Reminders"{
            let storyboard = UIStoryboard(name: "Reminder", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "reminder_vc") as! ReminderViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
        //case ("Folders"):
        }else if type == "Folders"{
            let storyboard = UIStoryboard(name: "Folders", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "folders_vc") as! FoldersViewController
            
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
        //default:
        }else{
            dashboardData = AppInfoData.addAppInfo(sectionName: "",sectionID:"")
        }
        
    }
    
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrDataMenu.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MainMenuCell") as! MainMenuTableViewCell
        cell.menuIcon.image = arrDataMenu[indexPath.row].img
        cell.menuNameLabel.text = arrDataMenu[indexPath.row].title
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let type = indexPath.row
        
        switch type {
        
        case (0):
            
            dashboardData = AppInfoData.addAppInfo(sectionName: "Notes",sectionID:"1")
            
            
            let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
            mainMenuView.isHidden = false
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
            
        case (1):
            
            let storyboard = UIStoryboard(name: "MyBookmarks", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "bookmark_vc") as! BookmarkViewController
            mainMenuView.isHidden = false
            let navigationController = UINavigationController(rootViewController: nextViewController)
            UIApplication.shared.windows.first?.rootViewController = navigationController
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            
        case (2):
            print("Change Password View")
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            let destinationVC = storyboard?.instantiateViewController(withIdentifier: "change_pass") as? ChangePasswordViewController
            show(destinationVC!, sender: self)
            
        case (3):
            print("support View")
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            let destinationVC = storyboard?.instantiateViewController(withIdentifier: "support") as? SupportViewController
            show(destinationVC!, sender: self)
            
        case (4):
            
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            let destinationVC = storyboard?.instantiateViewController(withIdentifier: "faq") as? FAQViewController
            show(destinationVC!, sender: self)
            
        case (5):
            
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
          //  let destinationVC = storyboard?.instantiateViewController(withIdentifier: "subscription_vc") as? SubscriptionViewController
            
            let destinationVC = storyboard?.instantiateViewController(withIdentifier: "paymentVC") as? PaymentViewController
            
            show(destinationVC!, sender: self)
            
            
        case (6):
            let defaults = UserDefaults.standard
            defaults.set(false, forKey: "isLogged")
            mainMenuView.isHidden = true
            mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height
            )
            
            DispatchQueue.main.async {
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            
            let nextViewController = storyboard.instantiateViewController(withIdentifier: "login_vc") as! ViewController
            
            UIApplication.shared.windows.first?.rootViewController = nextViewController
            
            UIApplication.shared.windows.first?.makeKeyAndVisible()
            
        default:
            dashboardData = AppInfoData.addAppInfo(sectionName: "",sectionID:"")
        }
        
    }
    
    
    
    
    @IBAction func openMenu(_ sender: Any) {
        if menu_open == false{
            UIView.animate(withDuration: 0.4) {
                self.mainMenuView.frame = CGRect(x: 0, y: 70, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
                self.mainMenuView.isHidden = false
                self.menu_open = true
                self.mainMenuBtn.image = UIImage(named: "xmark")
            }
        }else{
            UIView.animate(withDuration: 0.6) {
                self.mainMenuBtn.image = UIImage(named: "line.horizontal.3")
                self.mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: 0, height: 0)
                self.mainMenuView.isHidden = true
                self.menu_open = false
                
            }
        }
    }
    
    @IBAction func openImage(_ sender: Any) {
        dashboardData = AppInfoData.addAppInfo(sectionName: "Images",sectionID:"4")
        
        let storyboard = UIStoryboard(name: "Note", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func openVideo(_ sender: Any) {
        dashboardData = AppInfoData.addAppInfo(sectionName: "Videos",sectionID:"2")
        
        let storyboard = UIStoryboard(name: "Note", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func openAudio(_ sender: Any) {
       dashboardData = AppInfoData.addAppInfo(sectionName: "Audios",sectionID:"3")
        
        let storyboard = UIStoryboard(name: "Note", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "note_vc") as! NoteViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func allFolders(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Folders", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "folders_vc") as! FoldersViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    @IBAction func reminders(_ sender: Any) {
        let storyboard = UIStoryboard(name: "Reminder", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "reminder_vc") as! ReminderViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
        DispatchQueue.main.async {
            self.spiner.stopAnimating()
            self.view.isUserInteractionEnabled = true
        }
    }
    
    
    @IBAction func mainMenuOpen(_ sender: Any) {
        if menu_open == false{
            UIView.animate(withDuration: 0.4) {
                self.mainMenuView.frame = CGRect(x: 0, y: 70, width: UIScreen.main.bounds.size.width, height: UIScreen.main.bounds.size.height)
                self.mainMenuView.isHidden = false
                self.menu_open = true
                self.mainMenuBtn.image = UIImage(named: "xmark")
            }
        }else{
            UIView.animate(withDuration: 0.6) {
                self.mainMenuBtn.image = UIImage(named: "line.horizontal.3")
                self.mainMenuView.frame = CGRect(x: -UIScreen.main.bounds.size.width, y: 0, width: 0, height: 0)
                self.mainMenuView.isHidden = true
                self.menu_open = false
                
            }
        }
    }
    
}

