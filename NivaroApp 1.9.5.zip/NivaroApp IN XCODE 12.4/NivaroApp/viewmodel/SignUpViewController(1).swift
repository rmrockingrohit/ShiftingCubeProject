//
//  SignUpViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 12/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class SignUpViewController: UIViewController,UITextViewDelegate {
    
    @IBOutlet weak var name: UITextField!
    
    @IBOutlet weak var email: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        name.textColor = UIColor(named: "lightgray")
        email.textColor = UIColor(named: "lightgray")
        password.textColor = UIColor(named: "lightgray")
    }
    
    @IBAction func loginBtn(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "login_vc") as! ViewController
        
        UIApplication.shared.windows.first?.rootViewController = nextViewController
        
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
    }
    
    @IBAction func signUpUser(_ sender: Any) {
        
        let userName = name.text!
        let userMail = email.text!
        let userKey  = password.text!
        let reg_id   = ""
        
        var spiner = UIActivityIndicatorView()
        
        if userName == ""{
            DispatchQueue.main.async {
                
                let alertController = UIAlertController(title: "Nivaro Alert Error", message: "Please Fill Full Name", preferredStyle: UIAlertController.Style.alert)
                
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                    self.dismiss(animated: true, completion: nil)
                }))
                
                self.present(alertController, animated: true, completion: nil)
            }
        }else if userMail == ""{
            DispatchQueue.main.async {
                
                let alertController = UIAlertController(title: "Nivaro Alert Error", message: "Please Fill Email-ID", preferredStyle: UIAlertController.Style.alert)
                
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                    self.dismiss(animated: true, completion: nil)
                }))
                
                //UIApplication.shared.endIgnoringInteractionEvents()
                
                self.present(alertController, animated: true, completion: nil)
            }
        }else if userKey == ""{
            DispatchQueue.main.async {
                
                let alertController = UIAlertController(title: "Nivaro Alert Error", message: "Please Fill Password", preferredStyle: UIAlertController.Style.alert)
                
                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                    self.dismiss(animated: true, completion: nil)
                }))
                
                //UIApplication.shared.endIgnoringInteractionEvents()
                
                self.present(alertController, animated: true, completion: nil)
            }
        }else{
            
            self.view.isUserInteractionEnabled = false
            
            // Running Spiners
            spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
            spiner.center = view.center
            spiner.hidesWhenStopped = true
            spiner.style  = UIActivityIndicatorView.Style.large
            spiner.color  = .orange
            view.addSubview(spiner)
            spiner.startAnimating()
            
            var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/register/")!)
            
            request.httpMethod = "POST"
            
            let postString = "control=signup&email=\(String(describing: userMail))&password=\(String(describing: userKey))&name=\(String(describing: userName))&reg_id=\(reg_id)"
            
            request.httpBody = postString.data(using: .utf8)
            
            let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                
                if error != nil{
                    
                    DispatchQueue.main.async {
                        
                        spiner.stopAnimating()
                        self.view.isUserInteractionEnabled = true
                    }
                    
                    let errors = error?.localizedDescription
                    
                    let alert = UIAlertController(title: "Nivaro Error.", message: errors, preferredStyle: .alert)
                    self.present(alert, animated: true)
                    
                    // duration in seconds
                    let duration: Double = 3
                    
                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + duration) {
                        
                        alert.dismiss(animated: true)
                        
                    }
                    
                }else{
                    
                    if let urlContent = data{
                        
                        do {
                            //create json object from data
                            if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                                if let status = json["result"] as? String, status == "true" {
                                    
                                    // Define UserDefault For Data Store In Local Device
                                    let defaults = UserDefaults.standard
                                    
                                    // Storing Response Data to userData Key
                                    defaults.set(json["result"] as! String as Any?, forKey: "userID")
                                    
                                    defaults.set(userName, forKey: "UserName")
                                    
                                    // Setting And Storing Login Info In isLogged Variable
                                    defaults.set(true, forKey: "isLogged")
                                    
                                    // Defining the baseUrl For App
                                    defaults.set("https://nivaroapp.nivaro.com.au",forKey: "baseUrl")
                                    
                                    defaults.synchronize()
                                    
                                    DispatchQueue.main.async {
                                        
                                        spiner.stopAnimating()
                                        
                                        self.view.isUserInteractionEnabled = true
                                        
                                        let refreshAlert = UIAlertController(title: "Sign Up Completed.", message: "Thanks! your account has been successfully created.", preferredStyle: UIAlertController.Style.alert)

                                        refreshAlert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { (action: UIAlertAction!) in
                                            
                                            self.showSecondViewController()
                                            
                                        }))
                                        
                                        self.present(refreshAlert, animated: true, completion: nil)
                                    
                                    }
                                    
                                }else{
                                    
                                    DispatchQueue.main.async {
                                        
                                        spiner.stopAnimating()
                                        
                                        self.view.isUserInteractionEnabled = true
                                    }
                                    
                                    let message = json["message"] as? String
                                    
                                    let alert = UIAlertController(title: "Nivaro Error.", message: message, preferredStyle: .alert)
                                    
                                    self.present(alert, animated: true)
                                    
                                    // duration in seconds
                                    let duration: Double = 3
                                    
                                    DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + duration) {
                                        
                                        alert.dismiss(animated: true)
                                        
                                    }
                                    
                                }
                            }
                        }catch let error {
                            
                            DispatchQueue.main.async {
                                
                                spiner.stopAnimating()
                                
                                self.view.isUserInteractionEnabled = true
                            }
                            
                            
                            let err  = error.localizedDescription
                            
                            let message = err
                            
                            let alert = UIAlertController(title: "Nivaro Error.", message: message, preferredStyle: .alert)
                            
                            self.present(alert, animated: true)
                            
                            // duration in seconds
                            let duration: Double = 3
                            
                            DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + duration) {
                                
                                alert.dismiss(animated: true)
                                
                            }
                            
                        }// Do And Catch Close
                        
                    }
                    
                }// else closed
                
                
            }// task completed
            
            task.resume()
            
        }
        
    }
    
    func showSecondViewController() {
        let storyboard = UIStoryboard(name: "Dashboard", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "dashboard_vc") as! DashboardViewController
        
        let navigationController = UINavigationController(rootViewController: nextViewController)
        UIApplication.shared.windows.first?.rootViewController = navigationController
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}
    
    

