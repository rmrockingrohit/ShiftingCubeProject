//
//  LabelNameViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 30/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit



class LabelNameViewController: UIViewController {
    var noteID = ""
    
    @IBOutlet weak var textView: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        textView.layer.borderColor = CGColor(red: 190/255, green: 14/255, blue: 0/255, alpha: 1)
        textView.layer.borderWidth = 2.0
    }

    @IBAction func cancleView(_ sender: Any) {
       
        self.dismiss(animated: true, completion: nil)
       
    }
    
    @IBAction func saveLabel(_ sender: Any) {
        let textLabel = textView.text!
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/Edit_label/")!)
        request.httpMethod  = "POST"
        let postString      = "noteID=\(noteID)&label_name=\(textLabel)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                
                DispatchQueue.main.async {
                    let message = error?.localizedDescription
                    let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
                
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                DispatchQueue.main.async {
                                    let message = json["message"] as! String
                                    let alert = UIAlertController(title: "Label Updated", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                
                            }else{
                                DispatchQueue.main.async {
                                    let message = json["message"] as! String
                                    let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                print("Responce Error")
                            }
                        }
                    } catch let error {
                        
                        DispatchQueue.main.async {
                            let message = error.localizedDescription
                            let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
}
