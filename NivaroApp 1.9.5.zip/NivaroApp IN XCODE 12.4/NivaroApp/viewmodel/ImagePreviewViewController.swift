import UserNotifications
import UIKit

class ImagePreviewViewController: UIViewController{
    
    var noteID      : [Any] = []
    var name        : [Any] = []
    var imageUrl    : [Any] = []
    var notePass    : [Any] = []
    var isTagged    : [Any] = []
    var labelName   : [Any] = []
    var linkUrl     : [Any] = []
    
    var isTaged = ""
    
    var mainFolderID = ""
    
    @IBOutlet weak var mainView: UIImageView!
    
    @IBOutlet weak var tagButton: UIBarButtonItem!
    
    @IBOutlet weak var passwordBtn: UIBarButtonItem!
    
    @IBOutlet weak var collectionViewBond: UIImageView!
    
    @IBOutlet weak var previewImage: UIImageView!
    
    @IBOutlet weak var counterLbl: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var navTitle: UINavigationItem!
    
    
    let userID     = UserDefaults.standard.string(forKey: "userID")
    let loginKey   = UserDefaults.standard.string(forKey:"loginKey")
    
    var sectionID   = ""
    var clikedID    = ""
    var currentNote = ""
    var password    = ""
    var is_bookmarkPage = ""
    var folderTitle = ""
    
    var spiner    = UIActivityIndicatorView()
    
    
    // local variable for image preview
    
    var imagePassword : [Any] = []
    var imageView     : [Any] = []
    var imageID       : [Any] = []
    var imageName     : [Any] = []
    var indexPathImage : Int  = 0
    
    override func viewDidLoad() {
        
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        spiner.backgroundColor = UIColor.black
        spiner.alpha = 0.8
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        super.viewDidLoad()
        
        let swipeRight = UISwipeGestureRecognizer(target: self, action: #selector(respondToSwipeGesture))
        swipeRight.direction = .right
        self.view.addGestureRecognizer(swipeRight)

        let swipeLeft = UISwipeGestureRecognizer(target: self, action: #selector(respondToSwipeGesture))
        swipeLeft.direction = .left
        self.view.addGestureRecognizer(swipeLeft)
        
        getFolderItemData(userID: userID!, folder_id: mainFolderID, control: "show_note",sectionID:sectionID)
        
        if is_bookmarkPage != ""{
            navTitle.title = "Bookmark Image Slides"
        }else{
            navTitle.title = "\(folderTitle) Image Slides"
        }
    }
    
    override func viewDidAppear(_ animated: Bool) {
        
        let indexCount  = noteID.count
        for (index,clik) in noteID.enumerated(){
            
            if clikedID == noteID[index] as! String{
                //Spiners Start
                spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height))
                spiner.center = view.center
                spiner.style  = UIActivityIndicatorView.Style.large
                spiner.color  = .orange
                spiner.hidesWhenStopped = true
                spiner.backgroundColor = UIColor.black
                spiner.alpha = 0.8
                view.addSubview(spiner)
                
                spiner.startAnimating()
                self.view.isUserInteractionEnabled = false
                
                previewImage.image = UIImage(data: imageUrl[index] as! Data)
                counterLbl.text    = "\(index + 1) / \(indexCount)"
                nameLabel.text     = name[index] as? String
                self.currentNote   = noteID[index] as! String
                
                if isTagged[index] as! String == "true"{
                    tagButton.tintColor = UIColor.systemRed
                }else{
                    tagButton.tintColor = UIColor.white
                }
                
                let passKey = notePass[index] as! String
                
                if passKey.isEmpty != false{
                    self.password = passKey
                    self.passwordBtn.tintColor = UIColor.systemRed
                }else{
                    self.password = ""
                    self.passwordBtn.tintColor = UIColor.white
                }
                
                indexPathImage = index
                spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }
        }
    }
    
    
    @objc func respondToSwipeGesture(gesture: UIGestureRecognizer) {

        if let swipeGesture = gesture as? UISwipeGestureRecognizer {
            switch swipeGesture.direction {
            case .right:
                getRightSwip()
            case .left:
                getLeftSwip()
            default:
                getRightSwip()
                break
            }
        }
    }
    
    func getLeftSwip(){
        //Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        spiner.backgroundColor = UIColor.black
        spiner.alpha = 0.8
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        
        indexPathImage  =  indexPathImage + 1
        let indexCount = imageUrl.count
        if indexCount > indexPathImage{
            
           // CHECKING FOR TAGGED
            if isTagged[indexPathImage] as! String == "true"{
                tagButton.tintColor = UIColor.systemRed
            }else{
                tagButton.tintColor = UIColor.white
            }
         
            //Checking For PASSWORD
            if notePass[indexPathImage] as! String != ""{
                self.password  =  notePass[indexPathImage] as! String
                self.passwordBtn.tintColor = UIColor.systemRed
                self.askNotePassword(message: "Please Enter Image Password.",image:imageUrl[indexPathImage] as! Data,countLBL: "\(indexPathImage + 1) / \(indexCount)",nameLBL:(name[indexPathImage] as? String)!,currentNote:(noteID[indexPathImage] as! String))
            }else{
                self.password = ""
                self.passwordBtn.tintColor = UIColor.white
           
                previewImage.image = UIImage(data: imageUrl[indexPathImage] as! Data)
                counterLbl.text     = "\(indexPathImage + 1) / \(indexCount)"
                nameLabel.text      = name[indexPathImage] as? String
                self.currentNote    = noteID[indexPathImage] as! String
            }
            
        }else{
            self.indexPathImage = indexCount
        }
        
        spiner.stopAnimating()
        self.view.isUserInteractionEnabled = true
    }
    
    func getRightSwip(){
        //Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        spiner.backgroundColor = UIColor.black
        spiner.alpha = 0.8
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        indexPathImage  =  indexPathImage - 1
        if indexPathImage >= 0 {
            let indexCount = imageUrl.count
           
            if indexCount > indexPathImage{
                
                if isTagged[indexPathImage] as! String == "true"{
                    tagButton.tintColor = UIColor.systemRed
                }else{
                    tagButton.tintColor = UIColor.white
                }
                
                if notePass[indexPathImage] as! String != ""{
                    self.password  =  notePass[indexPathImage] as! String
                    self.passwordBtn.tintColor = UIColor.systemRed
                    self.askNotePassword(message: "Please Enter Image Password.",image:imageUrl[indexPathImage] as! Data,countLBL: "\(indexPathImage + 1) / \(indexCount)",nameLBL:(name[indexPathImage] as? String)!,currentNote:(noteID[indexPathImage] as! String))
                }else{
                    self.password = ""
                    self.passwordBtn.tintColor = UIColor.white
               
                    previewImage.image  = UIImage(data: imageUrl[indexPathImage] as! Data)
                    counterLbl.text     = "\(indexPathImage + 1) / \(indexCount)"
                    nameLabel.text      = name[indexPathImage] as? String
                    self.currentNote    = noteID[indexPathImage] as! String
                }
            }
        }else{
            indexPathImage = 0
        }
        
        spiner.stopAnimating()
        self.view.isUserInteractionEnabled = true
    }
    
    func askNotePassword(message:String,image:Data,countLBL:String,nameLBL:String,currentNote:String){
        let alert = UIAlertController(title: "Image Password", message: message, preferredStyle: UIAlertController.Style.alert)
        
        alert.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter Enter Password"
        }
        
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { action in
            let userPass = alert.textFields![0] as UITextField
            if userPass.text! == self.password{
                //Spiners Start
                self.spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:UIScreen.main.bounds.width,height:UIScreen.main.bounds.height))
                self.spiner.center = self.view.center
                self.spiner.style  = UIActivityIndicatorView.Style.large
                self.spiner.color  = .orange
                self.spiner.hidesWhenStopped = true
                self.spiner.backgroundColor = UIColor.black
                self.spiner.alpha = 0.8
                self.view.addSubview(self.spiner)
                self.spiner.startAnimating()
                self.view.isUserInteractionEnabled = false
                
                self.previewImage.image = UIImage(data: image)
                self.counterLbl.text    = countLBL
                self.nameLabel.text     = nameLBL
                self.currentNote        = currentNote
                
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
            }else{
                self.askNotePassword(message: "Password Is Incorrect. Please Enter Valid Image Password.", image: image, countLBL: countLBL, nameLBL: nameLBL, currentNote: currentNote)
            }
        }))

        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
    
    // Getting All Images In Folder
    public func getFolderItemData(userID:String,folder_id:String,control:String,sectionID:String){
        
        var note_id      : [Any] = []
        var imageURL     : [Any] = []
        var imageName    : [Any] = []
        var imagePass    : [Any] = []
        var imageTag     : [Any] = []
        var ImageLbl     : [Any] = []
        var urlImg       : [Any] = []
        
        var apiUrl = ""
        var postStr = ""
        
        if is_bookmarkPage != ""{
            apiUrl   = "https://nivaroapp.nivaro.com.au/api/ios/BookmarkItems"
            postStr  = "userID=\(userID)&section_id=4"
        }else{
            apiUrl   = "https://nivaroapp.nivaro.com.au/api/show_note/"
            postStr  = "control=\(control)&userID=\(userID)&folderID=\(folder_id)"
        }
        var request = URLRequest(url: URL(string: apiUrl)!)
        request.httpMethod  = "POST"
        let postString      = postStr
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    self.spiner.stopAnimating()
                    self.view.isUserInteractionEnabled = true
                    
                    let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            
                            if self.is_bookmarkPage == ""{
                                if let status = json["result"] as? String, status == "true" {
                                    if let content  = json["data"]  as? [String: Any] {
                                        let notes   = content["notes"] as! [[String:Any]]
                                        
                                        // Array Collection For Notes
                                        for nt in notes{
                                            let noteIDs       =   nt["noteID"]!
                                            let names         =   nt["note_name"]!
                                            let noteTextss    =   nt["text"]!
                                            let notePass      =   nt["password"]!
                                            let isTag         =   nt["is_taged"]!
                                            let lblName       =   nt["label_name"]!
                                            let urlImage      =  nt["text"]!
                                            
                                            let url  = URL(string: noteTextss as! String)
                                            let data = try? Data(contentsOf: url!)
                                            
                                            
                                            note_id.append(noteIDs)
                                            imageName.append(names)
                                            imageURL.append(data!)
                                            imagePass.append(notePass)
                                            imageTag.append(isTag)
                                            ImageLbl.append(lblName)
                                            urlImg.append(urlImage)
                                        }
                                        
                                        DispatchQueue.main.async {
                                            self.noteID    = note_id
                                            self.name      = imageName
                                            self.imageUrl  = imageURL
                                            self.notePass  = imagePass
                                            self.labelName = ImageLbl
                                            self.isTagged  = imageTag
                                            self.linkUrl   = urlImg
                                            self.spiner.stopAnimating()
                                            self.view.isUserInteractionEnabled = true
                                            self.viewDidAppear(true)
                                            
                                        }
                                    }
                                    
                                }else{
                                    DispatchQueue.main.async {
                                        self.spiner.stopAnimating()
                                        self.view.isUserInteractionEnabled = true
                                        let alert = UIAlertController(title: "Nivaro Error", message: (error?.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                                        alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                        self.present(alert, animated: true, completion: nil)
                                    }
                                    
                                }
                                
                            }else{
                                if let status = json["result"] as? String, status == "true" {
                                    if let content  = json["data"]  as? [[String: Any]] {
                                        
                                        // Array Collection For Notes
                                        for nt in content{
                                            
                                            let noteIDs       =   nt["noteID"]!
                                            let names         =   nt["note_name"]!
                                            let noteTextss    =   nt["text"]!
                                            let notePass      =   nt["password"]!
                                            let isTag         =   nt["is_taged"]!
                                            let lblName       =   nt["label_name"]!
                                            let urlImage      =   nt["text"]!
                                            
                                            let url  = URL(string: noteTextss as! String)
                                            let data = try? Data(contentsOf: url!)
                                            
                                            
                                            note_id.append(noteIDs)
                                            imageName.append(names)
                                            imageURL.append(data!)
                                            imagePass.append(notePass)
                                            imageTag.append(isTag)
                                            ImageLbl.append(lblName)
                                            urlImg.append(urlImage)
                                        }
                                        
                                        DispatchQueue.main.async {
                                            self.noteID    = note_id
                                            self.name      = imageName
                                            self.imageUrl  = imageURL
                                            self.notePass  = imagePass
                                            self.labelName = ImageLbl
                                            self.isTagged  = imageTag
                                            self.linkUrl   = urlImg
                                            self.spiner.stopAnimating()
                                            self.view.isUserInteractionEnabled = true
                                            self.viewDidAppear(true)
                                        }
                                    }
                                }
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: (error.localizedDescription), preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                        
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
    
    //---------------- SHARE IMAGE
    
    @IBAction func shareIT(_ sender: Any) {
        
        let items = [previewImage.image]
        let ac = UIActivityViewController(activityItems: items as [Any], applicationActivities: nil)
        present(ac, animated: true)
        
    }
    
    
    //---------------- DELETE IMAGE
    
    @IBAction func deleteIT(_ sender: Any) {
        
        let alert = UIAlertController(title: "Delete Note Alert", message: "Are You Sure To Delete It?", preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: { action in
            
            // Remove From Bookmark
            self.deleteItNow()
            
        }))
        
        alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
        
    }
    
    
    func deleteItNow(){
        // Calling API
        var request         = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/delete_note/")!)
        request.httpMethod  = "POST"
        let postString      = "userID=\(userID!)&noteID=\(currentNote)"
        request.httpBody    = postString.data(using: .utf8)

        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in

            if error != nil{
                DispatchQueue.main.async {
                    let message = "Loading Error. Try again"
                    let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{

                if let urlContent = data{
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                self.dismissController()
                            }else{
                                DispatchQueue.main.async {
                                    let message = "No Any Data Found"
                                    let alert = UIAlertController(title: "Nivaro Success", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }

                    }catch let error {

                        let err = (error.localizedDescription)
                        let message = err
                        DispatchQueue.main.async {
                            let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }
            }
        }
        task.resume()
    }
    
    
    
    // ------------ BOOKMARK IMAGE
    
    @IBAction func bookMarkIT(_ sender: Any) {
        
        if isTaged == "true"{
            let alert = UIAlertController(title: "Bookmark Alert", message: "This Image Is Bookmarked. Do you want to remove From Bookmark ?", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: { action in

                // Remove From Bookmark
                self.taggingNote(tags: "false")

            }))

            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)
            
        }else{

            let alert = UIAlertController(title: "Bookmark Alert", message: "Are You Sure To Bookmark This Image?", preferredStyle: UIAlertController.Style.alert)
            alert.addAction(UIAlertAction(title: "Yes", style: UIAlertAction.Style.default, handler: { action in

                // Remove From Bookmark
                self.taggingNote(tags: "true")

            }))

            alert.addAction(UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler: nil))
            self.present(alert, animated: true, completion: nil)

        }
        
    }
    
    func taggingNote(tags:String) {
        var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/add_tag/")!)
        request.httpMethod  = "POST"
        let postString      = "control=tag_note&userID=\(self.userID!)&noteID=\(self.currentNote)&tags=\(tags)"
        request.httpBody    = postString.data(using: .utf8)

        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Nivaro Error", message: error?.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }else{
                if let urlContent = data{
                    do{
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                DispatchQueue.main.async {
                                    if tags == "false"{
                                        self.tagButton.tintColor = UIColor.white
                                    }else{
                                        self.tagButton.tintColor = UIColor.systemRed
                                    }
                                    self.getFolderItemData(userID: self.userID!, folder_id: self.mainFolderID, control: "show_note", sectionID: "4")
                                }
                            }else{
                                DispatchQueue.main.async {
                                    let alert = UIAlertController(title: "Nivaro Error", message: json["message"] as? String, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    } catch let error {
                        DispatchQueue.main.async {
                            let alert = UIAlertController(title: "Nivaro Error", message: error.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                       
                    }// Do And Catch Close
                }// URL Content CLose]
            }//Task Control Close
        }
        task.resume()
    }
    
 
    
    
    /* SWIPING IMAGE TO OTHER IMAGE FOLDER*/
    @IBAction func swipFolder(_ sender: Any) {
        
    let displayVC = UIStoryboard(name: "Note", bundle: nil).instantiateViewController(withIdentifier: "shifting_vc") as! ShiftingNotesViewController
        displayVC.noteID = currentNote
        displayVC.sectionID  = "4"
        self.present(displayVC, animated: true, completion: nil)
        
        
        
    }
    
    /* SET REMINDER VIEW CONTROLLER */
    
    @IBAction func setAlarm(_ sender: Any) {
        let myDatePicker: UIDatePicker = UIDatePicker()
        // setting properties of the datePicker
        myDatePicker.timeZone = NSTimeZone.local
        myDatePicker.frame = CGRect(x: 30, y: 15, width: 270, height: 200)

        let alertController = UIAlertController(title: "Select Date And Time \n\n\n\n\n\n\n\n", message: nil, preferredStyle: UIAlertController.Style.alert)
        alertController.view.addSubview(myDatePicker)
        
        let somethingAction = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default, handler: { alert -> Void in
            
            let dateFormatter = DateFormatter()

            dateFormatter.dateStyle   = DateFormatter.Style.short
            dateFormatter.timeStyle   = DateFormatter.Style.short
            dateFormatter.dateFormat  = "yyyy-MM-dd HH:mm:ss"

            let strDate = dateFormatter.string(from: myDatePicker.date)
            let date    = dateFormatter.date(from: strDate)
            
            // Creating Usernotification
            let center = UNUserNotificationCenter.current()

            center.requestAuthorization(options: [.alert, .badge, .sound]) { [self] (granted, error) in
                if granted {
                    self.scheduleNotification(dateString:date!, dateInString: strDate)
                } else {
                    print("D'oh")
                }
            }
            
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.cancel, handler: nil)
        
        alertController.addAction(somethingAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion:{})
    }
    
    
    
    func scheduleNotification(dateString:Date,dateInString:String) {
        let imgUrl    = self.linkUrl[indexPathImage] as! String
        let imgName   = (self.name[indexPathImage] as? String)!
        
        let center    = UNUserNotificationCenter.current()
        let content   = UNMutableNotificationContent()
        content.title = imgName
        content.body  = imgUrl
        
        content.categoryIdentifier = "alarm"
        content.userInfo = ["type": "image","imageID":"\(String(describing: imgUrl))"]
        content.sound = UNNotificationSound.default
        
        let calendar   = Calendar.current
        let components = calendar.dateComponents([.year, .month, .day, .hour,.minute,.second], from: dateString.addingTimeInterval(2))
        
        let trigger = UNCalendarNotificationTrigger(dateMatching: components, repeats: false)
        
        let identifires = UUID().uuidString
        
        let request = UNNotificationRequest(identifier: identifires, content: content, trigger: trigger)
        
        
        center.add(request, withCompletionHandler: {(error) in
            if error != nil {
                
                DispatchQueue.main.async {
                    let alert = UIAlertController(title: "Reminder Error!", message: "Reminder Can't Set", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
                
            }else{
            
                DispatchQueue.main.async {
                  
                    let alert = UIAlertController(title: "Reminder Set", message: "Reminder Set SuccessFully for '\(imgName)'", preferredStyle: UIAlertController.Style.alert)
                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                    self.present(alert, animated: true, completion: nil)
                }
            }
        })
    }
    
    
    func dismissController() {
        DispatchQueue.main.async {
            self.navigationController?.popViewController(animated: true)
            self.dismiss(animated: true, completion: nil)
        }
    }
    
    @IBAction func setPassword(_ sender: Any) {
        var message:String = ""
        if password != ""{
            message = "If You want to remove password leave the password and varify password textbox blank."
        }else{
            message = "all fields are mandatory."
        }
        setNotePassword(message:message)
    }
    
    func setNotePassword(message:String){
        if password != ""{
            
            let alertController = UIAlertController(title: "Update Note Password", message:message, preferredStyle: UIAlertController.Style.alert)
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter Login Password"
            }
            
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter File Password"
            }
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter Verify Password"
            }
            
            let saveAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { [self] alert -> Void in
                
                let loginPassword   = alertController.textFields![0] as UITextField
                let notePassword    = alertController.textFields![1] as UITextField
                let verifyPassword  = alertController.textFields![2] as UITextField
                
                let alertLoginTxt   = loginPassword.text!
                let alertNotePass   = notePassword.text!
                let verifyNotePass  = verifyPassword.text!
                
                if alertLoginTxt != loginKey{
                    let message = "Login Password Not Matched. Try Again."
                    setNotePassword(message:message)
                }else if alertNotePass != verifyNotePass{
                    let message = "Password Not Matched With Verify Password. Password And Verify Password Shuld Be same."
                    setNotePassword(message:message)
                }else{
                    savePasswordForNote(notePass: alertNotePass)
                }
                
            })
            
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler:nil)
            
            alertController.addAction(saveAction)
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true, completion: nil)
            
        }else{
            
            let alertController = UIAlertController(title: "Set Image Password", message: message, preferredStyle: UIAlertController.Style.alert)
            /* Add Text Boxes */
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter Login Password"
            }
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter File Password"
            }
            alertController.addTextField { (textField : UITextField!) -> Void in
                textField.placeholder = "Enter Verify Password"
            }
            
            let saveAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { [self] alert -> Void in
                
                let loginPassword   = alertController.textFields![0] as UITextField
                let notePassword    = alertController.textFields![1] as UITextField
                let verifyPassword  = alertController.textFields![2] as UITextField
                
                let alertLoginTxt   = loginPassword.text!
                let alertNotePass   = notePassword.text!
                let verifyNotePass  = verifyPassword.text!
                
                if alertLoginTxt != loginKey{
                    
                    let message = "Login Password Not Matched. Try Again."
                    setNotePassword(message:message)
                    
                }else if alertNotePass.isEmpty{
                    
                    let message = "Password And Verify Password could not be blank. Please enter Password And Verify Password."
                    setNotePassword(message:message)
                    
                }else if alertNotePass != verifyNotePass{
                    
                    let message = "Password Not Matched With Verify Password. Password And Verify Password Shuld Be same."
                    setNotePassword(message:message)
                    
                }else{
                    savePasswordForNote(notePass: alertNotePass)
                }
                
            })
            
            let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler:nil)
            
            alertController.addAction(saveAction)
            alertController.addAction(cancelAction)
            
            self.present(alertController, animated: true, completion: nil)
            
        }
    }
    
    
    func savePasswordForNote(notePass:String) {
        
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        //notePasswordSet api call
        var request         = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/ios/SetPassword/")!)
        request.httpMethod  = "POST"
        let postString      = "noteID=\(currentNote)&password=\(notePass)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    self.password = notePass
                                    
                                    var titleAlert = ""
                                    if notePass != ""{
                                        self.passwordBtn.tintColor  = UIColor.systemRed
                                        titleAlert = "Password Set Successfully"
                                    }else{
                                        self.passwordBtn.tintColor  = UIColor.white
                                        titleAlert = "Password Removed Successfully"
                                    }
                                    let message = json["message"] as! String
                                    let alert = UIAlertController(title: titleAlert, message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                
                            }else{
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    
                                    let message = "Can't set note password. Please try later."
                                    let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    }catch let error {
                        let err = (error.localizedDescription)
                        let message = err
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }
            }
        }
        task.resume()
        
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    
    
    @IBAction func setImageLbl(_ sender: Any) {
        
        lblAlert(message:"Set \(nameLabel.text!)'s Label")
        
    }
    
    func lblAlert(message:String){
        let alertController = UIAlertController(title: "Set Image Label", message: message, preferredStyle: UIAlertController.Style.alert)
        
        /* Add Text Boxes */
        alertController.addTextField { (textField : UITextField!) -> Void in
            textField.placeholder = "Enter Image Label "
        }
        
        let saveAction = UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: { [self] alert -> Void in
            let labelNames   = alertController.textFields![0] as UITextField
            if labelNames.text!.isEmpty{
                let message = "Label Name Can't Be Empty."
                lblAlert(message:message)
            }else{
                saveLabel(lbl: labelNames.text!)
            }
        })
        
        let cancelAction = UIAlertAction(title: "Cancel", style: UIAlertAction.Style.default, handler:nil)
        alertController.addAction(saveAction)
        alertController.addAction(cancelAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    @objc func saveLabel(lbl:String){
        let note_id = self.currentNote
        let label   = lbl
        
        // Spiners Start
        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
        spiner.center = view.center
        spiner.style  = UIActivityIndicatorView.Style.large
        spiner.color  = .orange
        spiner.hidesWhenStopped = true
        view.addSubview(spiner)
        spiner.startAnimating()
        self.view.isUserInteractionEnabled = false
        
        //notePasswordSet api call
        var request         = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/Edit_label/")!)
        request.httpMethod  = "POST"
        let postString      = "label_name=\(label)&noteID=\(note_id)"
        request.httpBody    = postString.data(using: .utf8)
        
        let task  = URLSession.shared.dataTask(with: request){ (data,respnce,error) in
            if error != nil{
                self.spiner.stopAnimating()
                self.view.isUserInteractionEnabled = true
                print(error?.localizedDescription as Any)
            }else{
                if let urlContent = data{
                    do {
                        //create json object from data
                        if let json = try JSONSerialization.jsonObject(with: urlContent) as? [String: Any] {
                            if let status = json["result"] as? String, status == "true" {
                                
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    let message = json["message"] as! String
                                    let alert = UIAlertController(title: "Label Set Successfully", message: message, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                                
                            }else{
                                DispatchQueue.main.async {
                                    self.spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    let alert = UIAlertController(title: "Nivaro Error", message: json["message"] as? String, preferredStyle: UIAlertController.Style.alert)
                                    alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                                    self.present(alert, animated: true, completion: nil)
                                }
                            }
                        }
                    }catch let error {
                        let err = (error.localizedDescription)
                        let message = err
                        DispatchQueue.main.async {
                            self.spiner.stopAnimating()
                            self.view.isUserInteractionEnabled = true
                            
                            let alert = UIAlertController(title: "Nivaro Error", message: message, preferredStyle: UIAlertController.Style.alert)
                            alert.addAction(UIAlertAction(title: "OK", style: UIAlertAction.Style.default, handler: nil))
                            self.present(alert, animated: true, completion: nil)
                        }
                    }// Do And Catch Close
                }
            }
        }
        task.resume()
        
    }
    
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
        //let touch: UITouch? = touches.first
        self.view.endEditing(true)
    }
    
    
    
}
