//
//  ForgetViewController.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 13/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class ForgetViewController: UIViewController,UITextFieldDelegate {
    
    @IBOutlet weak var userMail: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userMail.textColor = UIColor(named: "lightgray")
    }
    
    
    @IBAction func sendForgetPassword(_ sender: Any) {
        
        let userMailID = userMail.text!
        
        if userMailID != "" {
            
            var spiner = UIActivityIndicatorView()
            
            var request = URLRequest(url: URL(string: "https://nivaroapp.nivaro.com.au/api/forgot/")!)
            
            request.httpMethod = "POST"
            
            let postString = "email=\(userMailID)&control=forgot_password"
            
            request.httpBody = postString.data(using: .utf8)
            
            let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
                
                if error != nil{
                    
                    DispatchQueue.main.async {
                        
                        let alertController = UIAlertController(title: "Nivaro Forget Error", message: error?.localizedDescription, preferredStyle: UIAlertController.Style.alert)
                        
                        alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                            self.dismiss(animated: true, completion: nil)
                        }))
                        
                        //UIApplication.shared.endIgnoringInteractionEvents()
                        
                        self.present(alertController, animated: true, completion: nil)
                    }
                    
                }else{
                    
                    DispatchQueue.main.async {
                        spiner        = UIActivityIndicatorView(frame: CGRect(x:0,y:0,width:80,height:80))
                        spiner.center = self.view.center
                        spiner.style  = UIActivityIndicatorView.Style.large
                        spiner.color  = .orange
                        spiner.hidesWhenStopped = true
                        self.view.addSubview(spiner)
                        spiner.startAnimating()
                        self.view.isUserInteractionEnabled = false
                    }
                    var resultMessage : String
                    var resultJson : String
                    
                    if let requestData = data {
                        do {
                            let jsonResult = try JSONSerialization.jsonObject(with: requestData, options: JSONSerialization.ReadingOptions.mutableContainers) as AnyObject // Added "as anyObject" to fix syntax error in Xcode 8 Beta 6
                            
                            resultMessage = jsonResult["message"]!! as! String
                            resultJson    = jsonResult["result"]!! as! String
                            
                            if resultJson == "false"{
                          
                                DispatchQueue.main.async {
                                    let alertController = UIAlertController(title: "Nivaro Forget Error", message: resultMessage, preferredStyle: UIAlertController.Style.alert)
                                    
                                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                                        self.dismiss(animated: true, completion: nil)
                                    }))
                                    
                                    spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    self.present(alertController, animated: true, completion: nil)
                                }
                                
                            }else{
                             
                                DispatchQueue.main.async {
                                    let alertController = UIAlertController(title: "Nivaro Password Sent", message: resultMessage, preferredStyle: UIAlertController.Style.alert)
                                    
                                    alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                                        self.dismiss(animated: true, completion: nil)
                                    }))
                                    
                                    spiner.stopAnimating()
                                    self.view.isUserInteractionEnabled = true
                                    self.present(alertController, animated: true, completion: nil)
                                }
                            }
                        }catch{
                            
                            DispatchQueue.main.async {
                                let alertController = UIAlertController(title: "Nivari API Error", message: "", preferredStyle: UIAlertController.Style.alert)
                                
                                alertController.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                                    self.dismiss(animated: true, completion: nil)
                                }))
                                
                                spiner.stopAnimating()
                                self.view.isUserInteractionEnabled = true
                                self.present(alertController, animated: true, completion: nil)
                            }
                            
                            
                        }
                        // do catch closed
                    }
                }
            }
            task.resume()
        }else{
            
            let signUPalert = UIAlertController(title: "Nivaro Error", message: "Mail ID is Required.", preferredStyle: UIAlertController.Style.alert)
            
            signUPalert.addAction(UIAlertAction(title: "OK", style: .default, handler: { (action) in
                self.dismiss(animated: true, completion: nil)
            }))
            
            self.present(signUPalert, animated: true, completion: nil)
            
        }
        
    }
    
    
    @IBAction func goToLogin(_ sender: Any) {
        
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        
        let nextViewController = storyboard.instantiateViewController(withIdentifier: "login_vc") as! ViewController
        
        UIApplication.shared.windows.first?.rootViewController = nextViewController
        
        UIApplication.shared.windows.first?.makeKeyAndVisible()
        
    }
    
    override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        self.view.endEditing(true)
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
}
