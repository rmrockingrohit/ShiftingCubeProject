//
//  ShowNotificationModelViewController.swift
//  NivaroApp
//
//  Created by rohit mishra on 27/07/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class ShowNotificationModelViewController: UIViewController {

    var titleNotification:String! = ""
    
    var notification:String! = ""
    
    @IBOutlet weak var textView: UITextView!
    
    @IBOutlet weak var navbarItem: UINavigationItem!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let navBar = self.navigationController?.navigationBar
        
        let tinColor = UIColor(hex: "#D35400")
        
        navBar?.barTintColor = tinColor
        
        navBar?.tintColor = UIColor.white
        
        navBar?.isTranslucent = false
        
        navBar?.titleTextAttributes = [NSAttributedString.Key.foregroundColor: UIColor.white]
        
        self.navbarItem.title = titleNotification
        self.textView.attributedText = notification.htmlToAttributedString
        self.textView.backgroundColor = .black
        self.textView.textColor       = .lightGray
        self.textView.linkTextAttributes = [.foregroundColor: UIColor.link]
    }
    
    
    @IBAction func back(_ sender: Any) {
        self.dismiss(animated: true, completion: nil)
    }
}


extension String {
    var htmlToAttributedString: NSAttributedString? {
        guard let data = data(using: .utf8) else { return nil }
        do {
            return try NSAttributedString(data: data, options: [.documentType: NSAttributedString.DocumentType.html, .characterEncoding:String.Encoding.utf8.rawValue], documentAttributes: nil)
        } catch {
            return nil
        }
    }
    var htmlToString: String {
        return htmlToAttributedString?.string ?? ""
    }
}
