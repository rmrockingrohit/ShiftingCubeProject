//
//  BookmarkItemCollectionViewCell.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 18/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class BookmarkItemCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var itemImg: UIImageView!
    @IBOutlet weak var itemName: UILabel!
    @IBOutlet weak var previewImage: UIImageView!
    @IBOutlet weak var labelName: UILabel!
    
}
