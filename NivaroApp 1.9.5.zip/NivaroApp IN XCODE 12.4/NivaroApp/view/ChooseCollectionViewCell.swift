//
//  ChooseCollectionViewCell.swift
//  NivaroApp
//
//  Created by Rohit Mishra on 30/03/1943 Saka.
//  Copyright © 1943 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class ChooseCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var colorLbl: UILabel!
    
    @IBOutlet weak var colorNameLbl: UILabel!
}
