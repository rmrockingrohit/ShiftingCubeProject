//
//  ReminderCollectionViewCell.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 20/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class ReminderCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var reminderTitle: UILabel!
    
    @IBOutlet weak var timing: UILabel!
    
    @IBOutlet weak var options: UIButton!
}
