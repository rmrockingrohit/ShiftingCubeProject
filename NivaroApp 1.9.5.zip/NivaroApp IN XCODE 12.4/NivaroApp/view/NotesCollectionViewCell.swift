//
//  NotesCollectionViewCell.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 14/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class NotesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImage: UIImageView!
    
    @IBOutlet weak var cellLabel: UILabel!
    
    @IBOutlet weak var labelName: UILabel!
    
    @IBOutlet weak var colorBox: UIButton!
    
    @IBOutlet weak var imagePreview: UIImageView!
    
    @IBOutlet weak var checkBox: UIButton!
}
