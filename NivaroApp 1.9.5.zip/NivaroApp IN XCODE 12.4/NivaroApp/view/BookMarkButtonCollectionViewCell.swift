//
//  BookMarkButtonCollectionViewCell.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 18/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class BookMarkButtonCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var cellImg: UIImageView!
    
    @IBOutlet weak var cellLabel: UILabel!
    
}
