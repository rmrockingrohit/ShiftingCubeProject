//
//  ImageSliderCollectionViewCell.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 31/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class ImageSliderCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var sliderImage: UIImageView!
    
    @IBOutlet weak var counter: UILabel!
    @IBOutlet weak var infoLbl: UILabel!
}
