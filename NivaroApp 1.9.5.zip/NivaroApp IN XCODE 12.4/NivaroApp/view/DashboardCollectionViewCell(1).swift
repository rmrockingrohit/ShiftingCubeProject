//
//  DashboardCollectionViewCell.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 14/05/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class DashboardCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var images: UIImageView!
    @IBOutlet weak var names: UILabel!
}
