//
//  Folder4CollectionViewCell.swift
//  NivaroApp
//
//  Created by Durga shankar Mishra on 01/06/21.
//  Copyright © 2021 ShiftingCube PVT LTD. All rights reserved.
//

import UIKit

class Folder4CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var label: UILabel!
}
